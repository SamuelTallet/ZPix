const Bn = 1, Un = 2, Yn = 16, Hn = 1, Gn = 2, Kn = 4, Wn = 8, $n = 16, zn = 1, Zn = 2, y = /* @__PURE__ */ Symbol(), Xn = "http://www.w3.org/1999/xhtml", Jn = "@attach", Ie = !1;
var Dt = Array.isArray, Lt = Array.prototype.indexOf, jt = Array.from, qt = Object.defineProperty, _e = Object.getOwnPropertyDescriptor, Qn = Object.getOwnPropertyDescriptors, Vt = Object.prototype, Bt = Array.prototype, Ut = Object.getPrototypeOf, ze = Object.isExtensible;
const er = () => {
};
function Yt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function st() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const m = 2, Te = 4, Pe = 8, qe = 1 << 24, U = 16, Y = 32, re = 64, Ve = 128, P = 512, b = 1024, T = 2048, H = 4096, F = 8192, K = 16384, Be = 32768, ve = 65536, Ze = 1 << 17, it = 1 << 18, ae = 1 << 19, Ht = 1 << 20, tr = 1 << 25, te = 32768, Fe = 1 << 21, Ue = 1 << 22, W = 1 << 23, de = /* @__PURE__ */ Symbol("$state"), nr = /* @__PURE__ */ Symbol("legacy props"), rr = /* @__PURE__ */ Symbol(""), ie = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Gt() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Kt(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Wt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function $t(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function zt() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function ir(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function Zt() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Xt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Jt() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Qt() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function lr() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function en() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function lt(e) {
  return e === this.v;
}
function tn(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function ft(e) {
  return !tn(e, this.v);
}
let Re = !1, nn = !1;
function fr() {
  Re = !0;
}
let E = null;
function fe(e) {
  E = e;
}
function rn(e, t = !1, n) {
  E = {
    p: E,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: Re && !t ? { s: null, u: null, $: [] } : null
  };
}
function sn(e) {
  var t = (
    /** @type {ComponentContext} */
    E
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      bt(r);
  }
  return t.i = !0, E = t.p, /** @type {T} */
  {};
}
function ge() {
  return !Re || E !== null && E.l === null;
}
let le = [];
function ln() {
  var e = le;
  le = [], Yt(e);
}
function we(e) {
  if (le.length === 0) {
    var t = le;
    queueMicrotask(() => {
      t === le && ln();
    });
  }
  le.push(e);
}
function ut(e) {
  var t = v;
  if (t === null)
    return h.f |= W, e;
  if ((t.f & Be) === 0) {
    if ((t.f & Ve) === 0)
      throw e;
    t.b.error(e);
  } else
    ue(e, t);
}
function ue(e, t) {
  for (; t !== null; ) {
    if ((t.f & Ve) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const fn = -7169;
function w(e, t) {
  e.f = e.f & fn | t;
}
function Ye(e) {
  (e.f & P) !== 0 || e.deps === null ? w(e, b) : w(e, H);
}
function at(e) {
  if (e !== null)
    for (const t of e)
      (t.f & m) === 0 || (t.f & te) === 0 || (t.f ^= te, at(
        /** @type {Derived} */
        t.deps
      ));
}
function ot(e, t, n) {
  (e.f & T) !== 0 ? t.add(e) : (e.f & H) !== 0 && n.add(e), at(e.deps), w(e, b);
}
const me = /* @__PURE__ */ new Set();
let g = null, R = null, N = [], He = null, Me = !1;
class I {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #_ = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #r = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #l = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #s = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #e = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#l > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    N = [], this.apply();
    var n = [], r = [];
    for (const s of t)
      this.#i(s, n, r);
    this.is_fork || this.#u(), this.is_deferred() ? (this.#f(r), this.#f(n)) : (g = null, Xe(r), Xe(n), this.#s?.resolve()), R = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #i(t, n, r) {
    t.f ^= b;
    for (var s = t.first, i = null; s !== null; ) {
      var f = s.f, u = (f & (Y | re)) !== 0, l = u && (f & b) !== 0, a = l || (f & F) !== 0 || this.skipped_effects.has(s);
      if (!a && s.fn !== null) {
        u ? s.f ^= b : i !== null && (f & (Te | Pe | qe)) !== 0 ? i.b.defer_effect(s) : (f & Te) !== 0 ? n.push(s) : Ee(s) && ((f & U) !== 0 && this.#n.add(s), pe(s));
        var o = s.first;
        if (o !== null) {
          s = o;
          continue;
        }
      }
      var d = s.parent;
      for (s = s.next; s === null && d !== null; )
        d === i && (i = null), s = d.next, d = d.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #f(t) {
    for (var n = 0; n < t.length; n += 1)
      ot(t[n], this.#n, this.#e);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== y && !this.previous.has(t) && this.previous.set(t, n), (t.f & W) === 0 && (this.current.set(t, t.v), R?.set(t, t.v));
  }
  activate() {
    g = this, this.apply();
  }
  deactivate() {
    g === this && (g = null, R = null);
  }
  flush() {
    if (this.activate(), N.length > 0) {
      if (un(), g !== null && g !== this)
        return;
    } else this.#r === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#_) t(this);
    this.#_.clear();
  }
  #u() {
    if (this.#l === 0) {
      for (const t of this.#t) t();
      this.#t.clear();
    }
    this.#r === 0 && this.#a();
  }
  #a() {
    if (me.size > 1) {
      this.previous.clear();
      var t = R, n = !0;
      for (const s of me) {
        if (s === this) {
          n = !1;
          continue;
        }
        const i = [];
        for (const [u, l] of this.current) {
          if (s.current.has(u))
            if (n && l !== s.current.get(u))
              s.current.set(u, l);
            else
              continue;
          i.push(u);
        }
        if (i.length === 0)
          continue;
        const f = [...s.current.keys()].filter((u) => !this.current.has(u));
        if (f.length > 0) {
          var r = N;
          N = [];
          const u = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Map();
          for (const a of i)
            ct(a, f, u, l);
          if (N.length > 0) {
            g = s, s.apply();
            for (const a of N)
              s.#i(a, [], []);
            s.deactivate();
          }
          N = r;
        }
      }
      g = null, R = t;
    }
    this.committed = !0, me.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#r += 1, t && (this.#l += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#r -= 1, t && (this.#l -= 1), this.revive();
  }
  revive() {
    for (const t of this.#n)
      this.#e.delete(t), w(t, T), B(t);
    for (const t of this.#e)
      w(t, H), B(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#t.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#_.add(t);
  }
  settled() {
    return (this.#s ??= st()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new I();
      me.add(g), I.enqueue(() => {
        g === t && t.flush();
      });
    }
    return g;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    we(t);
  }
  apply() {
  }
}
function un() {
  var e = Q;
  Me = !0;
  var t = null;
  try {
    var n = 0;
    for (Ae(!0); N.length > 0; ) {
      var r = I.ensure();
      if (n++ > 1e3) {
        var s, i;
        an();
      }
      r.process(N), $.clear();
    }
  } finally {
    Me = !1, Ae(e), He = null;
  }
}
function an() {
  try {
    zt();
  } catch (e) {
    ue(e, He);
  }
}
let q = null;
function Xe(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (K | F)) === 0 && Ee(r) && (q = /* @__PURE__ */ new Set(), pe(r), r.deps === null && r.first === null && r.nodes === null && (r.teardown === null && r.ac === null ? xt(r) : r.fn = null), q?.size > 0)) {
        $.clear();
        for (const s of q) {
          if ((s.f & (K | F)) !== 0) continue;
          const i = [s];
          let f = s.parent;
          for (; f !== null; )
            q.has(f) && (q.delete(f), i.push(f)), f = f.parent;
          for (let u = i.length - 1; u >= 0; u--) {
            const l = i[u];
            (l.f & (K | F)) === 0 && pe(l);
          }
        }
        q.clear();
      }
    }
    q = null;
  }
}
function ct(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const s of e.reactions) {
      const i = s.f;
      (i & m) !== 0 ? ct(
        /** @type {Derived} */
        s,
        t,
        n,
        r
      ) : (i & (Ue | U)) !== 0 && (i & T) === 0 && _t(s, t, r) && (w(s, T), B(
        /** @type {Effect} */
        s
      ));
    }
}
function _t(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const s of e.deps) {
      if (t.includes(s))
        return !0;
      if ((s.f & m) !== 0 && _t(
        /** @type {Derived} */
        s,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          s,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function B(e) {
  for (var t = He = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (Me && t === v && (n & U) !== 0 && (n & it) === 0)
      return;
    if ((n & (re | Y)) !== 0) {
      if ((n & b) === 0) return;
      t.f ^= b;
    }
  }
  N.push(t);
}
function on(e) {
  let t = 0, n = ye(0), r;
  return () => {
    We() && (J(n), kn(() => (t === 0 && (r = Fn(() => e(() => he(n)))), t += 1, () => {
      we(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, he(n));
      });
    })));
  };
}
var cn = ve | ae | Ve;
function _n(e, t, n) {
  new dn(e, t, n);
}
class dn {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #_ = null;
  /** @type {BoundaryProps} */
  #r;
  /** @type {((anchor: Node) => void)} */
  #l;
  /** @type {Effect} */
  #s;
  /** @type {Effect | null} */
  #n = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #i = null;
  /** @type {DocumentFragment | null} */
  #f = null;
  /** @type {TemplateNode | null} */
  #u = null;
  #a = 0;
  #o = 0;
  #d = !1;
  /** @type {Set<Effect>} */
  #h = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #v = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #c = null;
  #E = on(() => (this.#c = ye(this.#a), () => {
    this.#c = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, n, r) {
    this.#t = t, this.#r = n, this.#l = r, this.parent = /** @type {Effect} */
    v.b, this.is_pending = !!this.#r.pending, this.#s = Pn(() => {
      v.b = this;
      {
        var s = this.#w();
        try {
          this.#n = z(() => r(s));
        } catch (i) {
          this.error(i);
        }
        this.#o > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#u?.remove();
      };
    }, cn);
  }
  #m() {
    try {
      this.#n = z(() => this.#l(this.#t));
    } catch (t) {
      this.error(t);
    }
  }
  #b() {
    const t = this.#r.pending;
    t && (this.#e = z(() => t(this.#t)), I.enqueue(() => {
      var n = this.#w();
      this.#n = this.#p(() => (I.ensure(), z(() => this.#l(n)))), this.#o > 0 ? this.#g() : (be(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #w() {
    var t = this.#t;
    return this.is_pending && (this.#u = yt(), this.#t.before(this.#u), t = this.#u), t;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    ot(t, this.#h, this.#v);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#r.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(t) {
    var n = v, r = h, s = E;
    D(this.#s), x(this.#s), fe(this.#s.ctx);
    try {
      return t();
    } catch (i) {
      return ut(i), null;
    } finally {
      D(n), x(r), fe(s);
    }
  }
  #g() {
    const t = (
      /** @type {(anchor: Node) => void} */
      this.#r.pending
    );
    this.#n !== null && (this.#f = document.createDocumentFragment(), this.#f.append(
      /** @type {TemplateNode} */
      this.#u
    ), Cn(this.#n, this.#f)), this.#e === null && (this.#e = z(() => t(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #y(t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#y(t);
      return;
    }
    if (this.#o += t, this.#o === 0) {
      this.is_pending = !1;
      for (const n of this.#h)
        w(n, T), B(n);
      for (const n of this.#v)
        w(n, H), B(n);
      this.#h.clear(), this.#v.clear(), this.#e && be(this.#e, () => {
        this.#e = null;
      }), this.#f && (this.#t.before(this.#f), this.#f = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    this.#y(t), this.#a += t, this.#c && xe(this.#c, this.#a);
  }
  get_effect_pending() {
    return this.#E(), J(
      /** @type {Source<number>} */
      this.#c
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#r.onerror;
    let r = this.#r.failed;
    if (this.#d || !n && !r)
      throw t;
    this.#n && (M(this.#n), this.#n = null), this.#e && (M(this.#e), this.#e = null), this.#i && (M(this.#i), this.#i = null);
    var s = !1, i = !1;
    const f = () => {
      if (s) {
        en();
        return;
      }
      s = !0, i && Qt(), I.ensure(), this.#a = 0, this.#i !== null && be(this.#i, () => {
        this.#i = null;
      }), this.is_pending = this.has_pending_snippet(), this.#n = this.#p(() => (this.#d = !1, z(() => this.#l(this.#t)))), this.#o > 0 ? this.#g() : this.is_pending = !1;
    };
    var u = h;
    try {
      x(null), i = !0, n?.(t, f), i = !1;
    } catch (l) {
      ue(l, this.#s && this.#s.parent);
    } finally {
      x(u);
    }
    r && we(() => {
      this.#i = this.#p(() => {
        I.ensure(), this.#d = !0;
        try {
          return z(() => {
            r(
              this.#t,
              () => t,
              () => f
            );
          });
        } catch (l) {
          return ue(
            l,
            /** @type {Effect} */
            this.#s.parent
          ), null;
        } finally {
          this.#d = !1;
        }
      });
    });
  }
}
function hn(e, t, n, r) {
  const s = ge() ? Ge : gn;
  if (n.length === 0 && e.length === 0) {
    r(t.map(s));
    return;
  }
  var i = g, f = (
    /** @type {Effect} */
    v
  ), u = vn();
  function l() {
    Promise.all(n.map((a) => /* @__PURE__ */ pn(a))).then((a) => {
      u();
      try {
        r([...t.map(s), ...a]);
      } catch (o) {
        (f.f & K) === 0 && ue(o, f);
      }
      i?.deactivate(), Se();
    }).catch((a) => {
      ue(a, f);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    u();
    try {
      return l();
    } finally {
      i?.deactivate(), Se();
    }
  }) : l();
}
function vn() {
  var e = v, t = h, n = E, r = g;
  return function(i = !0) {
    D(e), x(t), fe(n), i && r?.activate();
  };
}
function Se() {
  D(null), x(null), fe(null);
}
// @__NO_SIDE_EFFECTS__
function Ge(e) {
  var t = m | T, n = h !== null && (h.f & m) !== 0 ? (
    /** @type {Derived} */
    h
  ) : null;
  return v !== null && (v.f |= ae), {
    ctx: E,
    deps: null,
    effects: null,
    equals: lt,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      y
    ),
    wv: 0,
    parent: n ?? v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function pn(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    v
  );
  r === null && Gt();
  var s = (
    /** @type {Boundary} */
    r.b
  ), i = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), f = ye(
    /** @type {V} */
    y
  ), u = !h, l = /* @__PURE__ */ new Map();
  return An(() => {
    var a = st();
    i = a.promise;
    try {
      Promise.resolve(e()).then(a.resolve, a.reject).then(() => {
        o === g && o.committed && o.deactivate(), Se();
      });
    } catch (_) {
      a.reject(_), Se();
    }
    var o = (
      /** @type {Batch} */
      g
    );
    if (u) {
      var d = s.is_rendered();
      s.update_pending_count(1), o.increment(d), l.get(o)?.reject(ie), l.delete(o), l.set(o, a);
    }
    const c = (_, p = void 0) => {
      if (o.activate(), p)
        p !== ie && (f.f |= W, xe(f, p));
      else {
        (f.f & W) !== 0 && (f.f ^= W), xe(f, _);
        for (const [C, j] of l) {
          if (l.delete(C), C === o) break;
          j.reject(ie);
        }
      }
      u && (s.update_pending_count(-1), o.decrement(d));
    };
    a.promise.then(c, (_) => c(null, _ || "unknown"));
  }), mt(() => {
    for (const a of l.values())
      a.reject(ie);
  }), new Promise((a) => {
    function o(d) {
      function c() {
        d === i ? a(f) : o(i);
      }
      d.then(c, c);
    }
    o(i);
  });
}
// @__NO_SIDE_EFFECTS__
function ur(e) {
  const t = /* @__PURE__ */ Ge(e);
  return Pt(t), t;
}
// @__NO_SIDE_EFFECTS__
function gn(e) {
  const t = /* @__PURE__ */ Ge(e);
  return t.equals = ft, t;
}
function dt(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      M(
        /** @type {Effect} */
        t[n]
      );
  }
}
function wn(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & m) === 0)
      return (t.f & K) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Ke(e) {
  var t, n = v;
  D(wn(e));
  try {
    e.f &= ~te, dt(e), t = Nt(e);
  } finally {
    D(n);
  }
  return t;
}
function ht(e) {
  var t = Ke(e);
  if (!e.equals(t) && (e.wv = Ot(), (!g?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    w(e, b);
    return;
  }
  ne || (R !== null ? (We() || g?.is_fork) && R.set(e, t) : Ye(e));
}
let De = /* @__PURE__ */ new Set();
const $ = /* @__PURE__ */ new Map();
let vt = !1;
function ye(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: lt,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function G(e, t) {
  const n = ye(e);
  return Pt(n), n;
}
// @__NO_SIDE_EFFECTS__
function ar(e, t = !1, n = !0) {
  const r = ye(e);
  return t || (r.equals = ft), Re && n && E !== null && E.l !== null && (E.l.s ??= []).push(r), r;
}
function Z(e, t, n = !1) {
  h !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!O || (h.f & Ze) !== 0) && ge() && (h.f & (m | U | Ue | Ze)) !== 0 && !V?.includes(e) && Jt();
  let r = n ? oe(t) : t;
  return xe(e, r);
}
function xe(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    ne ? $.set(e, t) : $.set(e, n), e.v = t;
    var r = I.ensure();
    if (r.capture(e, n), (e.f & m) !== 0) {
      const s = (
        /** @type {Derived} */
        e
      );
      (e.f & T) !== 0 && Ke(s), Ye(s);
    }
    e.wv = Ot(), pt(e, T), ge() && v !== null && (v.f & b) !== 0 && (v.f & (Y | re)) === 0 && (k === null ? Nn([e]) : k.push(e)), !r.is_fork && De.size > 0 && !vt && yn();
  }
  return t;
}
function yn() {
  vt = !1;
  var e = Q;
  Ae(!0);
  const t = Array.from(De);
  try {
    for (const n of t)
      (n.f & b) !== 0 && w(n, H), Ee(n) && pe(n);
  } finally {
    Ae(e);
  }
  De.clear();
}
function he(e) {
  Z(e, e.v + 1);
}
function pt(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var r = ge(), s = n.length, i = 0; i < s; i++) {
      var f = n[i], u = f.f;
      if (!(!r && f === v)) {
        var l = (u & T) === 0;
        if (l && w(f, t), (u & m) !== 0) {
          var a = (
            /** @type {Derived} */
            f
          );
          R?.delete(a), (u & te) === 0 && (u & P && (f.f |= te), pt(a, H));
        } else l && ((u & U) !== 0 && q !== null && q.add(
          /** @type {Effect} */
          f
        ), B(
          /** @type {Effect} */
          f
        ));
      }
    }
}
function oe(e) {
  if (typeof e != "object" || e === null || de in e)
    return e;
  const t = Ut(e);
  if (t !== Vt && t !== Bt)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Dt(e), s = /* @__PURE__ */ G(0), i = ee, f = (u) => {
    if (ee === i)
      return u();
    var l = h, a = ee;
    x(null), nt(i);
    var o = u();
    return x(l), nt(a), o;
  };
  return r && n.set("length", /* @__PURE__ */ G(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(u, l, a) {
        (!("value" in a) || a.configurable === !1 || a.enumerable === !1 || a.writable === !1) && Zt();
        var o = n.get(l);
        return o === void 0 ? o = f(() => {
          var d = /* @__PURE__ */ G(a.value);
          return n.set(l, d), d;
        }) : Z(o, a.value, !0), !0;
      },
      deleteProperty(u, l) {
        var a = n.get(l);
        if (a === void 0) {
          if (l in u) {
            const o = f(() => /* @__PURE__ */ G(y));
            n.set(l, o), he(s);
          }
        } else
          Z(a, y), he(s);
        return !0;
      },
      get(u, l, a) {
        if (l === de)
          return e;
        var o = n.get(l), d = l in u;
        if (o === void 0 && (!d || _e(u, l)?.writable) && (o = f(() => {
          var _ = oe(d ? u[l] : y), p = /* @__PURE__ */ G(_);
          return p;
        }), n.set(l, o)), o !== void 0) {
          var c = J(o);
          return c === y ? void 0 : c;
        }
        return Reflect.get(u, l, a);
      },
      getOwnPropertyDescriptor(u, l) {
        var a = Reflect.getOwnPropertyDescriptor(u, l);
        if (a && "value" in a) {
          var o = n.get(l);
          o && (a.value = J(o));
        } else if (a === void 0) {
          var d = n.get(l), c = d?.v;
          if (d !== void 0 && c !== y)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return a;
      },
      has(u, l) {
        if (l === de)
          return !0;
        var a = n.get(l), o = a !== void 0 && a.v !== y || Reflect.has(u, l);
        if (a !== void 0 || v !== null && (!o || _e(u, l)?.writable)) {
          a === void 0 && (a = f(() => {
            var c = o ? oe(u[l]) : y, _ = /* @__PURE__ */ G(c);
            return _;
          }), n.set(l, a));
          var d = J(a);
          if (d === y)
            return !1;
        }
        return o;
      },
      set(u, l, a, o) {
        var d = n.get(l), c = l in u;
        if (r && l === "length")
          for (var _ = a; _ < /** @type {Source<number>} */
          d.v; _ += 1) {
            var p = n.get(_ + "");
            p !== void 0 ? Z(p, y) : _ in u && (p = f(() => /* @__PURE__ */ G(y)), n.set(_ + "", p));
          }
        if (d === void 0)
          (!c || _e(u, l)?.writable) && (d = f(() => /* @__PURE__ */ G(void 0)), Z(d, oe(a)), n.set(l, d));
        else {
          c = d.v !== y;
          var C = f(() => oe(a));
          Z(d, C);
        }
        var j = Reflect.getOwnPropertyDescriptor(u, l);
        if (j?.set && j.set.call(o, a), !c) {
          if (r && typeof l == "string") {
            var $e = (
              /** @type {Source<number>} */
              n.get("length")
            ), Ne = Number(l);
            Number.isInteger(Ne) && Ne >= $e.v && Z($e, Ne + 1);
          }
          he(s);
        }
        return !0;
      },
      ownKeys(u) {
        J(s);
        var l = Reflect.ownKeys(u).filter((d) => {
          var c = n.get(d);
          return c === void 0 || c.v !== y;
        });
        for (var [a, o] of n)
          o.v !== y && !(a in u) && l.push(a);
        return l;
      },
      setPrototypeOf() {
        Xt();
      }
    }
  );
}
function Je(e) {
  try {
    if (e !== null && typeof e == "object" && de in e)
      return e[de];
  } catch {
  }
  return e;
}
function or(e, t) {
  return Object.is(Je(e), Je(t));
}
var Qe, En, gt, wt;
function mn() {
  if (Qe === void 0) {
    Qe = window, En = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    gt = _e(t, "firstChild").get, wt = _e(t, "nextSibling").get, ze(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), ze(n) && (n.__t = void 0);
  }
}
function yt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function Et(e) {
  return (
    /** @type {TemplateNode | null} */
    gt.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function Oe(e) {
  return (
    /** @type {TemplateNode | null} */
    wt.call(e)
  );
}
function cr(e, t) {
  return /* @__PURE__ */ Et(e);
}
function _r(e, t = !1) {
  {
    var n = /* @__PURE__ */ Et(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ Oe(n) : n;
  }
}
function dr(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ Oe(r);
  return r;
}
function hr(e) {
  e.textContent = "";
}
function vr() {
  return !1;
}
function pr(e, t) {
  if (t) {
    const n = document.body;
    e.autofocus = !0, we(() => {
      document.activeElement === n && e.focus();
    });
  }
}
let et = !1;
function bn() {
  et || (et = !0, document.addEventListener(
    "reset",
    (e) => {
      Promise.resolve().then(() => {
        if (!e.defaultPrevented)
          for (
            const t of
            /**@type {HTMLFormElement} */
            e.target.elements
          )
            t.__on_r?.();
      });
    },
    // In the capture phase to guarantee we get noticed of it (no possibility of stopPropagation)
    { capture: !0 }
  ));
}
function Ce(e) {
  var t = h, n = v;
  x(null), D(null);
  try {
    return e();
  } finally {
    x(t), D(n);
  }
}
function gr(e, t, n, r = n) {
  e.addEventListener(t, () => Ce(n));
  const s = e.__on_r;
  s ? e.__on_r = () => {
    s(), r(!0);
  } : e.__on_r = () => r(!0), bn();
}
function Tn(e) {
  v === null && (h === null && $t(), Wt()), ne && Kt();
}
function Sn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function L(e, t, n) {
  var r = v;
  r !== null && (r.f & F) !== 0 && (e |= F);
  var s = {
    ctx: E,
    deps: null,
    nodes: null,
    f: e | T | P,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: r,
    b: r && r.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      pe(s), s.f |= Be;
    } catch (u) {
      throw M(s), u;
    }
  else t !== null && B(s);
  var i = s;
  if (n && i.deps === null && i.teardown === null && i.nodes === null && i.first === i.last && // either `null`, or a singular child
  (i.f & ae) === 0 && (i = i.first, (e & U) !== 0 && (e & ve) !== 0 && i !== null && (i.f |= ve)), i !== null && (i.parent = r, r !== null && Sn(i, r), h !== null && (h.f & m) !== 0 && (e & re) === 0)) {
    var f = (
      /** @type {Derived} */
      h
    );
    (f.effects ??= []).push(i);
  }
  return s;
}
function We() {
  return h !== null && !O;
}
function mt(e) {
  const t = L(Pe, null, !1);
  return w(t, b), t.teardown = e, t;
}
function wr(e) {
  Tn();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !h && (t & Y) !== 0 && (t & Be) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      E
    );
    (r.e ??= []).push(e);
  } else
    return bt(e);
}
function bt(e) {
  return L(Te | Ht, e, !1);
}
function xn(e) {
  I.ensure();
  const t = L(re | ae, e, !0);
  return (n = {}) => new Promise((r) => {
    n.outro ? be(t, () => {
      M(t), r(void 0);
    }) : (M(t), r(void 0));
  });
}
function yr(e) {
  return L(Te, e, !1);
}
function An(e) {
  return L(Ue | ae, e, !0);
}
function kn(e, t = 0) {
  return L(Pe | t, e, !0);
}
function Er(e, t = [], n = [], r = []) {
  hn(r, t, n, (s) => {
    L(Pe, () => e(...s.map(J)), !0);
  });
}
function Pn(e, t = 0) {
  var n = L(U | t, e, !0);
  return n;
}
function mr(e, t = 0) {
  var n = L(qe | t, e, !0);
  return n;
}
function z(e) {
  return L(Y | ae, e, !0);
}
function Tt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = ne, r = h;
    tt(!0), x(null);
    try {
      t.call(null);
    } finally {
      tt(n), x(r);
    }
  }
}
function St(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && Ce(() => {
      s.abort(ie);
    });
    var r = n.next;
    (n.f & re) !== 0 ? n.parent = null : M(n, t), n = r;
  }
}
function Rn(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & Y) === 0 && M(t), t = n;
  }
}
function M(e, t = !0) {
  var n = !1;
  (t || (e.f & it) !== 0) && e.nodes !== null && e.nodes.end !== null && (On(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), St(e, t && !n), ke(e, 0), w(e, K);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const i of r)
      i.stop();
  Tt(e);
  var s = e.parent;
  s !== null && s.first !== null && xt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function On(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ Oe(e);
    e.remove(), e = n;
  }
}
function xt(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function be(e, t, n = !0) {
  var r = [];
  At(e, r, !0);
  var s = () => {
    n && M(e), t && t();
  }, i = r.length;
  if (i > 0) {
    var f = () => --i || s();
    for (var u of r)
      u.out(f);
  } else
    s();
}
function At(e, t, n) {
  if ((e.f & F) === 0) {
    e.f ^= F;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const u of r)
        (u.is_global || n) && t.push(u);
    for (var s = e.first; s !== null; ) {
      var i = s.next, f = (s.f & ve) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (s.f & Y) !== 0 && (e.f & U) !== 0;
      At(s, t, f ? n : !1), s = i;
    }
  }
}
function br(e) {
  kt(e, !0);
}
function kt(e, t) {
  if ((e.f & F) !== 0) {
    e.f ^= F, (e.f & b) === 0 && (w(e, T), B(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, s = (n.f & ve) !== 0 || (n.f & Y) !== 0;
      kt(n, s ? t : !1), n = r;
    }
    var i = e.nodes && e.nodes.t;
    if (i !== null)
      for (const f of i)
        (f.is_global || t) && f.in();
  }
}
function Cn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var s = n === r ? null : /* @__PURE__ */ Oe(n);
      t.append(n), n = s;
    }
}
let Q = !1;
function Ae(e) {
  Q = e;
}
let ne = !1;
function tt(e) {
  ne = e;
}
let h = null, O = !1;
function x(e) {
  h = e;
}
let v = null;
function D(e) {
  v = e;
}
let V = null;
function Pt(e) {
  h !== null && (V === null ? V = [e] : V.push(e));
}
let S = null, A = 0, k = null;
function Nn(e) {
  k = e;
}
let Rt = 1, X = 0, ee = X;
function nt(e) {
  ee = e;
}
function Ot() {
  return ++Rt;
}
function Ee(e) {
  var t = e.f;
  if ((t & T) !== 0)
    return !0;
  if (t & m && (e.f &= ~te), (t & H) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, s = 0; s < r; s++) {
      var i = n[s];
      if (Ee(
        /** @type {Derived} */
        i
      ) && ht(
        /** @type {Derived} */
        i
      ), i.wv > e.wv)
        return !0;
    }
    (t & P) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    R === null && w(e, b);
  }
  return !1;
}
function Ct(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !V?.includes(e))
    for (var s = 0; s < r.length; s++) {
      var i = r[s];
      (i.f & m) !== 0 ? Ct(
        /** @type {Derived} */
        i,
        t,
        !1
      ) : t === i && (n ? w(i, T) : (i.f & b) !== 0 && w(i, H), B(
        /** @type {Effect} */
        i
      ));
    }
}
function Nt(e) {
  var t = S, n = A, r = k, s = h, i = V, f = E, u = O, l = ee, a = e.f;
  S = /** @type {null | Value[]} */
  null, A = 0, k = null, h = (a & (Y | re)) === 0 ? e : null, V = null, fe(e.ctx), O = !1, ee = ++X, e.ac !== null && (Ce(() => {
    e.ac.abort(ie);
  }), e.ac = null);
  try {
    e.f |= Fe;
    var o = (
      /** @type {Function} */
      e.fn
    ), d = o(), c = e.deps;
    if (S !== null) {
      var _;
      if (ke(e, A), c !== null && A > 0)
        for (c.length = A + S.length, _ = 0; _ < S.length; _++)
          c[A + _] = S[_];
      else
        e.deps = c = S;
      if (We() && (e.f & P) !== 0)
        for (_ = A; _ < c.length; _++)
          (c[_].reactions ??= []).push(e);
    } else c !== null && A < c.length && (ke(e, A), c.length = A);
    if (ge() && k !== null && !O && c !== null && (e.f & (m | H | T)) === 0)
      for (_ = 0; _ < /** @type {Source[]} */
      k.length; _++)
        Ct(
          k[_],
          /** @type {Effect} */
          e
        );
    if (s !== null && s !== e) {
      if (X++, s.deps !== null)
        for (let p = 0; p < n; p += 1)
          s.deps[p].rv = X;
      if (t !== null)
        for (const p of t)
          p.rv = X;
      k !== null && (r === null ? r = k : r.push(.../** @type {Source[]} */
      k));
    }
    return (e.f & W) !== 0 && (e.f ^= W), d;
  } catch (p) {
    return ut(p);
  } finally {
    e.f ^= Fe, S = t, A = n, k = r, h = s, V = i, fe(f), O = u, ee = l;
  }
}
function In(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Lt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  if (n === null && (t.f & m) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (S === null || !S.includes(t))) {
    var i = (
      /** @type {Derived} */
      t
    );
    (i.f & P) !== 0 && (i.f ^= P, i.f &= ~te), Ye(i), dt(i), ke(i, 0);
  }
}
function ke(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      In(e, n[r]);
}
function pe(e) {
  var t = e.f;
  if ((t & K) === 0) {
    w(e, b);
    var n = v, r = Q;
    v = e, Q = !0;
    try {
      (t & (U | qe)) !== 0 ? Rn(e) : St(e), Tt(e);
      var s = Nt(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = Rt;
      var i;
      Ie && nn && (e.f & T) !== 0 && e.deps;
    } finally {
      Q = r, v = n;
    }
  }
}
function J(e) {
  var t = e.f, n = (t & m) !== 0;
  if (h !== null && !O) {
    var r = v !== null && (v.f & K) !== 0;
    if (!r && !V?.includes(e)) {
      var s = h.deps;
      if ((h.f & Fe) !== 0)
        e.rv < X && (e.rv = X, S === null && s !== null && s[A] === e ? A++ : S === null ? S = [e] : S.push(e));
      else {
        (h.deps ??= []).push(e);
        var i = e.reactions;
        i === null ? e.reactions = [h] : i.includes(h) || i.push(h);
      }
    }
  }
  if (ne && $.has(e))
    return $.get(e);
  if (n) {
    var f = (
      /** @type {Derived} */
      e
    );
    if (ne) {
      var u = f.v;
      return ((f.f & b) === 0 && f.reactions !== null || Ft(f)) && (u = Ke(f)), $.set(f, u), u;
    }
    var l = (f.f & P) === 0 && !O && h !== null && (Q || (h.f & P) !== 0), a = f.deps === null;
    Ee(f) && (l && (f.f |= P), ht(f)), l && !a && It(f);
  }
  if (R?.has(e))
    return R.get(e);
  if ((e.f & W) !== 0)
    throw e.v;
  return e.v;
}
function It(e) {
  if (e.deps !== null) {
    e.f |= P;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & m) !== 0 && (t.f & P) === 0 && It(
        /** @type {Derived} */
        t
      );
  }
}
function Ft(e) {
  if (e.v === y) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if ($.has(t) || (t.f & m) !== 0 && Ft(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Fn(e) {
  var t = O;
  try {
    return O = !0, e();
  } finally {
    O = t;
  }
}
function Tr(e) {
  return e.endsWith("capture") && e !== "gotpointercapture" && e !== "lostpointercapture";
}
const Mn = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function Sr(e) {
  return Mn.includes(e);
}
const Dn = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function xr(e) {
  return e = e.toLowerCase(), Dn[e] ?? e;
}
const Ln = ["touchstart", "touchmove"];
function jn(e) {
  return Ln.includes(e);
}
const Mt = /* @__PURE__ */ new Set(), Le = /* @__PURE__ */ new Set();
function qn(e, t, n, r = {}) {
  function s(i) {
    if (r.capture || ce.call(t, i), !i.cancelBubble)
      return Ce(() => n?.call(this, i));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? we(() => {
    t.addEventListener(e, s, r);
  }) : t.addEventListener(e, s, r), s;
}
function Ar(e, t, n, r, s) {
  var i = { capture: r, passive: s }, f = qn(e, t, n, i);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && mt(() => {
    t.removeEventListener(e, f, i);
  });
}
function kr(e) {
  for (var t = 0; t < e.length; t++)
    Mt.add(e[t]);
  for (var n of Le)
    n(e);
}
let rt = null;
function ce(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, s = e.composedPath?.() || [], i = (
    /** @type {null | Element} */
    s[0] || e.target
  );
  rt = e;
  var f = 0, u = rt === e && e.__root;
  if (u) {
    var l = s.indexOf(u);
    if (l !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var a = s.indexOf(t);
    if (a === -1)
      return;
    l <= a && (f = l);
  }
  if (i = /** @type {Element} */
  s[f] || e.target, i !== t) {
    qt(e, "currentTarget", {
      configurable: !0,
      get() {
        return i || n;
      }
    });
    var o = h, d = v;
    x(null), D(null);
    try {
      for (var c, _ = []; i !== null; ) {
        var p = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var C = i["__" + r];
          C != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === i) && C.call(i, e);
        } catch (j) {
          c ? _.push(j) : c = j;
        }
        if (e.cancelBubble || p === t || p === null)
          break;
        i = p;
      }
      if (c) {
        for (let j of _)
          queueMicrotask(() => {
            throw j;
          });
        throw c;
      }
    } finally {
      e.__root = t, delete e.currentTarget, x(o), D(d);
    }
  }
}
function Pr(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
function Rr(e, t) {
  return Vn(e, t);
}
const se = /* @__PURE__ */ new Map();
function Vn(e, { target: t, anchor: n, props: r = {}, events: s, context: i, intro: f = !0 }) {
  mn();
  var u = /* @__PURE__ */ new Set(), l = (d) => {
    for (var c = 0; c < d.length; c++) {
      var _ = d[c];
      if (!u.has(_)) {
        u.add(_);
        var p = jn(_);
        t.addEventListener(_, ce, { passive: p });
        var C = se.get(_);
        C === void 0 ? (document.addEventListener(_, ce, { passive: p }), se.set(_, 1)) : se.set(_, C + 1);
      }
    }
  };
  l(jt(Mt)), Le.add(l);
  var a = void 0, o = xn(() => {
    var d = n ?? t.appendChild(yt());
    return _n(
      /** @type {TemplateNode} */
      d,
      {
        pending: () => {
        }
      },
      (c) => {
        if (i) {
          rn({});
          var _ = (
            /** @type {ComponentContext} */
            E
          );
          _.c = i;
        }
        s && (r.$$events = s), a = e(c, r) || {}, i && sn();
      }
    ), () => {
      for (var c of u) {
        t.removeEventListener(c, ce);
        var _ = (
          /** @type {number} */
          se.get(c)
        );
        --_ === 0 ? (document.removeEventListener(c, ce), se.delete(c)) : se.set(c, _);
      }
      Le.delete(l), d !== n && d.parentNode?.removeChild(d);
    };
  });
  return je.set(a, o), a;
}
let je = /* @__PURE__ */ new WeakMap();
function Or(e, t) {
  const n = je.get(e);
  return n ? (je.delete(e), n(t)) : Promise.resolve();
}
export {
  ir as $,
  hr as A,
  Oe as B,
  mr as C,
  yr as D,
  ve as E,
  lr as F,
  or as G,
  mt as H,
  F as I,
  hn as J,
  Jn as K,
  rr as L,
  Tr as M,
  qn as N,
  kr as O,
  pr as P,
  xr as Q,
  Xn as R,
  Sr as S,
  zn as T,
  y as U,
  Qn as V,
  gr as W,
  Fn as X,
  kn as Y,
  er as Z,
  _e as _,
  Et as a,
  Kn as a0,
  oe as a1,
  Z as a2,
  ne as a3,
  K as a4,
  Wn as a5,
  Re as a6,
  Gn as a7,
  Hn as a8,
  Ge as a9,
  $n as aa,
  de as ab,
  nr as ac,
  We as ad,
  on as ae,
  G as af,
  wr as ag,
  rn as ah,
  sn as ai,
  ur as aj,
  fr as ak,
  _r as al,
  Er as am,
  cr as an,
  dr as ao,
  Ar as ap,
  Pr as aq,
  Rr as ar,
  Or as as,
  En as b,
  Zn as c,
  v as d,
  yt as e,
  g as f,
  Ut as g,
  M as h,
  Dt as i,
  z as j,
  Pn as k,
  J as l,
  Cn as m,
  xe as n,
  Vt as o,
  be as p,
  gn as q,
  br as r,
  vr as s,
  Un as t,
  ye as u,
  Bn as v,
  Yn as w,
  ar as x,
  jt as y,
  tr as z
};
