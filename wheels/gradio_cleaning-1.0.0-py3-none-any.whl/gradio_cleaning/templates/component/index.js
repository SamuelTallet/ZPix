import { i as Se, g as Ve, o as bt, a as Oe, b as mt, T as vt, c as gt, d as Ye, e as q, f as ge, r as Te, h as G, p as Me, j as W, m as _t, s as Ke, k as Le, E as Je, l as E, n as Ce, q as Xe, t as yt, u as Ie, v as wt, w as Et, x as kt, y as Ne, z as H, I as ue, A as At, B as St, C as Ze, D as Qe, F as Tt, G as Mt, H as $e, J as Lt, K as Nt, L as xt, M as Ot, N as Ct, O as U, P as It, Q as Pt, U as Rt, R as zt, S as Ft, V as Dt, W as Ht, X as oe, Y as et, Z as Ut, _ as Bt, $ as jt, a0 as Gt, a1 as se, a2 as J, a3 as Wt, a4 as qt, a5 as Vt, a6 as Yt, a7 as Kt, a8 as Jt, a9 as Xt, aa as Zt, ab as Qt, ac as $t, ad as er, ae as tr, af as ee, ag as te, ah as ce, ai as le, aj as N, ak as rr, al as he, am as P, an as C, ao as j, ap as _e, aq as Y } from "./render-IW9vq483.js";
const ar = [];
function tt(e, t = !1, a = !1) {
  return re(e, /* @__PURE__ */ new Map(), "", ar, null, a);
}
function re(e, t, a, r, n = null, s = !1) {
  if (typeof e == "object" && e !== null) {
    var f = t.get(e);
    if (f !== void 0) return f;
    if (e instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(e)
    );
    if (e instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(e)
    );
    if (Se(e)) {
      var i = (
        /** @type {Snapshot<any>} */
        Array(e.length)
      );
      t.set(e, i), n !== null && t.set(n, i);
      for (var o = 0; o < e.length; o += 1) {
        var d = e[o];
        o in e && (i[o] = re(d, t, a, r, null, s));
      }
      return i;
    }
    if (Ve(e) === bt) {
      i = {}, t.set(e, i), n !== null && t.set(n, i);
      for (var h in e)
        i[h] = re(
          // @ts-expect-error
          e[h],
          t,
          a,
          r,
          null,
          s
        );
      return i;
    }
    if (e instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(e)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    e.toJSON == "function" && !s)
      return re(
        /** @type {T & { toJSON(): any } } */
        e.toJSON(),
        t,
        a,
        r,
        // Associate the instance with the toJSON clone
        e
      );
  }
  if (e instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      e
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(e)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      e
    );
  }
}
function nr(e) {
  var t = document.createElement("template");
  return t.innerHTML = e.replaceAll("<!>", "<!---->"), t.content;
}
function ie(e, t) {
  var a = (
    /** @type {Effect} */
    Ye
  );
  a.nodes === null && (a.nodes = { start: e, end: t, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function R(e, t) {
  var a = (t & vt) !== 0, r = (t & gt) !== 0, n, s = !e.startsWith("<!>");
  return () => {
    n === void 0 && (n = nr(s ? e : "<!>" + e), a || (n = /** @type {TemplateNode} */
    Oe(n)));
    var f = (
      /** @type {TemplateNode} */
      r || mt ? document.importNode(n, !0) : n.cloneNode(!0)
    );
    if (a) {
      var i = (
        /** @type {TemplateNode} */
        Oe(f)
      ), o = (
        /** @type {TemplateNode} */
        f.lastChild
      );
      ie(i, o);
    } else
      ie(f, f);
    return f;
  };
}
function Pe(e = "") {
  {
    var t = q(e + "");
    return ie(t, t), t;
  }
}
function pe() {
  var e = document.createDocumentFragment(), t = document.createComment(""), a = q();
  return e.append(t, a), ie(t, a), e;
}
function L(e, t) {
  e !== null && e.before(
    /** @type {Node} */
    t
  );
}
class rt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #r = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #n = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(t, a = !0) {
    this.anchor = t, this.#n = a;
  }
  #s = () => {
    var t = (
      /** @type {Batch} */
      ge
    );
    if (this.#e.has(t)) {
      var a = (
        /** @type {Key} */
        this.#e.get(t)
      ), r = this.#r.get(a);
      if (r)
        Te(r), this.#a.delete(a);
      else {
        var n = this.#t.get(a);
        n && (this.#r.set(a, n.effect), this.#t.delete(a), n.fragment.lastChild.remove(), this.anchor.before(n.fragment), r = n.effect);
      }
      for (const [s, f] of this.#e) {
        if (this.#e.delete(s), s === t)
          break;
        const i = this.#t.get(f);
        i && (G(i.effect), this.#t.delete(f));
      }
      for (const [s, f] of this.#r) {
        if (s === a || this.#a.has(s)) continue;
        const i = () => {
          if (Array.from(this.#e.values()).includes(s)) {
            var d = document.createDocumentFragment();
            _t(f, d), d.append(q()), this.#t.set(s, { effect: f, fragment: d });
          } else
            G(f);
          this.#a.delete(s), this.#r.delete(s);
        };
        this.#n || !r ? (this.#a.add(s), Me(f, i, !1)) : i();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #i = (t) => {
    this.#e.delete(t);
    const a = Array.from(this.#e.values());
    for (const [r, n] of this.#t)
      a.includes(r) || (G(n.effect), this.#t.delete(r));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(t, a) {
    var r = (
      /** @type {Batch} */
      ge
    ), n = Ke();
    if (a && !this.#r.has(t) && !this.#t.has(t))
      if (n) {
        var s = document.createDocumentFragment(), f = q();
        s.append(f), this.#t.set(t, {
          effect: W(() => a(f)),
          fragment: s
        });
      } else
        this.#r.set(
          t,
          W(() => a(this.anchor))
        );
    if (this.#e.set(r, t), n) {
      for (const [i, o] of this.#r)
        i === t ? r.skipped_effects.delete(o) : r.skipped_effects.add(o);
      for (const [i, o] of this.#t)
        i === t ? r.skipped_effects.delete(o.effect) : r.skipped_effects.add(o.effect);
      r.oncommit(this.#s), r.ondiscard(this.#i);
    } else
      this.#s();
  }
}
function D(e, t, a = !1) {
  var r = new rt(e), n = a ? Je : 0;
  function s(f, i) {
    r.ensure(f, i);
  }
  Le(() => {
    var f = !1;
    t((i, o = !0) => {
      f = !0, s(o, i);
    }), f || s(!1, null);
  }, n);
}
function sr(e, t, a) {
  for (var r = [], n = t.length, s, f = t.length, i = 0; i < n; i++) {
    let u = t[i];
    Me(
      u,
      () => {
        if (s) {
          if (s.pending.delete(u), s.done.add(u), s.pending.size === 0) {
            var v = (
              /** @type {Set<EachOutroGroup>} */
              e.outrogroups
            );
            ye(Ne(s.done)), v.delete(s), v.size === 0 && (e.outrogroups = null);
          }
        } else
          f -= 1;
      },
      !1
    );
  }
  if (f === 0) {
    var o = r.length === 0 && a !== null;
    if (o) {
      var d = (
        /** @type {Element} */
        a
      ), h = (
        /** @type {Element} */
        d.parentNode
      );
      At(h), h.append(d), e.items.clear();
    }
    ye(t, !o);
  } else
    s = {
      pending: new Set(t),
      done: /* @__PURE__ */ new Set()
    }, (e.outrogroups ??= /* @__PURE__ */ new Set()).add(s);
}
function ye(e, t = !0) {
  for (var a = 0; a < e.length; a++)
    G(e[a], t);
}
var Re;
function ir(e, t, a, r, n, s = null) {
  var f = e, i = /* @__PURE__ */ new Map(), o = null, d = Xe(() => {
    var y = a();
    return Se(y) ? y : y == null ? [] : Ne(y);
  }), h, u = !0;
  function v() {
    c.fallback = o, fr(c, h, f, t, r), o !== null && (h.length === 0 ? (o.f & H) === 0 ? Te(o) : (o.f ^= H, K(o, null, f)) : Me(o, () => {
      o = null;
    }));
  }
  var m = Le(() => {
    h = /** @type {V[]} */
    E(d);
    for (var y = h.length, g = /* @__PURE__ */ new Set(), b = (
      /** @type {Batch} */
      ge
    ), A = Ke(), l = 0; l < y; l += 1) {
      var p = h[l], w = r(p, l), k = u ? null : i.get(w);
      k ? (k.v && Ce(k.v, p), k.i && Ce(k.i, l), A && b.skipped_effects.delete(k.e)) : (k = or(
        i,
        u ? f : Re ??= q(),
        p,
        w,
        l,
        n,
        t,
        a
      ), u || (k.e.f |= H), i.set(w, k)), g.add(w);
    }
    if (y === 0 && s && !o && (u ? o = W(() => s(f)) : (o = W(() => s(Re ??= q())), o.f |= H)), !u)
      if (A) {
        for (const [_, S] of i)
          g.has(_) || b.skipped_effects.add(S.e);
        b.oncommit(v), b.ondiscard(() => {
        });
      } else
        v();
    E(d);
  }), c = { effect: m, items: i, outrogroups: null, fallback: o };
  u = !1;
}
function fr(e, t, a, r, n) {
  var s = t.length, f = e.items, i = e.effect.first, o, d = null, h = [], u = [], v, m, c, y;
  for (y = 0; y < s; y += 1) {
    if (v = t[y], m = n(v, y), c = /** @type {EachItem} */
    f.get(m).e, e.outrogroups !== null)
      for (const S of e.outrogroups)
        S.pending.delete(c), S.done.delete(c);
    if ((c.f & H) !== 0)
      if (c.f ^= H, c === i)
        K(c, null, a);
      else {
        var g = d ? d.next : i;
        c === e.effect.last && (e.effect.last = c.prev), c.prev && (c.prev.next = c.next), c.next && (c.next.prev = c.prev), z(e, d, c), z(e, c, g), K(c, g, a), d = c, h = [], u = [], i = d.next;
        continue;
      }
    if ((c.f & ue) !== 0 && Te(c), c !== i) {
      if (o !== void 0 && o.has(c)) {
        if (h.length < u.length) {
          var b = u[0], A;
          d = b.prev;
          var l = h[0], p = h[h.length - 1];
          for (A = 0; A < h.length; A += 1)
            K(h[A], b, a);
          for (A = 0; A < u.length; A += 1)
            o.delete(u[A]);
          z(e, l.prev, p.next), z(e, d, l), z(e, p, b), i = b, d = p, y -= 1, h = [], u = [];
        } else
          o.delete(c), K(c, i, a), z(e, c.prev, c.next), z(e, c, d === null ? e.effect.first : d.next), z(e, d, c), d = c;
        continue;
      }
      for (h = [], u = []; i !== null && i !== c; )
        (o ??= /* @__PURE__ */ new Set()).add(i), u.push(i), i = i.next;
      if (i === null)
        continue;
    }
    (c.f & H) === 0 && h.push(c), d = c, i = c.next;
  }
  if (e.outrogroups !== null) {
    for (const S of e.outrogroups)
      S.pending.size === 0 && (ye(Ne(S.done)), e.outrogroups?.delete(S));
    e.outrogroups.size === 0 && (e.outrogroups = null);
  }
  if (i !== null || o !== void 0) {
    var w = [];
    if (o !== void 0)
      for (c of o)
        (c.f & ue) === 0 && w.push(c);
    for (; i !== null; )
      (i.f & ue) === 0 && i !== e.fallback && w.push(i), i = i.next;
    var k = w.length;
    if (k > 0) {
      var _ = null;
      sr(e, w, _);
    }
  }
}
function or(e, t, a, r, n, s, f, i) {
  var o = (f & wt) !== 0 ? (f & Et) === 0 ? kt(a, !1, !1) : Ie(a) : null, d = (f & yt) !== 0 ? Ie(n) : null;
  return {
    v: o,
    i: d,
    e: W(() => (s(t, o ?? a, d ?? n, i), () => {
      e.delete(r);
    }))
  };
}
function K(e, t, a) {
  if (e.nodes)
    for (var r = e.nodes.start, n = e.nodes.end, s = t && (t.f & H) === 0 ? (
      /** @type {EffectNodes} */
      t.nodes.start
    ) : a; r !== null; ) {
      var f = (
        /** @type {TemplateNode} */
        St(r)
      );
      if (s.before(r), r === n)
        return;
      r = f;
    }
}
function z(e, t, a) {
  t === null ? e.effect.first = a : t.next = a, a === null ? e.effect.last = t : a.prev = t;
}
function ze(e, t, ...a) {
  var r = new rt(e);
  Le(() => {
    const n = t() ?? null;
    r.ensure(n, n && ((s) => n(s, ...a)));
  }, Je);
}
function at(e, t) {
  var a = void 0, r;
  Ze(() => {
    a !== (a = t()) && (r && (G(r), r = null), a && (r = W(() => {
      Qe(() => (
        /** @type {(node: Element) => void} */
        a(e)
      ));
    })));
  });
}
function nt(e) {
  var t, a, r = "";
  if (typeof e == "string" || typeof e == "number") r += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var n = e.length;
    for (t = 0; t < n; t++) e[t] && (a = nt(e[t])) && (r && (r += " "), r += a);
  } else for (a in e) e[a] && (r && (r += " "), r += a);
  return r;
}
function cr() {
  for (var e, t, a = 0, r = "", n = arguments.length; a < n; a++) (e = arguments[a]) && (t = nt(e)) && (r && (r += " "), r += t);
  return r;
}
function lr(e) {
  return typeof e == "object" ? cr(e) : e ?? "";
}
const Fe = [...` 	
\r\f \v\uFEFF`];
function dr(e, t, a) {
  var r = e == null ? "" : "" + e;
  if (t && (r = r ? r + " " + t : t), a) {
    for (var n in a)
      if (a[n])
        r = r ? r + " " + n : n;
      else if (r.length)
        for (var s = n.length, f = 0; (f = r.indexOf(n, f)) >= 0; ) {
          var i = f + s;
          (f === 0 || Fe.includes(r[f - 1])) && (i === r.length || Fe.includes(r[i])) ? r = (f === 0 ? "" : r.substring(0, f)) + r.substring(i + 1) : f = i;
        }
  }
  return r === "" ? null : r;
}
function De(e, t = !1) {
  var a = t ? " !important;" : ";", r = "";
  for (var n in e) {
    var s = e[n];
    s != null && s !== "" && (r += " " + n + ": " + s + a);
  }
  return r;
}
function be(e) {
  return e[0] !== "-" || e[1] !== "-" ? e.toLowerCase() : e;
}
function ur(e, t) {
  if (t) {
    var a = "", r, n;
    if (Array.isArray(t) ? (r = t[0], n = t[1]) : r = t, e) {
      e = String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var s = !1, f = 0, i = !1, o = [];
      r && o.push(...Object.keys(r).map(be)), n && o.push(...Object.keys(n).map(be));
      var d = 0, h = -1;
      const y = e.length;
      for (var u = 0; u < y; u++) {
        var v = e[u];
        if (i ? v === "/" && e[u - 1] === "*" && (i = !1) : s ? s === v && (s = !1) : v === "/" && e[u + 1] === "*" ? i = !0 : v === '"' || v === "'" ? s = v : v === "(" ? f++ : v === ")" && f--, !i && s === !1 && f === 0) {
          if (v === ":" && h === -1)
            h = u;
          else if (v === ";" || u === y - 1) {
            if (h !== -1) {
              var m = be(e.substring(d, h).trim());
              if (!o.includes(m)) {
                v !== ";" && u++;
                var c = e.substring(d, u).trim();
                a += " " + c + ";";
              }
            }
            d = u + 1, h = -1;
          }
        }
      }
    }
    return r && (a += De(r)), n && (a += De(n, !0)), a = a.trim(), a === "" ? null : a;
  }
  return e == null ? null : String(e);
}
function fe(e, t, a, r, n, s) {
  var f = e.__className;
  if (f !== a || f === void 0) {
    var i = dr(a, r, s);
    i == null ? e.removeAttribute("class") : t ? e.className = i : e.setAttribute("class", i), e.__className = a;
  } else if (s && n !== s)
    for (var o in s) {
      var d = !!s[o];
      (n == null || d !== !!n[o]) && e.classList.toggle(o, d);
    }
  return s;
}
function me(e, t = {}, a, r) {
  for (var n in a) {
    var s = a[n];
    t[n] !== s && (a[n] == null ? e.style.removeProperty(n) : e.style.setProperty(n, s, r));
  }
}
function we(e, t, a, r) {
  var n = e.__style;
  if (n !== t) {
    var s = ur(t, r);
    s == null ? e.removeAttribute("style") : e.style.cssText = s, e.__style = t;
  } else r && (Array.isArray(r) ? (me(e, a?.[0], r[0]), me(e, a?.[1], r[1], "important")) : me(e, a, r));
  return r;
}
function Ee(e, t, a = !1) {
  if (e.multiple) {
    if (t == null)
      return;
    if (!Se(t))
      return Tt();
    for (var r of e.options)
      r.selected = t.includes(He(r));
    return;
  }
  for (r of e.options) {
    var n = He(r);
    if (Mt(n, t)) {
      r.selected = !0;
      return;
    }
  }
  (!a || t !== void 0) && (e.selectedIndex = -1);
}
function hr(e) {
  var t = new MutationObserver(() => {
    Ee(e, e.__value);
  });
  t.observe(e, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), $e(() => {
    t.disconnect();
  });
}
function He(e) {
  return "__value" in e ? e.__value : e.value;
}
const Z = /* @__PURE__ */ Symbol("class"), V = /* @__PURE__ */ Symbol("style"), st = /* @__PURE__ */ Symbol("is custom element"), it = /* @__PURE__ */ Symbol("is html");
function pr(e, t) {
  t ? e.hasAttribute("selected") || e.setAttribute("selected", "") : e.removeAttribute("selected");
}
function I(e, t, a, r) {
  var n = ft(e);
  n[t] !== (n[t] = a) && (t === "loading" && (e[xt] = a), a == null ? e.removeAttribute(t) : typeof a != "string" && ot(e).includes(t) ? e[t] = a : e.setAttribute(t, a));
}
function br(e, t, a, r, n = !1, s = !1) {
  var f = ft(e), i = f[st], o = !f[it], d = t || {}, h = e.tagName === "OPTION";
  for (var u in t)
    u in a || (a[u] = null);
  a.class ? a.class = lr(a.class) : a.class = null, a[V] && (a.style ??= null);
  var v = ot(e);
  for (const l in a) {
    let p = a[l];
    if (h && l === "value" && p == null) {
      e.value = e.__value = "", d[l] = p;
      continue;
    }
    if (l === "class") {
      var m = e.namespaceURI === "http://www.w3.org/1999/xhtml";
      fe(e, m, p, r, t?.[Z], a[Z]), d[l] = p, d[Z] = a[Z];
      continue;
    }
    if (l === "style") {
      we(e, p, t?.[V], a[V]), d[l] = p, d[V] = a[V];
      continue;
    }
    var c = d[l];
    if (!(p === c && !(p === void 0 && e.hasAttribute(l)))) {
      d[l] = p;
      var y = l[0] + l[1];
      if (y !== "$$")
        if (y === "on") {
          const w = {}, k = "$$" + l;
          let _ = l.slice(2);
          var g = Ft(_);
          if (Ot(_) && (_ = _.slice(0, -7), w.capture = !0), !g && c) {
            if (p != null) continue;
            e.removeEventListener(_, d[k], w), d[k] = null;
          }
          if (p != null)
            if (g)
              e[`__${_}`] = p, U([_]);
            else {
              let S = function(M) {
                d[l].call(this, M);
              };
              d[k] = Ct(_, e, S, w);
            }
          else g && (e[`__${_}`] = void 0);
        } else if (l === "style")
          I(e, l, p);
        else if (l === "autofocus")
          It(
            /** @type {HTMLElement} */
            e,
            !!p
          );
        else if (!i && (l === "__value" || l === "value" && p != null))
          e.value = e.__value = p;
        else if (l === "selected" && h)
          pr(
            /** @type {HTMLOptionElement} */
            e,
            p
          );
        else {
          var b = l;
          o || (b = Pt(b));
          var A = b === "defaultValue" || b === "defaultChecked";
          if (p == null && !i && !A)
            if (f[l] = null, b === "value" || b === "checked") {
              let w = (
                /** @type {HTMLInputElement} */
                e
              );
              const k = t === void 0;
              if (b === "value") {
                let _ = w.defaultValue;
                w.removeAttribute(b), w.defaultValue = _, w.value = w.__value = k ? _ : null;
              } else {
                let _ = w.defaultChecked;
                w.removeAttribute(b), w.defaultChecked = _, w.checked = k ? _ : !1;
              }
            } else
              e.removeAttribute(l);
          else A || v.includes(b) && (i || typeof p != "string") ? (e[b] = p, b in f && (f[b] = Rt)) : typeof p != "function" && I(e, b, p);
        }
    }
  }
  return d;
}
function mr(e, t, a = [], r = [], n = [], s, f = !1, i = !1) {
  Lt(n, a, r, (o) => {
    var d = void 0, h = {}, u = e.nodeName === "SELECT", v = !1;
    if (Ze(() => {
      var c = t(...o.map(E)), y = br(
        e,
        d,
        c,
        s,
        f,
        i
      );
      v && u && "value" in c && Ee(
        /** @type {HTMLSelectElement} */
        e,
        c.value
      );
      for (let b of Object.getOwnPropertySymbols(h))
        c[b] || G(h[b]);
      for (let b of Object.getOwnPropertySymbols(c)) {
        var g = c[b];
        b.description === Nt && (!d || g !== d[b]) && (h[b] && G(h[b]), h[b] = W(() => at(e, () => g))), y[b] = g;
      }
      d = y;
    }), u) {
      var m = (
        /** @type {HTMLSelectElement} */
        e
      );
      Qe(() => {
        Ee(
          m,
          /** @type {Record<string | symbol, any>} */
          d.value,
          !0
        ), hr(m);
      });
    }
    v = !0;
  });
}
function ft(e) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    e.__attributes ??= {
      [st]: e.nodeName.includes("-"),
      [it]: e.namespaceURI === zt
    }
  );
}
var Ue = /* @__PURE__ */ new Map();
function ot(e) {
  var t = e.getAttribute("is") || e.nodeName, a = Ue.get(t);
  if (a) return a;
  Ue.set(t, a = []);
  for (var r, n = e, s = Element.prototype; s !== n; ) {
    r = Dt(n);
    for (var f in r)
      r[f].set && a.push(f);
    n = Ve(n);
  }
  return a;
}
function vr(e, t, a = t) {
  Ht(e, "change", (r) => {
    var n = r ? e.defaultChecked : e.checked;
    a(n);
  }), // If we are hydrating and the value has since changed,
  // then use the update value from the input instead.
  // If defaultChecked is set, then checked == defaultChecked
  oe(t) == null && a(e.checked), et(() => {
    var r = t();
    e.checked = !!r;
  });
}
function gr(e, t, a, r, n) {
  var s = () => {
    r(a[e]);
  };
  a.addEventListener(t, s), n ? et(() => {
    a[e] = n();
  }) : s(), (a === document.body || a === window || a === document) && $e(() => {
    a.removeEventListener(t, s);
  });
}
function _r(e, t, a) {
  if (e == null)
    return t(void 0), Ut;
  const r = oe(
    () => e.subscribe(
      t,
      // @ts-expect-error
      a
    )
  );
  return r.unsubscribe ? () => r.unsubscribe() : r;
}
function yr(e) {
  let t;
  return _r(e, (a) => t = a)(), t;
}
let Q = !1;
function wr(e) {
  var t = Q;
  try {
    return Q = !1, [e(), Q];
  } finally {
    Q = t;
  }
}
const Er = {
  get(e, t) {
    if (!e.exclude.includes(t))
      return e.props[t];
  },
  set(e, t) {
    return !1;
  },
  getOwnPropertyDescriptor(e, t) {
    if (!e.exclude.includes(t) && t in e.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: e.props[t]
      };
  },
  has(e, t) {
    return e.exclude.includes(t) ? !1 : t in e.props;
  },
  ownKeys(e) {
    return Reflect.ownKeys(e.props).filter((t) => !e.exclude.includes(t));
  }
};
// @__NO_SIDE_EFFECTS__
function ct(e, t, a) {
  return new Proxy(
    { props: e, exclude: t },
    Er
  );
}
function T(e, t, a, r) {
  var n = !Yt || (a & Kt) !== 0, s = (a & Vt) !== 0, f = (a & Zt) !== 0, i = (
    /** @type {V} */
    r
  ), o = !0, d = () => (o && (o = !1, i = f ? oe(
    /** @type {() => V} */
    r
  ) : (
    /** @type {V} */
    r
  )), i), h;
  if (s) {
    var u = Qt in e || $t in e;
    h = Bt(e, t)?.set ?? (u && t in e ? (l) => e[t] = l : void 0);
  }
  var v, m = !1;
  s ? [v, m] = wr(() => (
    /** @type {V} */
    e[t]
  )) : v = /** @type {V} */
  e[t], v === void 0 && r !== void 0 && (v = d(), h && (n && jt(), h(v)));
  var c;
  if (n ? c = () => {
    var l = (
      /** @type {V} */
      e[t]
    );
    return l === void 0 ? d() : (o = !0, l);
  } : c = () => {
    var l = (
      /** @type {V} */
      e[t]
    );
    return l !== void 0 && (i = /** @type {V} */
    void 0), l === void 0 ? i : l;
  }, n && (a & Gt) === 0)
    return c;
  if (h) {
    var y = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(l, p) {
        return arguments.length > 0 ? ((!n || !p || y || m) && h(p ? c() : l), l) : c();
      })
    );
  }
  var g = !1, b = ((a & Jt) !== 0 ? Xt : Xe)(() => (g = !1, c()));
  s && E(b);
  var A = (
    /** @type {Effect} */
    Ye
  );
  return (
    /** @type {() => V} */
    (function(l, p) {
      if (arguments.length > 0) {
        const w = p ? E(b) : n && s ? se(l) : l;
        return J(b, w), g = !0, i !== void 0 && (i = w), l;
      }
      return Wt && g || (A.f & qt) !== 0 ? b.v : E(b);
    })
  );
}
const kr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Be = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
kr.reduce((e, { color: t, primary: a, secondary: r }) => ({
  ...e,
  [t]: {
    primary: Be[t][a],
    secondary: Be[t][r]
  }
}), {});
function Ar(e) {
  let t;
  const a = tr((n) => {
    let s = !1;
    const f = e.subscribe((i) => {
      t = i, s && n();
    });
    return s = !0, f;
  });
  function r() {
    return er() ? (a(), t) : yr(e);
  }
  return "set" in e ? {
    get current() {
      return r();
    },
    set current(n) {
      e.set(n);
    }
  } : {
    get current() {
      return r();
    }
  };
}
const Sr = "__i18n__", Tr = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Mr = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Lr(e) {
  return typeof e == "string" && e.includes(Sr);
}
class Nr {
  load_component;
  #e = ee(se({}));
  get shared() {
    return E(this.#e);
  }
  set shared(t) {
    J(this.#e, t, !0);
  }
  #r = ee(se({}));
  get props() {
    return E(this.#r);
  }
  set props(t) {
    J(this.#r, t, !0);
  }
  #t = ee((t) => t);
  get i18n() {
    return E(this.#t);
  }
  set i18n(t) {
    J(this.#t, t, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Mr;
  mounted = !1;
  old_value;
  register_component;
  constructor(t, a) {
    for (const r in t.shared_props)
      this.shared[r] = t.shared_props[r];
    for (const r in t.props)
      r !== "i18n_store" && (this.props[r] = t.props[r]);
    if (a)
      for (const r in a)
        this.props[r] === void 0 && (this.props[r] = a[r]);
    this.i18n = this.props.i18n ?? ((r) => r), this.i18n_store = t.props.i18n_store, this._i18n_from_store = this.i18n_store ? Ar(this.i18n_store) : void 0;
    for (const r of Tr)
      this.shared[r] = this._translate_and_store(
        "shared",
        r,
        // @ts-ignore
        t.shared_props[r]
      ), this.props[r] = this._translate_and_store(
        "props",
        r,
        // @ts-ignore
        t.props[r]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      t.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), te(() => {
      for (const r in t.shared_props)
        this._is_i18n_managed(`shared.${r}`, t.shared_props[r]) || (this.shared[r] = t.shared_props[r]);
      for (const r in t.props)
        r !== "i18n_store" && (this._is_i18n_managed(`props.${r}`, t.props[r]) || (this.props[r] = t.props[r]));
      this.register_component(
        t.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), oe(() => {
        this.shared.id = t.shared_props.id;
      });
    }), te(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [n, s] of Object.entries(this.translatable_props)) {
        const [f, i] = n.split("."), o = this.i18n(s);
        f === "shared" ? this.shared[i] = o : this.props[i] = o;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(t, a) {
    const r = this.translatable_props[t];
    return r ? a === r ? !0 : (delete this.translatable_props[t], !1) : !1;
  }
  _translate_and_store(t, a, r) {
    if (typeof r != "string") return r;
    const n = this.i18n(r);
    return n !== r && (this.translatable_props[`${t}.${a}`] = r), n;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (t) => (this._i18n_from_store?.current, this.i18n(t));
  dispatch(t, a) {
    this.dispatcher(this.shared.id, t, a);
  }
  async get_data() {
    return tt(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const a in t) {
      const r = t[a], n = Lr(r) ? this._translate_and_store(this.shared_props.includes(a) ? "shared" : "props", a, r) : r;
      if (this.shared_props.includes(a)) {
        const s = a;
        this.shared[s] = n;
        continue;
      }
      this.props[a] = n;
    }
  }
  watch_for_change() {
    te(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
typeof process < "u" && process.versions && process.versions.node;
(class extends TransformStream {
  #e = "";
  constructor(e = { allowCR: !1 }) {
    super({
      transform: (t, a) => {
        for (t = this.#e + t; ; ) {
          let r = t.indexOf(`
`), n = e.allowCR ? t.indexOf("\r") : -1;
          if (n !== -1 && n !== t.length - 1 && (r === -1 || r - 1 > n)) {
            a.enqueue(t.slice(0, n)), t = t.slice(n + 1);
            continue;
          }
          if (r === -1) break;
          let s = t[r - 1] === "\r" ? r - 1 : r;
          a.enqueue(t.slice(0, s)), t = t.slice(r + 1);
        }
        this.#e = t;
      },
      flush: (t) => {
        if (this.#e === "") return;
        let a = e.allowCR && this.#e.endsWith("\r") ? this.#e.slice(0, -1) : this.#e;
        t.enqueue(a);
      }
    });
  }
});
var xr = /* @__PURE__ */ R("<img/>");
function je(e, t) {
  ce(t, !0);
  let a = T(t, "src", 3, ""), r = T(t, "restProps", 19, () => ({})), n = T(t, "class_names", 19, () => []), s = /* @__PURE__ */ ct(t, [
    "$$slots",
    "$$events",
    "$$legacy",
    "src",
    "restProps",
    "data_testid",
    "class_names",
    "onload"
  ]);
  const f = ({ class: u, ...v }) => v;
  let i = N(() => f(r())), o = N(() => f(s)), d = N(() => [n().join(" "), r().class, t.class].filter(Boolean).join(" "));
  var h = xr();
  mr(
    h,
    () => ({
      src: a(),
      class: E(d),
      "data-testid": t.data_testid,
      ...E(i),
      ...E(o),
      onload: t.onload
    }),
    void 0,
    void 0,
    void 0,
    "svelte-o6zd0j"
  ), L(e, h), le();
}
const Or = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Ge = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Or.reduce((e, { color: t, primary: a, secondary: r }) => ({
  ...e,
  [t]: {
    primary: Ge[t][a],
    secondary: Ge[t][r]
  }
}), {});
U(["mousedown"]);
U(["click"]);
rr();
const Cr = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], We = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Cr.reduce((e, { color: t, primary: a, secondary: r }) => ({
  ...e,
  [t]: {
    primary: We[t][a],
    secondary: We[t][r]
  }
}), {});
U(["click"]);
U(["click"]);
U(["click"]);
var Ir = /* @__PURE__ */ R("<a><!> <!></a>"), Pr = /* @__PURE__ */ R("<button><!> <!></button>");
function qe(e, t) {
  ce(t, !0);
  let a = T(t, "elem_classes", 19, () => []), r = T(t, "visible", 3, !0), n = T(t, "variant", 3, "secondary"), s = T(t, "size", 3, "md"), f = T(t, "value", 3, null), i = T(t, "link_target", 3, "_self"), o = T(t, "disabled", 3, !1), d = T(t, "scale", 3, null), h = T(t, "onclick", 3, () => {
  });
  var u = pe(), v = he(u);
  {
    var m = (y) => {
      var g = Ir();
      let b, A;
      var l = C(g);
      {
        var p = (_) => {
          {
            let S = N(() => t.icon.url ?? ""), M = N(() => ({ alt: `${f()} icon`, class: "button-icon" }));
            je(_, {
              get src() {
                return E(S);
              },
              get restProps() {
                return E(M);
              }
            });
          }
        };
        D(l, (_) => {
          t.icon && _(p);
        });
      }
      var w = j(l, 2);
      {
        var k = (_) => {
          var S = pe(), M = he(S);
          ze(M, () => t.children), L(_, S);
        };
        D(w, (_) => {
          t.children && _(k);
        });
      }
      P(
        (_) => {
          I(g, "href", t.link), I(g, "target", i()), I(g, "rel", i() === "_blank" ? "noopener noreferrer" : void 0), I(g, "aria-disabled", o()), b = fe(g, 1, `${s() ?? ""} ${n() ?? ""} ${_ ?? ""}`, "svelte-72sf5n", b, {
            hidden: r() === !1 || r() === "hidden",
            disabled: o()
          }), I(g, "id", t.elem_id), A = we(g, "", A, {
            "flex-grow": d(),
            "pointer-events": o() ? "none" : null,
            width: d() === 0 ? "fit-content" : null,
            "min-width": typeof t.min_width == "number" ? `calc(min(${t.min_width}px, 100%))` : null
          });
        },
        [() => (a() ?? []).join(" ")]
      ), L(y, g);
    }, c = (y) => {
      var g = Pr();
      g.__click = function(..._) {
        h()?.apply(this, _);
      };
      let b, A;
      var l = C(g);
      {
        var p = (_) => {
          {
            let S = N(() => ({ alt: `${f()} icon` })), M = N(() => [`button-icon ${f() ? "right-padded" : ""}`]), O = N(() => t.icon.url ?? "");
            je(_, {
              get restProps() {
                return E(S);
              },
              get class_names() {
                return E(M);
              },
              get src() {
                return E(O);
              }
            });
          }
        };
        D(l, (_) => {
          t.icon && _(p);
        });
      }
      var w = j(l, 2);
      {
        var k = (_) => {
          var S = pe(), M = he(S);
          ze(M, () => t.children), L(_, S);
        };
        D(w, (_) => {
          t.children && _(k);
        });
      }
      P(
        (_) => {
          b = fe(g, 1, `${s() ?? ""} ${n() ?? ""} ${_ ?? ""}`, "svelte-72sf5n", b, { hidden: r() === !1 || r() === "hidden" }), I(g, "id", t.elem_id), g.disabled = o(), A = we(g, "", A, {
            "flex-grow": d(),
            width: d() === 0 ? "fit-content" : null,
            "min-width": typeof t.min_width == "number" ? `calc(min(${t.min_width}px, 100%))` : null
          });
        },
        [() => (a() ?? []).join(" ")]
      ), L(y, g);
    };
    D(v, (y) => {
      t.link && t.link.length > 0 ? y(m) : y(c, !1);
    });
  }
  L(e, u), le();
}
U(["click"]);
const ke = (e) => JSON.parse(JSON.stringify(e)), Rr = (e) => e.nodeType === 1, zr = (e) => a0.has(e.tagName), Fr = (e) => "action" in e, Dr = (e) => e.tagName === "IFRAME", Hr = (e) => "formAction" in e, Ur = (e) => "protocol" in e, $ = /* @__PURE__ */ (() => {
  const e = /^(?:\w+script|data):/i;
  return (t) => e.test(t);
})(), Br = /* @__PURE__ */ (() => {
  const e = /(?:script|data):/i;
  return (t) => e.test(t);
})(), jr = (e) => {
  const t = {};
  for (let a = 0, r = e.length; a < r; a++) {
    const n = e[a];
    for (const s in n)
      t[s] ? t[s] = t[s].concat(n[s]) : t[s] = n[s];
  }
  return t;
}, lt = (e, t) => {
  let a = e.firstChild;
  for (; a; ) {
    const r = a.nextSibling;
    Rr(a) && (t(a, e), a.parentNode && lt(a, t)), a = r;
  }
}, Gr = (e, t) => {
  const a = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT);
  let r;
  for (; r = a.nextNode(); ) {
    const n = r.parentNode;
    n && t(r, n);
  }
}, Wr = (e, t) => !!globalThis.document && !!globalThis.document.createNodeIterator ? Gr(e, t) : lt(e, t), dt = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], qr = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Vr = /* @__PURE__ */ new Set([
  ...dt,
  ...qr
]), ut = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Yr = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], Kr = /* @__PURE__ */ new Set([
  ...ut,
  ...Yr
]), ht = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], Jr = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], Xr = /* @__PURE__ */ new Set([
  ...ht,
  ...Jr
]), Zr = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Qr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], $r = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], x = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, e0 = {
  [x.HTML]: Vr,
  [x.SVG]: Kr,
  [x.MATH]: Xr
}, t0 = {
  [x.HTML]: "html",
  [x.SVG]: "svg",
  [x.MATH]: "math"
}, r0 = {
  [x.HTML]: "",
  [x.SVG]: "svg:",
  [x.MATH]: "math:"
}, a0 = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), pt = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...dt,
    ...ut.map((e) => `svg:${e}`),
    ...ht.map((e) => `math:${e}`)
  ],
  allowAttributes: jr([
    Object.fromEntries(Zr.map((e) => [e, ["*"]])),
    Object.fromEntries(Qr.map((e) => [e, ["svg:*"]])),
    Object.fromEntries($r.map((e) => [e, ["math:*"]]))
  ])
};
var ve = function(e, t, a, r, n) {
  if (r === "m") throw new TypeError("Private method is not writable");
  if (r === "a" && !n) throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return r === "a" ? n.call(e, a) : n ? n.value = a : t.set(e, a), a;
}, B = function(e, t, a, r) {
  if (a === "a" && !r) throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return a === "m" ? r : a === "a" ? r.call(e) : r ? r.value : t.get(e);
}, F, ae, ne;
class xe {
  /* CONSTRUCTOR */
  constructor(t = {}) {
    F.set(this, void 0), ae.set(this, void 0), ne.set(this, void 0), this.getConfiguration = () => ke(B(this, F, "f")), this.sanitize = (h) => {
      const u = B(this, ae, "f"), v = B(this, ne, "f");
      return Wr(h, (m, c) => {
        const y = m.namespaceURI || x.HTML, g = c.namespaceURI || x.HTML, b = e0[y], A = t0[y], l = r0[y], p = m.tagName.toLowerCase(), w = `${l}${p}`, _ = `${l}*`;
        if (!b.has(p) || !u.has(w) || y !== g && p !== A)
          c.removeChild(m);
        else {
          const S = m.getAttributeNames(), M = S.length;
          if (M) {
            for (let O = 0; O < M; O++) {
              const X = S[O], de = v[X];
              (!de || !de.has(_) && !de.has(w)) && m.removeAttribute(X);
            }
            if (zr(m))
              if (Ur(m)) {
                const O = m.getAttribute("href");
                O && Br(O) && $(m.protocol) && m.removeAttribute("href");
              } else Fr(m) ? $(m.action) && m.removeAttribute("action") : Hr(m) ? $(m.formAction) && m.removeAttribute("formaction") : Dr(m) && ($(m.src) && m.removeAttribute("formaction"), m.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), h;
    }, this.sanitizeFor = (h, u) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: a, allowCustomElements: r, allowUnknownMarkup: n, blockElements: s, dropElements: f, dropAttributes: i } = t;
    if (a === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (r)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (n)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (s)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (f)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (i)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    ve(this, F, ke(pt), "f");
    const { allowElements: o, allowAttributes: d } = t;
    o && (B(this, F, "f").allowElements = t.allowElements), d && (B(this, F, "f").allowAttributes = t.allowAttributes), ve(this, ae, new Set(B(this, F, "f").allowElements), "f"), ve(this, ne, Object.fromEntries(Object.entries(B(this, F, "f").allowAttributes || {}).map(([h, u]) => [h, new Set(u)])), "f");
  }
}
F = /* @__PURE__ */ new WeakMap(), ae = /* @__PURE__ */ new WeakMap(), ne = /* @__PURE__ */ new WeakMap();
xe.getDefaultConfiguration = () => ke(pt);
const Ae = xe.getDefaultConfiguration();
Ae.allowElements = (Ae.allowElements ?? []).filter((e) => e !== "style" && e !== "svg:style" && e !== "link" && e !== "meta");
new xe(Ae);
U(["touchstart", "touchmove", "touchend", "click", "keydown"]);
var n0 = /* @__PURE__ */ R('<span class="label-text svelte-1iilpd9"> </span>'), s0 = /* @__PURE__ */ R('<label><input type="checkbox" name="test" data-testid="checkbox" class="svelte-1iilpd9"/> <!></label>');
function i0(e, t) {
  ce(t, !0);
  let a = T(t, "label", 3, "Checkbox"), r = T(t, "value", 15), n = T(t, "indeterminate", 7, !1), s = T(t, "interactive", 3, !0), f = T(t, "show_label", 3, !0), i = N(() => !s()), o = ee(se(r()));
  te(() => {
    E(o) !== r() && (J(o, r(), !0), t.on_change?.(tt(r())));
  });
  async function d(g) {
    g.key === "Enter" && (r(!r()), t.on_select?.({
      index: 0,
      value: g.currentTarget.checked,
      selected: g.currentTarget.checked
    }));
  }
  async function h(g) {
    r(g.currentTarget.checked), t.on_select?.({
      index: 0,
      value: g.currentTarget.checked,
      selected: g.currentTarget.checked
    }), t.on_input?.();
  }
  var u = s0();
  let v;
  var m = C(u), c = j(m, 2);
  {
    var y = (g) => {
      var b = n0(), A = C(b);
      P(() => Y(A, a())), L(g, b);
    };
    D(c, (g) => {
      f() && g(y);
    });
  }
  P(() => {
    v = fe(u, 1, "checkbox-container svelte-1iilpd9", null, v, { disabled: E(i) }), m.disabled = E(i);
  }), vr(m, r), gr("indeterminate", "change", m, n, n), _e("keydown", m, d), _e("input", m, h), L(e, u), le();
}
var f0 = /* @__PURE__ */ R('<h3 class="svelte-8sag4p"> </h3>'), o0 = /* @__PURE__ */ R('<div class="item svelte-8sag4p"><!> <span class="size svelte-8sag4p"> </span></div>'), c0 = /* @__PURE__ */ R('<dialog tabindex="-1" closedby="any" class="svelte-8sag4p"><!> <!> <div class="buttons svelte-8sag4p"><!> <!></div></dialog>'), l0 = /* @__PURE__ */ R('<div class="gradio-cleaning svelte-8sag4p"><!></div>');
function u0(e, t) {
  ce(t, !0);
  const a = /* @__PURE__ */ ct(t, ["$$slots", "$$events", "$$legacy"]), r = new Nr(a), n = N(() => r.props.value ?? { items: [], selected: [] });
  function s(u) {
    return u.showModal(), u.focus(), () => document.activeElement?.blur();
  }
  function f(u, v) {
    const m = E(n).selected.filter((c) => c !== u);
    r.props.value = {
      ...E(n),
      selected: v ? [...m, u] : m
    };
  }
  function i(u) {
    const v = r.props.size_base, m = ["kilobyte", "megabyte", "gigabyte", "terabyte"], c = Math.min(Math.max(Math.floor(Math.log(u) / Math.log(v)), 1), m.length);
    return new Intl.NumberFormat(void 0, {
      style: "unit",
      unit: m[c - 1],
      maximumFractionDigits: 1
    }).format(u / v ** c);
  }
  var o = l0(), d = C(o);
  {
    var h = (u) => {
      var v = c0(), m = C(v);
      {
        var c = (l) => {
          var p = f0(), w = C(p);
          P(() => Y(w, r.props.title)), L(l, p);
        };
        D(m, (l) => {
          r.props.title && l(c);
        });
      }
      var y = j(m, 2);
      ir(y, 17, () => E(n).items, (l) => l.id, (l, p) => {
        var w = o0(), k = C(w);
        {
          let M = N(() => E(n).selected.includes(E(p).id)), O = N(() => E(p).size !== null);
          i0(k, {
            get label() {
              return E(p).label;
            },
            get value() {
              return E(M);
            },
            get interactive() {
              return E(O);
            },
            on_change: (X) => f(E(p).id, X)
          });
        }
        var _ = j(k, 2), S = C(_);
        P((M) => Y(S, M), [
          () => E(p).size === null ? "⏳" : i(E(p).size)
        ]), L(l, w);
      });
      var g = j(y, 2), b = C(g);
      qe(b, {
        onclick: () => r.dispatch("close"),
        children: (l, p) => {
          var w = Pe();
          P(() => Y(w, r.props.cancel_label)), L(l, w);
        },
        $$slots: { default: !0 }
      });
      var A = j(b, 2);
      {
        let l = N(() => !E(n).selected.length);
        qe(A, {
          variant: "primary",
          get disabled() {
            return E(l);
          },
          onclick: () => r.dispatch("clean"),
          children: (p, w) => {
            var k = Pe();
            P(() => Y(k, r.props.clean_label)), L(p, k);
          },
          $$slots: { default: !0 }
        });
      }
      at(v, () => s), P(() => I(v, "aria-label", r.props.title)), _e("close", v, () => r.dispatch("close")), L(u, v);
    };
    D(d, (u) => {
      r.shared.visible === !0 && u(h);
    });
  }
  L(e, o), le();
}
export {
  u0 as default
};
