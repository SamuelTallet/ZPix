import { e as I, g as y, i as M, T as x, a as A, c as B, u as U, b as S, r as P, d as N, f as Y, h as _, j as D, k as j, l as q, p as z, P as C, m as G, s as H, D as W, n as F, o as J, q as K, t as Q, v as V, S as X, L as Z, w as $, x as k, y as ee, z as te, A as ne } from "./render-B4ZWyICt.js";
I();
function re(e) {
  var n = document.createElement("template");
  return n.innerHTML = e.replaceAll("<!>", "<!---->"), n.content;
}
function ae(e, n) {
  var r = (
    /** @type {Effect} */
    A
  );
  r.nodes === null && (r.nodes = { start: e, end: n, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function ie(e, n) {
  var r = (n & x) !== 0, t, a = !e.startsWith("<!>");
  return () => {
    t === void 0 && (t = re(a ? e : "<!>" + e), t = /** @type {TemplateNode} */
    y(t));
    var i = (
      /** @type {TemplateNode} */
      r || M ? document.importNode(t, !0) : t.cloneNode(!0)
    );
    return ae(i, i), i;
  };
}
function fe(e, n) {
  e !== null && e.before(
    /** @type {Node} */
    n
  );
}
const O = [...` 	
\r\f \v\uFEFF`];
function le(e, n, r) {
  var t = "" + e;
  if (r) {
    for (var a in r)
      if (r[a])
        t = t ? t + " " + a : a;
      else if (t.length)
        for (var i = a.length, f = 0; (f = t.indexOf(a, f)) >= 0; ) {
          var l = f + i;
          (f === 0 || O.includes(t[f - 1])) && (l === t.length || O.includes(t[l])) ? t = (f === 0 ? "" : t.substring(0, f)) + t.substring(l + 1) : f = l;
        }
  }
  return t === "" ? null : t;
}
function se(e, n, r, t, a, i) {
  var f = e.__className;
  if (f !== r || f === void 0) {
    var l = le(r, t, i);
    l == null ? e.removeAttribute("class") : e.className = l, e.__className = r;
  } else if (i && a !== i)
    for (var u in i) {
      var o = !!i[u];
      (a == null || o !== !!a[u]) && e.classList.toggle(u, o);
    }
  return i;
}
function ue(e = !1) {
  const n = (
    /** @type {ComponentContextLegacy} */
    B
  ), r = n.l.u;
  if (!r) return;
  let t = () => D(n.s);
  if (e) {
    let a = 0, i = (
      /** @type {Record<string, any>} */
      {}
    );
    const f = j(() => {
      let l = !1;
      const u = n.s;
      for (const o in u)
        u[o] !== i[o] && (i[o] = u[o], l = !0);
      return l && a++, a;
    });
    t = () => _(f);
  }
  r.b.length && U(() => {
    T(n, t), P(r.b);
  }), S(() => {
    const a = N(() => r.m.map(Y));
    return () => {
      for (const i of a)
        typeof i == "function" && i();
    };
  }), r.a.length && S(() => {
    T(n, t), P(r.a);
  });
}
function T(e, n) {
  if (e.l.s)
    for (const r of e.l.s) _(r);
  n();
}
let m = !1;
function oe(e) {
  var n = m;
  try {
    return m = !1, [e(), m];
  } finally {
    m = n;
  }
}
function b(e, n, r, t) {
  var a = !F || (r & J) !== 0, i = (r & K) !== 0, f = (
    /** @type {V} */
    t
  ), l = !0, u = () => (l && (l = !1, f = /** @type {V} */
  t), f), o;
  {
    var L = X in e || Z in e;
    o = q(e, n)?.set ?? (L && n in e ? (s) => e[n] = s : void 0);
  }
  var v, p = !1;
  [v, p] = oe(() => (
    /** @type {V} */
    e[n]
  )), v === void 0 && t !== void 0 && (v = u(), o && (a && z(), o(v)));
  var d;
  if (a ? d = () => {
    var s = (
      /** @type {V} */
      e[n]
    );
    return s === void 0 ? u() : (l = !0, s);
  } : d = () => {
    var s = (
      /** @type {V} */
      e[n]
    );
    return s !== void 0 && (f = /** @type {V} */
    void 0), s === void 0 ? f : s;
  }, a && (r & C) === 0)
    return d;
  if (o) {
    var R = e.$$legacy;
    return (
      /** @type {() => V} */
      (function(s, g) {
        return arguments.length > 0 ? ((!a || !g || R || p) && o(g ? d() : s), s) : d();
      })
    );
  }
  var h = !1, c = Q(() => (h = !1, d()));
  _(c);
  var w = (
    /** @type {Effect} */
    A
  );
  return (
    /** @type {() => V} */
    (function(s, g) {
      if (arguments.length > 0) {
        const E = g ? _(c) : a && i ? G(s) : s;
        return H(c, E), h = !0, f !== void 0 && (f = E), s;
      }
      return V && h || (w.f & W) !== 0 ? c.v : _(c);
    })
  );
}
var de = /* @__PURE__ */ ie("<div> </div>");
function _e(e, n) {
  ee(n, !1);
  let r = b(n, "value", 8), t = b(n, "type", 8), a = b(n, "selected", 8, !1);
  ue();
  var i = de();
  let f;
  var l = ne(i);
  $(
    (u) => {
      f = se(i, 1, "svelte-1fzkwf3", null, f, {
        table: t() === "table",
        gallery: t() === "gallery",
        selected: a()
      }), te(l, u);
    },
    [
      () => (D(r()), N(() => r() ? r().items.map((u) => u.label).join(", ") : "—"))
    ]
  ), fe(e, i), k();
}
export {
  _e as default
};
