let je = !1, Ft = !1;
function In() {
  je = !0;
}
const Mn = 2, qn = 4, Ln = 8, Bn = 2, y = /* @__PURE__ */ Symbol(), Re = !1;
var Nt = Array.isArray, Ct = Array.prototype.indexOf, jt = Array.from, It = Object.defineProperty, ce = Object.getOwnPropertyDescriptor, Mt = Object.getOwnPropertyDescriptors, qt = Object.prototype, Lt = Array.prototype, Xe = Object.getPrototypeOf, $e = Object.isExtensible;
function Un(e) {
  return e();
}
function Bt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function et() {
  var e, t, n = new Promise((i, r) => {
    e = i, t = r;
  });
  return { promise: n, resolve: e, reject: t };
}
const w = 2, Pe = 4, ve = 8, tt = 1 << 24, L = 16, H = 32, re = 64, Ie = 128, R = 512, E = 1024, x = 2048, B = 4096, Y = 8192, K = 16384, Me = 32768, Ee = 65536, ze = 1 << 17, nt = 1 << 18, oe = 1 << 19, rt = 1 << 20, te = 32768, Oe = 1 << 21, qe = 1 << 22, $ = 1 << 23, _e = /* @__PURE__ */ Symbol("$state"), Vn = /* @__PURE__ */ Symbol("legacy props"), se = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Ut() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Vt(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function Yt() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function Kt(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function $t() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function Kn(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function zt() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function Gt() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function Ht() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function Wt() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function Zt() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function it(e) {
  return e === this.v;
}
function Jt(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function Qt(e) {
  return !Jt(e, this.v);
}
let T = null;
function le(e) {
  T = e;
}
function Xt(e, t = !1, n) {
  T = {
    p: T,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: je && !t ? { s: null, u: null, $: [] } : null
  };
}
function en(e) {
  var t = (
    /** @type {ComponentContext} */
    T
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var i of n)
      Et(i);
  }
  return t.i = !0, T = t.p, /** @type {T} */
  {};
}
function pe() {
  return !je || T !== null && T.l === null;
}
let fe = [];
function tn() {
  var e = fe;
  fe = [], Bt(e);
}
function Le(e) {
  if (fe.length === 0) {
    var t = fe;
    queueMicrotask(() => {
      t === fe && tn();
    });
  }
  fe.push(e);
}
function st(e) {
  var t = v;
  if (t === null)
    return d.f |= $, e;
  if ((t.f & Me) === 0) {
    if ((t.f & Ie) === 0)
      throw e;
    t.b.error(e);
  } else
    ue(e, t);
}
function ue(e, t) {
  for (; t !== null; ) {
    if ((t.f & Ie) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const nn = -7169;
function m(e, t) {
  e.f = e.f & nn | t;
}
function Be(e) {
  (e.f & R) !== 0 || e.deps === null ? m(e, E) : m(e, B);
}
function ft(e) {
  if (e !== null)
    for (const t of e)
      (t.f & w) === 0 || (t.f & te) === 0 || (t.f ^= te, ft(
        /** @type {Derived} */
        t.deps
      ));
}
function lt(e, t, n) {
  (e.f & x) !== 0 ? t.add(e) : (e.f & B) !== 0 && n.add(e), ft(e.deps), m(e, E);
}
const ye = /* @__PURE__ */ new Set();
let g = null, P = null, F = [], Ue = null, De = !1;
class N {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #_ = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #r = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #f = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #i = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #e = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#f > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    F = [], this.apply();
    var n = [], i = [];
    for (const r of t)
      this.#s(r, n, i);
    this.is_fork || this.#u(), this.is_deferred() ? (this.#l(i), this.#l(n)) : (g = null, Ge(i), Ge(n), this.#i?.resolve()), P = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #s(t, n, i) {
    t.f ^= E;
    for (var r = t.first, s = null; r !== null; ) {
      var u = r.f, l = (u & (H | re)) !== 0, f = l && (u & E) !== 0, o = f || (u & Y) !== 0 || this.skipped_effects.has(r);
      if (!o && r.fn !== null) {
        l ? r.f ^= E : s !== null && (u & (Pe | ve | tt)) !== 0 ? s.b.defer_effect(r) : (u & Pe) !== 0 ? n.push(r) : ge(r) && ((u & L) !== 0 && this.#n.add(r), de(r));
        var a = r.first;
        if (a !== null) {
          r = a;
          continue;
        }
      }
      var h = r.parent;
      for (r = r.next; r === null && h !== null; )
        h === s && (s = null), r = h.next, h = h.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #l(t) {
    for (var n = 0; n < t.length; n += 1)
      lt(t[n], this.#n, this.#e);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== y && !this.previous.has(t) && this.previous.set(t, n), (t.f & $) === 0 && (this.current.set(t, t.v), P?.set(t, t.v));
  }
  activate() {
    g = this, this.apply();
  }
  deactivate() {
    g === this && (g = null, P = null);
  }
  flush() {
    if (this.activate(), F.length > 0) {
      if (rn(), g !== null && g !== this)
        return;
    } else this.#r === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#_) t(this);
    this.#_.clear();
  }
  #u() {
    if (this.#f === 0) {
      for (const t of this.#t) t();
      this.#t.clear();
    }
    this.#r === 0 && this.#o();
  }
  #o() {
    if (ye.size > 1) {
      this.previous.clear();
      var t = P, n = !0;
      for (const r of ye) {
        if (r === this) {
          n = !1;
          continue;
        }
        const s = [];
        for (const [l, f] of this.current) {
          if (r.current.has(l))
            if (n && f !== r.current.get(l))
              r.current.set(l, f);
            else
              continue;
          s.push(l);
        }
        if (s.length === 0)
          continue;
        const u = [...r.current.keys()].filter((l) => !this.current.has(l));
        if (u.length > 0) {
          var i = F;
          F = [];
          const l = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
          for (const o of s)
            ut(o, u, l, f);
          if (F.length > 0) {
            g = r, r.apply();
            for (const o of F)
              r.#s(o, [], []);
            r.deactivate();
          }
          F = i;
        }
      }
      g = null, P = t;
    }
    this.committed = !0, ye.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#r += 1, t && (this.#f += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#r -= 1, t && (this.#f -= 1), this.revive();
  }
  revive() {
    for (const t of this.#n)
      this.#e.delete(t), m(t, x), G(t);
    for (const t of this.#e)
      m(t, B), G(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#t.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#_.add(t);
  }
  settled() {
    return (this.#i ??= et()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new N();
      ye.add(g), N.enqueue(() => {
        g === t && t.flush();
      });
    }
    return g;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Le(t);
  }
  apply() {
  }
}
function rn() {
  var e = X;
  De = !0;
  var t = null;
  try {
    var n = 0;
    for (xe(!0); F.length > 0; ) {
      var i = N.ensure();
      if (n++ > 1e3) {
        var r, s;
        sn();
      }
      i.process(F), z.clear();
    }
  } finally {
    De = !1, xe(e), Ue = null;
  }
}
function sn() {
  try {
    $t();
  } catch (e) {
    ue(e, Ue);
  }
}
let M = null;
function Ge(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var i = e[n++];
      if ((i.f & (K | Y)) === 0 && ge(i) && (M = /* @__PURE__ */ new Set(), de(i), i.deps === null && i.first === null && i.nodes === null && (i.teardown === null && i.ac === null ? xt(i) : i.fn = null), M?.size > 0)) {
        z.clear();
        for (const r of M) {
          if ((r.f & (K | Y)) !== 0) continue;
          const s = [r];
          let u = r.parent;
          for (; u !== null; )
            M.has(u) && (M.delete(u), s.push(u)), u = u.parent;
          for (let l = s.length - 1; l >= 0; l--) {
            const f = s[l];
            (f.f & (K | Y)) === 0 && de(f);
          }
        }
        M.clear();
      }
    }
    M = null;
  }
}
function ut(e, t, n, i) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const r of e.reactions) {
      const s = r.f;
      (s & w) !== 0 ? ut(
        /** @type {Derived} */
        r,
        t,
        n,
        i
      ) : (s & (qe | L)) !== 0 && (s & x) === 0 && ot(r, t, i) && (m(r, x), G(
        /** @type {Effect} */
        r
      ));
    }
}
function ot(e, t, n) {
  const i = n.get(e);
  if (i !== void 0) return i;
  if (e.deps !== null)
    for (const r of e.deps) {
      if (t.includes(r))
        return !0;
      if ((r.f & w) !== 0 && ot(
        /** @type {Derived} */
        r,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          r,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function G(e) {
  for (var t = Ue = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (De && t === v && (n & L) !== 0 && (n & nt) === 0)
      return;
    if ((n & (re | H)) !== 0) {
      if ((n & E) === 0) return;
      t.f ^= E;
    }
  }
  F.push(t);
}
function fn(e) {
  let t = 0, n = ke(0), i;
  return () => {
    Ye() && (Q(n), Sn(() => (t === 0 && (i = Dn(() => e(() => he(n)))), t += 1, () => {
      Le(() => {
        t -= 1, t === 0 && (i?.(), i = void 0, he(n));
      });
    })));
  };
}
var ln = Ee | oe | Ie;
function un(e, t, n) {
  new on(e, t, n);
}
class on {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #_ = null;
  /** @type {BoundaryProps} */
  #r;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #i;
  /** @type {Effect | null} */
  #n = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #s = null;
  /** @type {DocumentFragment | null} */
  #l = null;
  /** @type {TemplateNode | null} */
  #u = null;
  #o = 0;
  #a = 0;
  #h = !1;
  /** @type {Set<Effect>} */
  #d = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #v = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #c = null;
  #m = fn(() => (this.#c = ke(this.#o), () => {
    this.#c = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, n, i) {
    this.#t = t, this.#r = n, this.#f = i, this.parent = /** @type {Effect} */
    v.b, this.is_pending = !!this.#r.pending, this.#i = xn(() => {
      v.b = this;
      {
        var r = this.#y();
        try {
          this.#n = W(() => i(r));
        } catch (s) {
          this.error(s);
        }
        this.#a > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#u?.remove();
      };
    }, ln);
  }
  #E() {
    try {
      this.#n = W(() => this.#f(this.#t));
    } catch (t) {
      this.error(t);
    }
  }
  #b() {
    const t = this.#r.pending;
    t && (this.#e = W(() => t(this.#t)), N.enqueue(() => {
      var n = this.#y();
      this.#n = this.#p(() => (N.ensure(), W(() => this.#f(n)))), this.#a > 0 ? this.#g() : (me(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #y() {
    var t = this.#t;
    return this.is_pending && (this.#u = gt(), this.#t.before(this.#u), t = this.#u), t;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    lt(t, this.#d, this.#v);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#r.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(t) {
    var n = v, i = d, r = T;
    j(this.#i), S(this.#i), le(this.#i.ctx);
    try {
      return t();
    } catch (s) {
      return st(s), null;
    } finally {
      j(n), S(i), le(r);
    }
  }
  #g() {
    const t = (
      /** @type {(anchor: Node) => void} */
      this.#r.pending
    );
    this.#n !== null && (this.#l = document.createDocumentFragment(), this.#l.append(
      /** @type {TemplateNode} */
      this.#u
    ), An(this.#n, this.#l)), this.#e === null && (this.#e = W(() => t(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #w(t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#w(t);
      return;
    }
    if (this.#a += t, this.#a === 0) {
      this.is_pending = !1;
      for (const n of this.#d)
        m(n, x), G(n);
      for (const n of this.#v)
        m(n, B), G(n);
      this.#d.clear(), this.#v.clear(), this.#e && me(this.#e, () => {
        this.#e = null;
      }), this.#l && (this.#t.before(this.#l), this.#l = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    this.#w(t), this.#o += t, this.#c && Se(this.#c, this.#o);
  }
  get_effect_pending() {
    return this.#m(), Q(
      /** @type {Source<number>} */
      this.#c
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#r.onerror;
    let i = this.#r.failed;
    if (this.#h || !n && !i)
      throw t;
    this.#n && (C(this.#n), this.#n = null), this.#e && (C(this.#e), this.#e = null), this.#s && (C(this.#s), this.#s = null);
    var r = !1, s = !1;
    const u = () => {
      if (r) {
        Zt();
        return;
      }
      r = !0, s && Wt(), N.ensure(), this.#o = 0, this.#s !== null && me(this.#s, () => {
        this.#s = null;
      }), this.is_pending = this.has_pending_snippet(), this.#n = this.#p(() => (this.#h = !1, W(() => this.#f(this.#t)))), this.#a > 0 ? this.#g() : this.is_pending = !1;
    };
    var l = d;
    try {
      S(null), s = !0, n?.(t, u), s = !1;
    } catch (f) {
      ue(f, this.#i && this.#i.parent);
    } finally {
      S(l);
    }
    i && Le(() => {
      this.#s = this.#p(() => {
        N.ensure(), this.#h = !0;
        try {
          return W(() => {
            i(
              this.#t,
              () => t,
              () => u
            );
          });
        } catch (f) {
          return ue(
            f,
            /** @type {Effect} */
            this.#i.parent
          ), null;
        } finally {
          this.#h = !1;
        }
      });
    });
  }
}
function an(e, t, n, i) {
  const r = pe() ? at : hn;
  if (n.length === 0 && e.length === 0) {
    i(t.map(r));
    return;
  }
  var s = g, u = (
    /** @type {Effect} */
    v
  ), l = cn();
  function f() {
    Promise.all(n.map((o) => /* @__PURE__ */ _n(o))).then((o) => {
      l();
      try {
        i([...t.map(r), ...o]);
      } catch (a) {
        (u.f & K) === 0 && ue(a, u);
      }
      s?.deactivate(), be();
    }).catch((o) => {
      ue(o, u);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    l();
    try {
      return f();
    } finally {
      s?.deactivate(), be();
    }
  }) : f();
}
function cn() {
  var e = v, t = d, n = T, i = g;
  return function(s = !0) {
    j(e), S(t), le(n), s && i?.activate();
  };
}
function be() {
  j(null), S(null), le(null);
}
// @__NO_SIDE_EFFECTS__
function at(e) {
  var t = w | x, n = d !== null && (d.f & w) !== 0 ? (
    /** @type {Derived} */
    d
  ) : null;
  return v !== null && (v.f |= oe), {
    ctx: T,
    deps: null,
    effects: null,
    equals: it,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      y
    ),
    wv: 0,
    parent: n ?? v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function _n(e, t, n) {
  let i = (
    /** @type {Effect | null} */
    v
  );
  i === null && Ut();
  var r = (
    /** @type {Boundary} */
    i.b
  ), s = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), u = ke(
    /** @type {V} */
    y
  ), l = !d, f = /* @__PURE__ */ new Map();
  return bn(() => {
    var o = et();
    s = o.promise;
    try {
      Promise.resolve(e()).then(o.resolve, o.reject).then(() => {
        a === g && a.committed && a.deactivate(), be();
      });
    } catch (_) {
      o.reject(_), be();
    }
    var a = (
      /** @type {Batch} */
      g
    );
    if (l) {
      var h = r.is_rendered();
      r.update_pending_count(1), a.increment(h), f.get(a)?.reject(se), f.delete(a), f.set(a, o);
    }
    const c = (_, p = void 0) => {
      if (a.activate(), p)
        p !== se && (u.f |= $, Se(u, p));
      else {
        (u.f & $) !== 0 && (u.f ^= $), Se(u, _);
        for (const [D, I] of f) {
          if (f.delete(D), D === a) break;
          I.reject(se);
        }
      }
      l && (r.update_pending_count(-1), a.decrement(h));
    };
    o.promise.then(c, (_) => c(null, _ || "unknown"));
  }), mn(() => {
    for (const o of f.values())
      o.reject(se);
  }), new Promise((o) => {
    function a(h) {
      function c() {
        h === s ? o(u) : a(s);
      }
      h.then(c, c);
    }
    a(s);
  });
}
// @__NO_SIDE_EFFECTS__
function hn(e) {
  const t = /* @__PURE__ */ at(e);
  return t.equals = Qt, t;
}
function ct(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      C(
        /** @type {Effect} */
        t[n]
      );
  }
}
function dn(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & w) === 0)
      return (t.f & K) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Ve(e) {
  var t, n = v;
  j(dn(e));
  try {
    e.f &= ~te, ct(e), t = Pt(e);
  } finally {
    j(n);
  }
  return t;
}
function _t(e) {
  var t = Ve(e);
  if (!e.equals(t) && (e.wv = At(), (!g?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    m(e, E);
    return;
  }
  ne || (P !== null ? (Ye() || g?.is_fork) && P.set(e, t) : Be(e));
}
let Fe = /* @__PURE__ */ new Set();
const z = /* @__PURE__ */ new Map();
let ht = !1;
function ke(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: it,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function V(e, t) {
  const n = ke(e);
  return Rn(n), n;
}
function Z(e, t, n = !1) {
  d !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!O || (d.f & ze) !== 0) && pe() && (d.f & (w | L | qe | ze)) !== 0 && !q?.includes(e) && Ht();
  let i = n ? ae(t) : t;
  return Se(e, i);
}
function Se(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    ne ? z.set(e, t) : z.set(e, n), e.v = t;
    var i = N.ensure();
    if (i.capture(e, n), (e.f & w) !== 0) {
      const r = (
        /** @type {Derived} */
        e
      );
      (e.f & x) !== 0 && Ve(r), Be(r);
    }
    e.wv = At(), dt(e, x), pe() && v !== null && (v.f & E) !== 0 && (v.f & (H | re)) === 0 && (A === null ? Pn([e]) : A.push(e)), !i.is_fork && Fe.size > 0 && !ht && vn();
  }
  return t;
}
function vn() {
  ht = !1;
  var e = X;
  xe(!0);
  const t = Array.from(Fe);
  try {
    for (const n of t)
      (n.f & E) !== 0 && m(n, B), ge(n) && de(n);
  } finally {
    xe(e);
  }
  Fe.clear();
}
function he(e) {
  Z(e, e.v + 1);
}
function dt(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var i = pe(), r = n.length, s = 0; s < r; s++) {
      var u = n[s], l = u.f;
      if (!(!i && u === v)) {
        var f = (l & x) === 0;
        if (f && m(u, t), (l & w) !== 0) {
          var o = (
            /** @type {Derived} */
            u
          );
          P?.delete(o), (l & te) === 0 && (l & R && (u.f |= te), dt(o, B));
        } else f && ((l & L) !== 0 && M !== null && M.add(
          /** @type {Effect} */
          u
        ), G(
          /** @type {Effect} */
          u
        ));
      }
    }
}
function ae(e) {
  if (typeof e != "object" || e === null || _e in e)
    return e;
  const t = Xe(e);
  if (t !== qt && t !== Lt)
    return e;
  var n = /* @__PURE__ */ new Map(), i = Nt(e), r = /* @__PURE__ */ V(0), s = ee, u = (l) => {
    if (ee === s)
      return l();
    var f = d, o = ee;
    S(null), Ze(s);
    var a = l();
    return S(f), Ze(o), a;
  };
  return i && n.set("length", /* @__PURE__ */ V(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(l, f, o) {
        (!("value" in o) || o.configurable === !1 || o.enumerable === !1 || o.writable === !1) && zt();
        var a = n.get(f);
        return a === void 0 ? a = u(() => {
          var h = /* @__PURE__ */ V(o.value);
          return n.set(f, h), h;
        }) : Z(a, o.value, !0), !0;
      },
      deleteProperty(l, f) {
        var o = n.get(f);
        if (o === void 0) {
          if (f in l) {
            const a = u(() => /* @__PURE__ */ V(y));
            n.set(f, a), he(r);
          }
        } else
          Z(o, y), he(r);
        return !0;
      },
      get(l, f, o) {
        if (f === _e)
          return e;
        var a = n.get(f), h = f in l;
        if (a === void 0 && (!h || ce(l, f)?.writable) && (a = u(() => {
          var _ = ae(h ? l[f] : y), p = /* @__PURE__ */ V(_);
          return p;
        }), n.set(f, a)), a !== void 0) {
          var c = Q(a);
          return c === y ? void 0 : c;
        }
        return Reflect.get(l, f, o);
      },
      getOwnPropertyDescriptor(l, f) {
        var o = Reflect.getOwnPropertyDescriptor(l, f);
        if (o && "value" in o) {
          var a = n.get(f);
          a && (o.value = Q(a));
        } else if (o === void 0) {
          var h = n.get(f), c = h?.v;
          if (h !== void 0 && c !== y)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return o;
      },
      has(l, f) {
        if (f === _e)
          return !0;
        var o = n.get(f), a = o !== void 0 && o.v !== y || Reflect.has(l, f);
        if (o !== void 0 || v !== null && (!a || ce(l, f)?.writable)) {
          o === void 0 && (o = u(() => {
            var c = a ? ae(l[f]) : y, _ = /* @__PURE__ */ V(c);
            return _;
          }), n.set(f, o));
          var h = Q(o);
          if (h === y)
            return !1;
        }
        return a;
      },
      set(l, f, o, a) {
        var h = n.get(f), c = f in l;
        if (i && f === "length")
          for (var _ = o; _ < /** @type {Source<number>} */
          h.v; _ += 1) {
            var p = n.get(_ + "");
            p !== void 0 ? Z(p, y) : _ in l && (p = u(() => /* @__PURE__ */ V(y)), n.set(_ + "", p));
          }
        if (h === void 0)
          (!c || ce(l, f)?.writable) && (h = u(() => /* @__PURE__ */ V(void 0)), Z(h, ae(o)), n.set(f, h));
        else {
          c = h.v !== y;
          var D = u(() => ae(o));
          Z(h, D);
        }
        var I = Reflect.getOwnPropertyDescriptor(l, f);
        if (I?.set && I.set.call(a, o), !c) {
          if (i && typeof f == "string") {
            var Ke = (
              /** @type {Source<number>} */
              n.get("length")
            ), Ae = Number(f);
            Number.isInteger(Ae) && Ae >= Ke.v && Z(Ke, Ae + 1);
          }
          he(r);
        }
        return !0;
      },
      ownKeys(l) {
        Q(r);
        var f = Reflect.ownKeys(l).filter((h) => {
          var c = n.get(h);
          return c === void 0 || c.v !== y;
        });
        for (var [o, a] of n)
          a.v !== y && !(o in l) && f.push(o);
        return f;
      },
      setPrototypeOf() {
        Gt();
      }
    }
  );
}
var He, pn, vt, pt;
function gn() {
  if (He === void 0) {
    He = window, pn = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    vt = ce(t, "firstChild").get, pt = ce(t, "nextSibling").get, $e(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), $e(n) && (n.__t = void 0);
  }
}
function gt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function yn(e) {
  return (
    /** @type {TemplateNode | null} */
    vt.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function yt(e) {
  return (
    /** @type {TemplateNode | null} */
    pt.call(e)
  );
}
function $n(e, t) {
  return /* @__PURE__ */ yn(e);
}
function wt(e) {
  var t = d, n = v;
  S(null), j(null);
  try {
    return e();
  } finally {
    S(t), j(n);
  }
}
function mt(e) {
  v === null && (d === null && Kt(), Yt()), ne && Vt();
}
function wn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function U(e, t, n) {
  var i = v;
  i !== null && (i.f & Y) !== 0 && (e |= Y);
  var r = {
    ctx: T,
    deps: null,
    nodes: null,
    f: e | x | R,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: i,
    b: i && i.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      de(r), r.f |= Me;
    } catch (l) {
      throw C(r), l;
    }
  else t !== null && G(r);
  var s = r;
  if (n && s.deps === null && s.teardown === null && s.nodes === null && s.first === s.last && // either `null`, or a singular child
  (s.f & oe) === 0 && (s = s.first, (e & L) !== 0 && (e & Ee) !== 0 && s !== null && (s.f |= Ee)), s !== null && (s.parent = i, i !== null && wn(s, i), d !== null && (d.f & w) !== 0 && (e & re) === 0)) {
    var u = (
      /** @type {Derived} */
      d
    );
    (u.effects ??= []).push(s);
  }
  return r;
}
function Ye() {
  return d !== null && !O;
}
function mn(e) {
  const t = U(ve, null, !1);
  return m(t, E), t.teardown = e, t;
}
function zn(e) {
  mt();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !d && (t & H) !== 0 && (t & Me) === 0;
  if (n) {
    var i = (
      /** @type {ComponentContext} */
      T
    );
    (i.e ??= []).push(e);
  } else
    return Et(e);
}
function Et(e) {
  return U(Pe | rt, e, !1);
}
function Gn(e) {
  return mt(), U(ve | rt, e, !0);
}
function En(e) {
  N.ensure();
  const t = U(re | oe, e, !0);
  return (n = {}) => new Promise((i) => {
    n.outro ? me(t, () => {
      C(t), i(void 0);
    }) : (C(t), i(void 0));
  });
}
function bn(e) {
  return U(qe | oe, e, !0);
}
function Sn(e, t = 0) {
  return U(ve | t, e, !0);
}
function Hn(e, t = [], n = [], i = []) {
  an(i, t, n, (r) => {
    U(ve, () => e(...r.map(Q)), !0);
  });
}
function xn(e, t = 0) {
  var n = U(L | t, e, !0);
  return n;
}
function W(e) {
  return U(H | oe, e, !0);
}
function bt(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = ne, i = d;
    We(!0), S(null);
    try {
      t.call(null);
    } finally {
      We(n), S(i);
    }
  }
}
function St(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const r = n.ac;
    r !== null && wt(() => {
      r.abort(se);
    });
    var i = n.next;
    (n.f & re) !== 0 ? n.parent = null : C(n, t), n = i;
  }
}
function Tn(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & H) === 0 && C(t), t = n;
  }
}
function C(e, t = !0) {
  var n = !1;
  (t || (e.f & nt) !== 0) && e.nodes !== null && e.nodes.end !== null && (kn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), St(e, t && !n), Te(e, 0), m(e, K);
  var i = e.nodes && e.nodes.t;
  if (i !== null)
    for (const s of i)
      s.stop();
  bt(e);
  var r = e.parent;
  r !== null && r.first !== null && xt(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function kn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ yt(e);
    e.remove(), e = n;
  }
}
function xt(e) {
  var t = e.parent, n = e.prev, i = e.next;
  n !== null && (n.next = i), i !== null && (i.prev = n), t !== null && (t.first === e && (t.first = i), t.last === e && (t.last = n));
}
function me(e, t, n = !0) {
  var i = [];
  Tt(e, i, !0);
  var r = () => {
    n && C(e), t && t();
  }, s = i.length;
  if (s > 0) {
    var u = () => --s || r();
    for (var l of i)
      l.out(u);
  } else
    r();
}
function Tt(e, t, n) {
  if ((e.f & Y) === 0) {
    e.f ^= Y;
    var i = e.nodes && e.nodes.t;
    if (i !== null)
      for (const l of i)
        (l.is_global || n) && t.push(l);
    for (var r = e.first; r !== null; ) {
      var s = r.next, u = (r.f & Ee) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (r.f & H) !== 0 && (e.f & L) !== 0;
      Tt(r, t, u ? n : !1), r = s;
    }
  }
}
function An(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, i = e.nodes.end; n !== null; ) {
      var r = n === i ? null : /* @__PURE__ */ yt(n);
      t.append(n), n = r;
    }
}
let X = !1;
function xe(e) {
  X = e;
}
let ne = !1;
function We(e) {
  ne = e;
}
let d = null, O = !1;
function S(e) {
  d = e;
}
let v = null;
function j(e) {
  v = e;
}
let q = null;
function Rn(e) {
  d !== null && (q === null ? q = [e] : q.push(e));
}
let b = null, k = 0, A = null;
function Pn(e) {
  A = e;
}
let kt = 1, J = 0, ee = J;
function Ze(e) {
  ee = e;
}
function At() {
  return ++kt;
}
function ge(e) {
  var t = e.f;
  if ((t & x) !== 0)
    return !0;
  if (t & w && (e.f &= ~te), (t & B) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), i = n.length, r = 0; r < i; r++) {
      var s = n[r];
      if (ge(
        /** @type {Derived} */
        s
      ) && _t(
        /** @type {Derived} */
        s
      ), s.wv > e.wv)
        return !0;
    }
    (t & R) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    P === null && m(e, E);
  }
  return !1;
}
function Rt(e, t, n = !0) {
  var i = e.reactions;
  if (i !== null && !q?.includes(e))
    for (var r = 0; r < i.length; r++) {
      var s = i[r];
      (s.f & w) !== 0 ? Rt(
        /** @type {Derived} */
        s,
        t,
        !1
      ) : t === s && (n ? m(s, x) : (s.f & E) !== 0 && m(s, B), G(
        /** @type {Effect} */
        s
      ));
    }
}
function Pt(e) {
  var t = b, n = k, i = A, r = d, s = q, u = T, l = O, f = ee, o = e.f;
  b = /** @type {null | Value[]} */
  null, k = 0, A = null, d = (o & (H | re)) === 0 ? e : null, q = null, le(e.ctx), O = !1, ee = ++J, e.ac !== null && (wt(() => {
    e.ac.abort(se);
  }), e.ac = null);
  try {
    e.f |= Oe;
    var a = (
      /** @type {Function} */
      e.fn
    ), h = a(), c = e.deps;
    if (b !== null) {
      var _;
      if (Te(e, k), c !== null && k > 0)
        for (c.length = k + b.length, _ = 0; _ < b.length; _++)
          c[k + _] = b[_];
      else
        e.deps = c = b;
      if (Ye() && (e.f & R) !== 0)
        for (_ = k; _ < c.length; _++)
          (c[_].reactions ??= []).push(e);
    } else c !== null && k < c.length && (Te(e, k), c.length = k);
    if (pe() && A !== null && !O && c !== null && (e.f & (w | B | x)) === 0)
      for (_ = 0; _ < /** @type {Source[]} */
      A.length; _++)
        Rt(
          A[_],
          /** @type {Effect} */
          e
        );
    if (r !== null && r !== e) {
      if (J++, r.deps !== null)
        for (let p = 0; p < n; p += 1)
          r.deps[p].rv = J;
      if (t !== null)
        for (const p of t)
          p.rv = J;
      A !== null && (i === null ? i = A : i.push(.../** @type {Source[]} */
      A));
    }
    return (e.f & $) !== 0 && (e.f ^= $), h;
  } catch (p) {
    return st(p);
  } finally {
    e.f ^= Oe, b = t, k = n, A = i, d = r, q = s, le(u), O = l, ee = f;
  }
}
function On(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var i = Ct.call(n, e);
    if (i !== -1) {
      var r = n.length - 1;
      r === 0 ? n = t.reactions = null : (n[i] = n[r], n.pop());
    }
  }
  if (n === null && (t.f & w) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (b === null || !b.includes(t))) {
    var s = (
      /** @type {Derived} */
      t
    );
    (s.f & R) !== 0 && (s.f ^= R, s.f &= ~te), Be(s), ct(s), Te(s, 0);
  }
}
function Te(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var i = t; i < n.length; i++)
      On(e, n[i]);
}
function de(e) {
  var t = e.f;
  if ((t & K) === 0) {
    m(e, E);
    var n = v, i = X;
    v = e, X = !0;
    try {
      (t & (L | tt)) !== 0 ? Tn(e) : St(e), bt(e);
      var r = Pt(e);
      e.teardown = typeof r == "function" ? r : null, e.wv = kt;
      var s;
      Re && Ft && (e.f & x) !== 0 && e.deps;
    } finally {
      X = i, v = n;
    }
  }
}
function Q(e) {
  var t = e.f, n = (t & w) !== 0;
  if (d !== null && !O) {
    var i = v !== null && (v.f & K) !== 0;
    if (!i && !q?.includes(e)) {
      var r = d.deps;
      if ((d.f & Oe) !== 0)
        e.rv < J && (e.rv = J, b === null && r !== null && r[k] === e ? k++ : b === null ? b = [e] : b.push(e));
      else {
        (d.deps ??= []).push(e);
        var s = e.reactions;
        s === null ? e.reactions = [d] : s.includes(d) || s.push(d);
      }
    }
  }
  if (ne && z.has(e))
    return z.get(e);
  if (n) {
    var u = (
      /** @type {Derived} */
      e
    );
    if (ne) {
      var l = u.v;
      return ((u.f & E) === 0 && u.reactions !== null || Dt(u)) && (l = Ve(u)), z.set(u, l), l;
    }
    var f = (u.f & R) === 0 && !O && d !== null && (X || (d.f & R) !== 0), o = u.deps === null;
    ge(u) && (f && (u.f |= R), _t(u)), f && !o && Ot(u);
  }
  if (P?.has(e))
    return P.get(e);
  if ((e.f & $) !== 0)
    throw e.v;
  return e.v;
}
function Ot(e) {
  if (e.deps !== null) {
    e.f |= R;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & w) !== 0 && (t.f & R) === 0 && Ot(
        /** @type {Derived} */
        t
      );
  }
}
function Dt(e) {
  if (e.v === y) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (z.has(t) || (t.f & w) !== 0 && Dt(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Dn(e) {
  var t = O;
  try {
    return O = !0, e();
  } finally {
    O = t;
  }
}
function Wn(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (_e in e)
      Ne(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const n = e[t];
        typeof n == "object" && n && _e in n && Ne(n);
      }
  }
}
function Ne(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let i in e)
      try {
        Ne(e[i], t);
      } catch {
      }
    const n = Xe(e);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const i = Mt(n);
      for (let r in i) {
        const s = i[r].get;
        if (s)
          try {
            s.call(e);
          } catch {
          }
      }
    }
  }
}
const Fn = ["touchstart", "touchmove"];
function Nn(e) {
  return Fn.includes(e);
}
const Cn = /* @__PURE__ */ new Set(), Je = /* @__PURE__ */ new Set();
let Qe = null;
function we(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), i = e.type, r = e.composedPath?.() || [], s = (
    /** @type {null | Element} */
    r[0] || e.target
  );
  Qe = e;
  var u = 0, l = Qe === e && e.__root;
  if (l) {
    var f = r.indexOf(l);
    if (f !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var o = r.indexOf(t);
    if (o === -1)
      return;
    f <= o && (u = f);
  }
  if (s = /** @type {Element} */
  r[u] || e.target, s !== t) {
    It(e, "currentTarget", {
      configurable: !0,
      get() {
        return s || n;
      }
    });
    var a = d, h = v;
    S(null), j(null);
    try {
      for (var c, _ = []; s !== null; ) {
        var p = s.assignedSlot || s.parentNode || /** @type {any} */
        s.host || null;
        try {
          var D = s["__" + i];
          D != null && (!/** @type {any} */
          s.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === s) && D.call(s, e);
        } catch (I) {
          c ? _.push(I) : c = I;
        }
        if (e.cancelBubble || p === t || p === null)
          break;
        s = p;
      }
      if (c) {
        for (let I of _)
          queueMicrotask(() => {
            throw I;
          });
        throw c;
      }
    } finally {
      e.__root = t, delete e.currentTarget, S(a), j(h);
    }
  }
}
function Zn(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
function Jn(e, t) {
  return jn(e, t);
}
const ie = /* @__PURE__ */ new Map();
function jn(e, { target: t, anchor: n, props: i = {}, events: r, context: s, intro: u = !0 }) {
  gn();
  var l = /* @__PURE__ */ new Set(), f = (h) => {
    for (var c = 0; c < h.length; c++) {
      var _ = h[c];
      if (!l.has(_)) {
        l.add(_);
        var p = Nn(_);
        t.addEventListener(_, we, { passive: p });
        var D = ie.get(_);
        D === void 0 ? (document.addEventListener(_, we, { passive: p }), ie.set(_, 1)) : ie.set(_, D + 1);
      }
    }
  };
  f(jt(Cn)), Je.add(f);
  var o = void 0, a = En(() => {
    var h = n ?? t.appendChild(gt());
    return un(
      /** @type {TemplateNode} */
      h,
      {
        pending: () => {
        }
      },
      (c) => {
        if (s) {
          Xt({});
          var _ = (
            /** @type {ComponentContext} */
            T
          );
          _.c = s;
        }
        r && (i.$$events = r), o = e(c, i) || {}, s && en();
      }
    ), () => {
      for (var c of l) {
        t.removeEventListener(c, we);
        var _ = (
          /** @type {number} */
          ie.get(c)
        );
        --_ === 0 ? (document.removeEventListener(c, we), ie.delete(c)) : ie.set(c, _);
      }
      Je.delete(f), h !== n && h.parentNode?.removeChild(h);
    };
  });
  return Ce.set(o, a), o;
}
let Ce = /* @__PURE__ */ new WeakMap();
function Qn(e, t) {
  const n = Ce.get(e);
  return n ? (Ce.delete(e), n(t)) : Promise.resolve();
}
export {
  $n as A,
  Jn as B,
  Qn as C,
  K as D,
  Vn as L,
  qn as P,
  _e as S,
  Bn as T,
  v as a,
  zn as b,
  T as c,
  Dn as d,
  In as e,
  Un as f,
  yn as g,
  Q as h,
  pn as i,
  Wn as j,
  at as k,
  ce as l,
  ae as m,
  je as n,
  Mn as o,
  Kn as p,
  Ln as q,
  Bt as r,
  Z as s,
  hn as t,
  Gn as u,
  ne as v,
  Hn as w,
  en as x,
  Xt as y,
  Zn as z
};
