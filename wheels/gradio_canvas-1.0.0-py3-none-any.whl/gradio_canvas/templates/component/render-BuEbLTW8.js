const Yn = 1, Gn = 2, $n = 4, Kn = 8, zn = 16, Wn = 1, Zn = 2, Xn = 4, Jn = 8, Qn = 16, er = 1, tr = 2, E = /* @__PURE__ */ Symbol(), nr = "http://www.w3.org/1999/xhtml", rr = "http://www.w3.org/2000/svg", sr = "@attach", De = !1;
var Yt = Array.isArray, Gt = Array.prototype.indexOf, $t = Array.from, Kt = Object.defineProperty, ve = Object.getOwnPropertyDescriptor, zt = Object.getOwnPropertyDescriptors, Wt = Object.prototype, Zt = Array.prototype, lt = Object.getPrototypeOf, Qe = Object.isExtensible;
function ir(e) {
  return typeof e == "function";
}
const fr = () => {
};
function lr(e) {
  return e();
}
function Xt(e) {
  for (var t = 0; t < e.length; t++)
    e[t]();
}
function at() {
  var e, t, n = new Promise((r, s) => {
    e = r, t = s;
  });
  return { promise: n, resolve: e, reject: t };
}
const m = 2, Ae = 4, we = 8, Be = 1 << 24, H = 16, Y = 32, ie = 64, Ue = 128, P = 512, b = 1024, T = 2048, j = 4096, M = 8192, z = 16384, He = 32768, ye = 65536, et = 1 << 17, ut = 1 << 18, ce = 1 << 19, ot = 1 << 20, ar = 1 << 25, re = 32768, Me = 1 << 21, Ye = 1 << 22, W = 1 << 23, ee = /* @__PURE__ */ Symbol("$state"), ur = /* @__PURE__ */ Symbol("legacy props"), or = /* @__PURE__ */ Symbol(""), le = new class extends Error {
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function Jt() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
function Qt(e) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
function en() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
function tn(e) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
function nn() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
function _r(e) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
function rn() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
function sn() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
function fn() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
function ln() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
function hr() {
  console.warn("https://svelte.dev/e/select_multiple_invalid_value");
}
function an() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
function ct(e) {
  return e === this.v;
}
function un(e, t) {
  return e != e ? t == t : e !== t || e !== null && typeof e == "object" || typeof e == "function";
}
function _t(e) {
  return !un(e, this.v);
}
let Pe = !1, on = !1;
function dr() {
  Pe = !0;
}
let y = null;
function ae(e) {
  y = e;
}
function cn(e, t = !1, n) {
  y = {
    p: y,
    i: !1,
    c: null,
    e: null,
    s: e,
    x: null,
    l: Pe && !t ? { s: null, u: null, $: [] } : null
  };
}
function _n(e) {
  var t = (
    /** @type {ComponentContext} */
    y
  ), n = t.e;
  if (n !== null) {
    t.e = null;
    for (var r of n)
      Ct(r);
  }
  return t.i = !0, y = t.p, /** @type {T} */
  {};
}
function Ee() {
  return !Pe || y !== null && y.l === null;
}
let J = [];
function ht() {
  var e = J;
  J = [], Xt(e);
}
function Ce(e) {
  if (J.length === 0 && !pe) {
    var t = J;
    queueMicrotask(() => {
      t === J && ht();
    });
  }
  J.push(e);
}
function hn() {
  for (; J.length > 0; )
    ht();
}
function dt(e) {
  var t = v;
  if (t === null)
    return d.f |= W, e;
  if ((t.f & He) === 0) {
    if ((t.f & Ue) === 0)
      throw e;
    t.b.error(e);
  } else
    ue(e, t);
}
function ue(e, t) {
  for (; t !== null; ) {
    if ((t.f & Ue) !== 0)
      try {
        t.b.error(e);
        return;
      } catch (n) {
        e = n;
      }
    t = t.parent;
  }
  throw e;
}
const dn = -7169;
function w(e, t) {
  e.f = e.f & dn | t;
}
function Ge(e) {
  (e.f & P) !== 0 || e.deps === null ? w(e, b) : w(e, j);
}
function vt(e) {
  if (e !== null)
    for (const t of e)
      (t.f & m) === 0 || (t.f & re) === 0 || (t.f ^= re, vt(
        /** @type {Derived} */
        t.deps
      ));
}
function pt(e, t, n) {
  (e.f & T) !== 0 ? t.add(e) : (e.f & j) !== 0 && n.add(e), vt(e.deps), w(e, b);
}
const me = /* @__PURE__ */ new Set();
let g = null, C = null, R = [], Oe = null, Fe = !1, pe = !1;
class D {
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #t = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #_ = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #r = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #f = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #s = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #e = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#f > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(t) {
    R = [], this.apply();
    var n = [], r = [];
    for (const s of t)
      this.#i(s, n, r);
    this.is_fork || this.#a(), this.is_deferred() ? (this.#l(r), this.#l(n)) : (g = null, tt(r), tt(n), this.#s?.resolve()), C = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #i(t, n, r) {
    t.f ^= b;
    for (var s = t.first, i = null; s !== null; ) {
      var l = s.f, a = (l & (Y | ie)) !== 0, f = a && (l & b) !== 0, u = f || (l & M) !== 0 || this.skipped_effects.has(s);
      if (!u && s.fn !== null) {
        a ? s.f ^= b : i !== null && (l & (Ae | we | Be)) !== 0 ? i.b.defer_effect(s) : (l & Ae) !== 0 ? n.push(s) : _e(s) && ((l & H) !== 0 && this.#n.add(s), oe(s));
        var o = s.first;
        if (o !== null) {
          s = o;
          continue;
        }
      }
      var h = s.parent;
      for (s = s.next; s === null && h !== null; )
        h === i && (i = null), s = h.next, h = h.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #l(t) {
    for (var n = 0; n < t.length; n += 1)
      pt(t[n], this.#n, this.#e);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(t, n) {
    n !== E && !this.previous.has(t) && this.previous.set(t, n), (t.f & W) === 0 && (this.current.set(t, t.v), C?.set(t, t.v));
  }
  activate() {
    g = this, this.apply();
  }
  deactivate() {
    g === this && (g = null, C = null);
  }
  flush() {
    if (this.activate(), R.length > 0) {
      if (gt(), g !== null && g !== this)
        return;
    } else this.#r === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const t of this.#_) t(this);
    this.#_.clear();
  }
  #a() {
    if (this.#f === 0) {
      for (const t of this.#t) t();
      this.#t.clear();
    }
    this.#r === 0 && this.#u();
  }
  #u() {
    if (me.size > 1) {
      this.previous.clear();
      var t = C, n = !0;
      for (const s of me) {
        if (s === this) {
          n = !1;
          continue;
        }
        const i = [];
        for (const [a, f] of this.current) {
          if (s.current.has(a))
            if (n && f !== s.current.get(a))
              s.current.set(a, f);
            else
              continue;
          i.push(a);
        }
        if (i.length === 0)
          continue;
        const l = [...s.current.keys()].filter((a) => !this.current.has(a));
        if (l.length > 0) {
          var r = R;
          R = [];
          const a = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map();
          for (const u of i)
            yt(u, l, a, f);
          if (R.length > 0) {
            g = s, s.apply();
            for (const u of R)
              s.#i(u, [], []);
            s.deactivate();
          }
          R = r;
        }
      }
      g = null, C = t;
    }
    this.committed = !0, me.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(t) {
    this.#r += 1, t && (this.#f += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(t) {
    this.#r -= 1, t && (this.#f -= 1), this.revive();
  }
  revive() {
    for (const t of this.#n)
      this.#e.delete(t), w(t, T), U(t);
    for (const t of this.#e)
      w(t, j), U(t);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(t) {
    this.#t.add(t);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(t) {
    this.#_.add(t);
  }
  settled() {
    return (this.#s ??= at()).promise;
  }
  static ensure() {
    if (g === null) {
      const t = g = new D();
      me.add(g), pe || D.enqueue(() => {
        g === t && t.flush();
      });
    }
    return g;
  }
  /** @param {() => void} task */
  static enqueue(t) {
    Ce(t);
  }
  apply() {
  }
}
function vn(e) {
  var t = pe;
  pe = !0;
  try {
    for (var n; ; ) {
      if (hn(), R.length === 0 && (g?.flush(), R.length === 0))
        return Oe = null, /** @type {T} */
        n;
      gt();
    }
  } finally {
    pe = t;
  }
}
function gt() {
  var e = te;
  Fe = !0;
  var t = null;
  try {
    var n = 0;
    for (ke(!0); R.length > 0; ) {
      var r = D.ensure();
      if (n++ > 1e3) {
        var s, i;
        pn();
      }
      r.process(R), Z.clear();
    }
  } finally {
    Fe = !1, ke(e), Oe = null;
  }
}
function pn() {
  try {
    nn();
  } catch (e) {
    ue(e, Oe);
  }
}
let V = null;
function tt(e) {
  var t = e.length;
  if (t !== 0) {
    for (var n = 0; n < t; ) {
      var r = e[n++];
      if ((r.f & (z | M)) === 0 && _e(r) && (V = /* @__PURE__ */ new Set(), oe(r), r.deps === null && r.first === null && r.nodes === null && (r.teardown === null && r.ac === null ? It(r) : r.fn = null), V?.size > 0)) {
        Z.clear();
        for (const s of V) {
          if ((s.f & (z | M)) !== 0) continue;
          const i = [s];
          let l = s.parent;
          for (; l !== null; )
            V.has(l) && (V.delete(l), i.push(l)), l = l.parent;
          for (let a = i.length - 1; a >= 0; a--) {
            const f = i[a];
            (f.f & (z | M)) === 0 && oe(f);
          }
        }
        V.clear();
      }
    }
    V = null;
  }
}
function yt(e, t, n, r) {
  if (!n.has(e) && (n.add(e), e.reactions !== null))
    for (const s of e.reactions) {
      const i = s.f;
      (i & m) !== 0 ? yt(
        /** @type {Derived} */
        s,
        t,
        n,
        r
      ) : (i & (Ye | H)) !== 0 && (i & T) === 0 && wt(s, t, r) && (w(s, T), U(
        /** @type {Effect} */
        s
      ));
    }
}
function wt(e, t, n) {
  const r = n.get(e);
  if (r !== void 0) return r;
  if (e.deps !== null)
    for (const s of e.deps) {
      if (t.includes(s))
        return !0;
      if ((s.f & m) !== 0 && wt(
        /** @type {Derived} */
        s,
        t,
        n
      ))
        return n.set(
          /** @type {Derived} */
          s,
          !0
        ), !0;
    }
  return n.set(e, !1), !1;
}
function U(e) {
  for (var t = Oe = e; t.parent !== null; ) {
    t = t.parent;
    var n = t.f;
    if (Fe && t === v && (n & H) !== 0 && (n & ut) === 0)
      return;
    if ((n & (ie | Y)) !== 0) {
      if ((n & b) === 0) return;
      t.f ^= b;
    }
  }
  R.push(t);
}
function gn(e) {
  let t = 0, n = be(0), r;
  return () => {
    We() && (K(n), Ze(() => (t === 0 && (r = Xe(() => e(() => ge(n)))), t += 1, () => {
      Ce(() => {
        t -= 1, t === 0 && (r?.(), r = void 0, ge(n));
      });
    })));
  };
}
var yn = ye | ce | Ue;
function wn(e, t, n) {
  new En(e, t, n);
}
class En {
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #t;
  /** @type {TemplateNode | null} */
  #_ = null;
  /** @type {BoundaryProps} */
  #r;
  /** @type {((anchor: Node) => void)} */
  #f;
  /** @type {Effect} */
  #s;
  /** @type {Effect | null} */
  #n = null;
  /** @type {Effect | null} */
  #e = null;
  /** @type {Effect | null} */
  #i = null;
  /** @type {DocumentFragment | null} */
  #l = null;
  /** @type {TemplateNode | null} */
  #a = null;
  #u = 0;
  #o = 0;
  #h = !1;
  /** @type {Set<Effect>} */
  #d = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #v = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #c = null;
  #E = gn(() => (this.#c = be(this.#u), () => {
    this.#c = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(t, n, r) {
    this.#t = t, this.#r = n, this.#f = r, this.parent = /** @type {Effect} */
    v.b, this.is_pending = !!this.#r.pending, this.#s = Nn(() => {
      v.b = this;
      {
        var s = this.#y();
        try {
          this.#n = X(() => r(s));
        } catch (i) {
          this.error(i);
        }
        this.#o > 0 ? this.#g() : this.is_pending = !1;
      }
      return () => {
        this.#a?.remove();
      };
    }, yn);
  }
  #b() {
    try {
      this.#n = X(() => this.#f(this.#t));
    } catch (t) {
      this.error(t);
    }
  }
  #m() {
    const t = this.#r.pending;
    t && (this.#e = X(() => t(this.#t)), D.enqueue(() => {
      var n = this.#y();
      this.#n = this.#p(() => (D.ensure(), X(() => this.#f(n)))), this.#o > 0 ? this.#g() : (Te(
        /** @type {Effect} */
        this.#e,
        () => {
          this.#e = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #y() {
    var t = this.#t;
    return this.is_pending && (this.#a = xt(), this.#t.before(this.#a), t = this.#a), t;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(t) {
    pt(t, this.#d, this.#v);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#r.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #p(t) {
    var n = v, r = d, s = y;
    L(this.#s), S(this.#s), ae(this.#s.ctx);
    try {
      return t();
    } catch (i) {
      return dt(i), null;
    } finally {
      L(n), S(r), ae(s);
    }
  }
  #g() {
    const t = (
      /** @type {(anchor: Node) => void} */
      this.#r.pending
    );
    this.#n !== null && (this.#l = document.createDocumentFragment(), this.#l.append(
      /** @type {TemplateNode} */
      this.#a
    ), Mn(this.#n, this.#l)), this.#e === null && (this.#e = X(() => t(this.#t)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #w(t) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#w(t);
      return;
    }
    if (this.#o += t, this.#o === 0) {
      this.is_pending = !1;
      for (const n of this.#d)
        w(n, T), U(n);
      for (const n of this.#v)
        w(n, j), U(n);
      this.#d.clear(), this.#v.clear(), this.#e && Te(this.#e, () => {
        this.#e = null;
      }), this.#l && (this.#t.before(this.#l), this.#l = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(t) {
    this.#w(t), this.#u += t, this.#c && xe(this.#c, this.#u);
  }
  get_effect_pending() {
    return this.#E(), K(
      /** @type {Source<number>} */
      this.#c
    );
  }
  /** @param {unknown} error */
  error(t) {
    var n = this.#r.onerror;
    let r = this.#r.failed;
    if (this.#h || !n && !r)
      throw t;
    this.#n && (F(this.#n), this.#n = null), this.#e && (F(this.#e), this.#e = null), this.#i && (F(this.#i), this.#i = null);
    var s = !1, i = !1;
    const l = () => {
      if (s) {
        an();
        return;
      }
      s = !0, i && ln(), D.ensure(), this.#u = 0, this.#i !== null && Te(this.#i, () => {
        this.#i = null;
      }), this.is_pending = this.has_pending_snippet(), this.#n = this.#p(() => (this.#h = !1, X(() => this.#f(this.#t)))), this.#o > 0 ? this.#g() : this.is_pending = !1;
    };
    var a = d;
    try {
      S(null), i = !0, n?.(t, l), i = !1;
    } catch (f) {
      ue(f, this.#s && this.#s.parent);
    } finally {
      S(a);
    }
    r && Ce(() => {
      this.#i = this.#p(() => {
        D.ensure(), this.#h = !0;
        try {
          return X(() => {
            r(
              this.#t,
              () => t,
              () => l
            );
          });
        } catch (f) {
          return ue(
            f,
            /** @type {Effect} */
            this.#s.parent
          ), null;
        } finally {
          this.#h = !1;
        }
      });
    });
  }
}
function bn(e, t, n, r) {
  const s = Ee() ? $e : An;
  if (n.length === 0 && e.length === 0) {
    r(t.map(s));
    return;
  }
  var i = g, l = (
    /** @type {Effect} */
    v
  ), a = mn();
  function f() {
    Promise.all(n.map((u) => /* @__PURE__ */ Tn(u))).then((u) => {
      a();
      try {
        r([...t.map(s), ...u]);
      } catch (o) {
        (l.f & z) === 0 && ue(o, l);
      }
      i?.deactivate(), Se();
    }).catch((u) => {
      ue(u, l);
    });
  }
  e.length > 0 ? Promise.all(e).then(() => {
    a();
    try {
      return f();
    } finally {
      i?.deactivate(), Se();
    }
  }) : f();
}
function mn() {
  var e = v, t = d, n = y, r = g;
  return function(i = !0) {
    L(e), S(t), ae(n), i && r?.activate();
  };
}
function Se() {
  L(null), S(null), ae(null);
}
// @__NO_SIDE_EFFECTS__
function $e(e) {
  var t = m | T, n = d !== null && (d.f & m) !== 0 ? (
    /** @type {Derived} */
    d
  ) : null;
  return v !== null && (v.f |= ce), {
    ctx: y,
    deps: null,
    effects: null,
    equals: ct,
    f: t,
    fn: e,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      E
    ),
    wv: 0,
    parent: n ?? v,
    ac: null
  };
}
// @__NO_SIDE_EFFECTS__
function Tn(e, t, n) {
  let r = (
    /** @type {Effect | null} */
    v
  );
  r === null && Jt();
  var s = (
    /** @type {Boundary} */
    r.b
  ), i = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), l = be(
    /** @type {V} */
    E
  ), a = !d, f = /* @__PURE__ */ new Map();
  return On(() => {
    var u = at();
    i = u.promise;
    try {
      Promise.resolve(e()).then(u.resolve, u.reject).then(() => {
        o === g && o.committed && o.deactivate(), Se();
      });
    } catch (_) {
      u.reject(_), Se();
    }
    var o = (
      /** @type {Batch} */
      g
    );
    if (a) {
      var h = s.is_rendered();
      s.update_pending_count(1), o.increment(h), f.get(o)?.reject(le), f.delete(o), f.set(o, u);
    }
    const c = (_, p = void 0) => {
      if (o.activate(), p)
        p !== le && (l.f |= W, xe(l, p));
      else {
        (l.f & W) !== 0 && (l.f ^= W), xe(l, _);
        for (const [I, q] of f) {
          if (f.delete(I), I === o) break;
          q.reject(le);
        }
      }
      a && (s.update_pending_count(-1), o.decrement(h));
    };
    u.promise.then(c, (_) => c(null, _ || "unknown"));
  }), Pt(() => {
    for (const u of f.values())
      u.reject(le);
  }), new Promise((u) => {
    function o(h) {
      function c() {
        h === i ? u(l) : o(i);
      }
      h.then(c, c);
    }
    o(i);
  });
}
// @__NO_SIDE_EFFECTS__
function vr(e) {
  const t = /* @__PURE__ */ $e(e);
  return Ft(t), t;
}
// @__NO_SIDE_EFFECTS__
function An(e) {
  const t = /* @__PURE__ */ $e(e);
  return t.equals = _t, t;
}
function Et(e) {
  var t = e.effects;
  if (t !== null) {
    e.effects = null;
    for (var n = 0; n < t.length; n += 1)
      F(
        /** @type {Effect} */
        t[n]
      );
  }
}
function Sn(e) {
  for (var t = e.parent; t !== null; ) {
    if ((t.f & m) === 0)
      return (t.f & z) === 0 ? (
        /** @type {Effect} */
        t
      ) : null;
    t = t.parent;
  }
  return null;
}
function Ke(e) {
  var t, n = v;
  L(Sn(e));
  try {
    e.f &= ~re, Et(e), t = Vt(e);
  } finally {
    L(n);
  }
  return t;
}
function bt(e) {
  var t = Ke(e);
  if (!e.equals(t) && (e.wv = jt(), (!g?.is_fork || e.deps === null) && (e.v = t, e.deps === null))) {
    w(e, b);
    return;
  }
  se || (C !== null ? (We() || g?.is_fork) && C.set(e, t) : Ge(e));
}
let Le = /* @__PURE__ */ new Set();
const Z = /* @__PURE__ */ new Map();
let mt = !1;
function be(e, t) {
  var n = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v: e,
    reactions: null,
    equals: ct,
    rv: 0,
    wv: 0
  };
  return n;
}
// @__NO_SIDE_EFFECTS__
function G(e, t) {
  const n = be(e);
  return Ft(n), n;
}
// @__NO_SIDE_EFFECTS__
function pr(e, t = !1, n = !0) {
  const r = be(e);
  return t || (r.equals = _t), Pe && n && y !== null && y.l !== null && (y.l.s ??= []).push(r), r;
}
function gr(e, t) {
  return $(
    e,
    Xe(() => K(e))
  ), t;
}
function $(e, t, n = !1) {
  d !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!O || (d.f & et) !== 0) && Ee() && (d.f & (m | H | Ye | et)) !== 0 && !B?.includes(e) && fn();
  let r = n ? he(t) : t;
  return xe(e, r);
}
function xe(e, t) {
  if (!e.equals(t)) {
    var n = e.v;
    se ? Z.set(e, t) : Z.set(e, n), e.v = t;
    var r = D.ensure();
    if (r.capture(e, n), (e.f & m) !== 0) {
      const s = (
        /** @type {Derived} */
        e
      );
      (e.f & T) !== 0 && Ke(s), Ge(s);
    }
    e.wv = jt(), Tt(e, T), Ee() && v !== null && (v.f & b) !== 0 && (v.f & (Y | ie)) === 0 && (k === null ? Fn([e]) : k.push(e)), !r.is_fork && Le.size > 0 && !mt && xn();
  }
  return t;
}
function xn() {
  mt = !1;
  var e = te;
  ke(!0);
  const t = Array.from(Le);
  try {
    for (const n of t)
      (n.f & b) !== 0 && w(n, j), _e(n) && oe(n);
  } finally {
    ke(e);
  }
  Le.clear();
}
function ge(e) {
  $(e, e.v + 1);
}
function Tt(e, t) {
  var n = e.reactions;
  if (n !== null)
    for (var r = Ee(), s = n.length, i = 0; i < s; i++) {
      var l = n[i], a = l.f;
      if (!(!r && l === v)) {
        var f = (a & T) === 0;
        if (f && w(l, t), (a & m) !== 0) {
          var u = (
            /** @type {Derived} */
            l
          );
          C?.delete(u), (a & re) === 0 && (a & P && (l.f |= re), Tt(u, j));
        } else f && ((a & H) !== 0 && V !== null && V.add(
          /** @type {Effect} */
          l
        ), U(
          /** @type {Effect} */
          l
        ));
      }
    }
}
function he(e) {
  if (typeof e != "object" || e === null || ee in e)
    return e;
  const t = lt(e);
  if (t !== Wt && t !== Zt)
    return e;
  var n = /* @__PURE__ */ new Map(), r = Yt(e), s = /* @__PURE__ */ G(0), i = ne, l = (a) => {
    if (ne === i)
      return a();
    var f = d, u = ne;
    S(null), it(i);
    var o = a();
    return S(f), it(u), o;
  };
  return r && n.set("length", /* @__PURE__ */ G(
    /** @type {any[]} */
    e.length
  )), new Proxy(
    /** @type {any} */
    e,
    {
      defineProperty(a, f, u) {
        (!("value" in u) || u.configurable === !1 || u.enumerable === !1 || u.writable === !1) && rn();
        var o = n.get(f);
        return o === void 0 ? o = l(() => {
          var h = /* @__PURE__ */ G(u.value);
          return n.set(f, h), h;
        }) : $(o, u.value, !0), !0;
      },
      deleteProperty(a, f) {
        var u = n.get(f);
        if (u === void 0) {
          if (f in a) {
            const o = l(() => /* @__PURE__ */ G(E));
            n.set(f, o), ge(s);
          }
        } else
          $(u, E), ge(s);
        return !0;
      },
      get(a, f, u) {
        if (f === ee)
          return e;
        var o = n.get(f), h = f in a;
        if (o === void 0 && (!h || ve(a, f)?.writable) && (o = l(() => {
          var _ = he(h ? a[f] : E), p = /* @__PURE__ */ G(_);
          return p;
        }), n.set(f, o)), o !== void 0) {
          var c = K(o);
          return c === E ? void 0 : c;
        }
        return Reflect.get(a, f, u);
      },
      getOwnPropertyDescriptor(a, f) {
        var u = Reflect.getOwnPropertyDescriptor(a, f);
        if (u && "value" in u) {
          var o = n.get(f);
          o && (u.value = K(o));
        } else if (u === void 0) {
          var h = n.get(f), c = h?.v;
          if (h !== void 0 && c !== E)
            return {
              enumerable: !0,
              configurable: !0,
              value: c,
              writable: !0
            };
        }
        return u;
      },
      has(a, f) {
        if (f === ee)
          return !0;
        var u = n.get(f), o = u !== void 0 && u.v !== E || Reflect.has(a, f);
        if (u !== void 0 || v !== null && (!o || ve(a, f)?.writable)) {
          u === void 0 && (u = l(() => {
            var c = o ? he(a[f]) : E, _ = /* @__PURE__ */ G(c);
            return _;
          }), n.set(f, u));
          var h = K(u);
          if (h === E)
            return !1;
        }
        return o;
      },
      set(a, f, u, o) {
        var h = n.get(f), c = f in a;
        if (r && f === "length")
          for (var _ = u; _ < /** @type {Source<number>} */
          h.v; _ += 1) {
            var p = n.get(_ + "");
            p !== void 0 ? $(p, E) : _ in a && (p = l(() => /* @__PURE__ */ G(E)), n.set(_ + "", p));
          }
        if (h === void 0)
          (!c || ve(a, f)?.writable) && (h = l(() => /* @__PURE__ */ G(void 0)), $(h, he(u)), n.set(f, h));
        else {
          c = h.v !== E;
          var I = l(() => he(u));
          $(h, I);
        }
        var q = Reflect.getOwnPropertyDescriptor(a, f);
        if (q?.set && q.set.call(o, u), !c) {
          if (r && typeof f == "string") {
            var Je = (
              /** @type {Source<number>} */
              n.get("length")
            ), Ie = Number(f);
            Number.isInteger(Ie) && Ie >= Je.v && $(Je, Ie + 1);
          }
          ge(s);
        }
        return !0;
      },
      ownKeys(a) {
        K(s);
        var f = Reflect.ownKeys(a).filter((h) => {
          var c = n.get(h);
          return c === void 0 || c.v !== E;
        });
        for (var [u, o] of n)
          o.v !== E && !(u in a) && f.push(u);
        return f;
      },
      setPrototypeOf() {
        sn();
      }
    }
  );
}
function nt(e) {
  try {
    if (e !== null && typeof e == "object" && ee in e)
      return e[ee];
  } catch {
  }
  return e;
}
function yr(e, t) {
  return Object.is(nt(e), nt(t));
}
var rt, kn, At, St;
function Rn() {
  if (rt === void 0) {
    rt = window, kn = /Firefox/.test(navigator.userAgent);
    var e = Element.prototype, t = Node.prototype, n = Text.prototype;
    At = ve(t, "firstChild").get, St = ve(t, "nextSibling").get, Qe(e) && (e.__click = void 0, e.__className = void 0, e.__attributes = null, e.__style = void 0, e.__e = void 0), Qe(n) && (n.__t = void 0);
  }
}
function xt(e = "") {
  return document.createTextNode(e);
}
// @__NO_SIDE_EFFECTS__
function kt(e) {
  return (
    /** @type {TemplateNode | null} */
    At.call(e)
  );
}
// @__NO_SIDE_EFFECTS__
function Ne(e) {
  return (
    /** @type {TemplateNode | null} */
    St.call(e)
  );
}
function wr(e, t) {
  return /* @__PURE__ */ kt(e);
}
function Er(e, t = !1) {
  {
    var n = /* @__PURE__ */ kt(e);
    return n instanceof Comment && n.data === "" ? /* @__PURE__ */ Ne(n) : n;
  }
}
function br(e, t = 1, n = !1) {
  let r = e;
  for (; t--; )
    r = /** @type {TemplateNode} */
    /* @__PURE__ */ Ne(r);
  return r;
}
function mr(e) {
  e.textContent = "";
}
function Tr() {
  return !1;
}
function ze(e) {
  var t = d, n = v;
  S(null), L(null);
  try {
    return e();
  } finally {
    S(t), L(n);
  }
}
function Rt(e) {
  v === null && (d === null && tn(), en()), se && Qt();
}
function Pn(e, t) {
  var n = t.last;
  n === null ? t.last = t.first = e : (n.next = e, e.prev = n, t.last = e);
}
function N(e, t, n) {
  var r = v;
  r !== null && (r.f & M) !== 0 && (e |= M);
  var s = {
    ctx: y,
    deps: null,
    nodes: null,
    f: e | T | P,
    first: null,
    fn: t,
    last: null,
    next: null,
    parent: r,
    b: r && r.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (n)
    try {
      oe(s), s.f |= He;
    } catch (a) {
      throw F(s), a;
    }
  else t !== null && U(s);
  var i = s;
  if (n && i.deps === null && i.teardown === null && i.nodes === null && i.first === i.last && // either `null`, or a singular child
  (i.f & ce) === 0 && (i = i.first, (e & H) !== 0 && (e & ye) !== 0 && i !== null && (i.f |= ye)), i !== null && (i.parent = r, r !== null && Pn(i, r), d !== null && (d.f & m) !== 0 && (e & ie) === 0)) {
    var l = (
      /** @type {Derived} */
      d
    );
    (l.effects ??= []).push(i);
  }
  return s;
}
function We() {
  return d !== null && !O;
}
function Pt(e) {
  const t = N(we, null, !1);
  return w(t, b), t.teardown = e, t;
}
function Ar(e) {
  Rt();
  var t = (
    /** @type {Effect} */
    v.f
  ), n = !d && (t & Y) !== 0 && (t & He) === 0;
  if (n) {
    var r = (
      /** @type {ComponentContext} */
      y
    );
    (r.e ??= []).push(e);
  } else
    return Ct(e);
}
function Ct(e) {
  return N(Ae | ot, e, !1);
}
function Sr(e) {
  return Rt(), N(we | ot, e, !0);
}
function Cn(e) {
  D.ensure();
  const t = N(ie | ce, e, !0);
  return (n = {}) => new Promise((r) => {
    n.outro ? Te(t, () => {
      F(t), r(void 0);
    }) : (F(t), r(void 0));
  });
}
function xr(e) {
  return N(Ae, e, !1);
}
function kr(e, t) {
  var n = (
    /** @type {ComponentContextLegacy} */
    y
  ), r = { effect: null, ran: !1, deps: e };
  n.l.$.push(r), r.effect = Ze(() => {
    e(), !r.ran && (r.ran = !0, Xe(t));
  });
}
function Rr() {
  var e = (
    /** @type {ComponentContextLegacy} */
    y
  );
  Ze(() => {
    for (var t of e.l.$) {
      t.deps();
      var n = t.effect;
      (n.f & b) !== 0 && n.deps !== null && w(n, j), _e(n) && oe(n), t.ran = !1;
    }
  });
}
function On(e) {
  return N(Ye | ce, e, !0);
}
function Ze(e, t = 0) {
  return N(we | t, e, !0);
}
function Pr(e, t = [], n = [], r = []) {
  bn(r, t, n, (s) => {
    N(we, () => e(...s.map(K)), !0);
  });
}
function Nn(e, t = 0) {
  var n = N(H | t, e, !0);
  return n;
}
function Cr(e, t = 0) {
  var n = N(Be | t, e, !0);
  return n;
}
function X(e) {
  return N(Y | ce, e, !0);
}
function Ot(e) {
  var t = e.teardown;
  if (t !== null) {
    const n = se, r = d;
    st(!0), S(null);
    try {
      t.call(null);
    } finally {
      st(n), S(r);
    }
  }
}
function Nt(e, t = !1) {
  var n = e.first;
  for (e.first = e.last = null; n !== null; ) {
    const s = n.ac;
    s !== null && ze(() => {
      s.abort(le);
    });
    var r = n.next;
    (n.f & ie) !== 0 ? n.parent = null : F(n, t), n = r;
  }
}
function In(e) {
  for (var t = e.first; t !== null; ) {
    var n = t.next;
    (t.f & Y) === 0 && F(t), t = n;
  }
}
function F(e, t = !0) {
  var n = !1;
  (t || (e.f & ut) !== 0) && e.nodes !== null && e.nodes.end !== null && (Dn(
    e.nodes.start,
    /** @type {TemplateNode} */
    e.nodes.end
  ), n = !0), Nt(e, t && !n), Re(e, 0), w(e, z);
  var r = e.nodes && e.nodes.t;
  if (r !== null)
    for (const i of r)
      i.stop();
  Ot(e);
  var s = e.parent;
  s !== null && s.first !== null && It(e), e.next = e.prev = e.teardown = e.ctx = e.deps = e.fn = e.nodes = e.ac = null;
}
function Dn(e, t) {
  for (; e !== null; ) {
    var n = e === t ? null : /* @__PURE__ */ Ne(e);
    e.remove(), e = n;
  }
}
function It(e) {
  var t = e.parent, n = e.prev, r = e.next;
  n !== null && (n.next = r), r !== null && (r.prev = n), t !== null && (t.first === e && (t.first = r), t.last === e && (t.last = n));
}
function Te(e, t, n = !0) {
  var r = [];
  Dt(e, r, !0);
  var s = () => {
    n && F(e), t && t();
  }, i = r.length;
  if (i > 0) {
    var l = () => --i || s();
    for (var a of r)
      a.out(l);
  } else
    s();
}
function Dt(e, t, n) {
  if ((e.f & M) === 0) {
    e.f ^= M;
    var r = e.nodes && e.nodes.t;
    if (r !== null)
      for (const a of r)
        (a.is_global || n) && t.push(a);
    for (var s = e.first; s !== null; ) {
      var i = s.next, l = (s.f & ye) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (s.f & Y) !== 0 && (e.f & H) !== 0;
      Dt(s, t, l ? n : !1), s = i;
    }
  }
}
function Or(e) {
  Mt(e, !0);
}
function Mt(e, t) {
  if ((e.f & M) !== 0) {
    e.f ^= M, (e.f & b) === 0 && (w(e, T), U(e));
    for (var n = e.first; n !== null; ) {
      var r = n.next, s = (n.f & ye) !== 0 || (n.f & Y) !== 0;
      Mt(n, s ? t : !1), n = r;
    }
    var i = e.nodes && e.nodes.t;
    if (i !== null)
      for (const l of i)
        (l.is_global || t) && l.in();
  }
}
function Mn(e, t) {
  if (e.nodes)
    for (var n = e.nodes.start, r = e.nodes.end; n !== null; ) {
      var s = n === r ? null : /* @__PURE__ */ Ne(n);
      t.append(n), n = s;
    }
}
let te = !1;
function ke(e) {
  te = e;
}
let se = !1;
function st(e) {
  se = e;
}
let d = null, O = !1;
function S(e) {
  d = e;
}
let v = null;
function L(e) {
  v = e;
}
let B = null;
function Ft(e) {
  d !== null && (B === null ? B = [e] : B.push(e));
}
let A = null, x = 0, k = null;
function Fn(e) {
  k = e;
}
let Lt = 1, Q = 0, ne = Q;
function it(e) {
  ne = e;
}
function jt() {
  return ++Lt;
}
function _e(e) {
  var t = e.f;
  if ((t & T) !== 0)
    return !0;
  if (t & m && (e.f &= ~re), (t & j) !== 0) {
    for (var n = (
      /** @type {Value[]} */
      e.deps
    ), r = n.length, s = 0; s < r; s++) {
      var i = n[s];
      if (_e(
        /** @type {Derived} */
        i
      ) && bt(
        /** @type {Derived} */
        i
      ), i.wv > e.wv)
        return !0;
    }
    (t & P) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    C === null && w(e, b);
  }
  return !1;
}
function qt(e, t, n = !0) {
  var r = e.reactions;
  if (r !== null && !B?.includes(e))
    for (var s = 0; s < r.length; s++) {
      var i = r[s];
      (i.f & m) !== 0 ? qt(
        /** @type {Derived} */
        i,
        t,
        !1
      ) : t === i && (n ? w(i, T) : (i.f & b) !== 0 && w(i, j), U(
        /** @type {Effect} */
        i
      ));
    }
}
function Vt(e) {
  var t = A, n = x, r = k, s = d, i = B, l = y, a = O, f = ne, u = e.f;
  A = /** @type {null | Value[]} */
  null, x = 0, k = null, d = (u & (Y | ie)) === 0 ? e : null, B = null, ae(e.ctx), O = !1, ne = ++Q, e.ac !== null && (ze(() => {
    e.ac.abort(le);
  }), e.ac = null);
  try {
    e.f |= Me;
    var o = (
      /** @type {Function} */
      e.fn
    ), h = o(), c = e.deps;
    if (A !== null) {
      var _;
      if (Re(e, x), c !== null && x > 0)
        for (c.length = x + A.length, _ = 0; _ < A.length; _++)
          c[x + _] = A[_];
      else
        e.deps = c = A;
      if (We() && (e.f & P) !== 0)
        for (_ = x; _ < c.length; _++)
          (c[_].reactions ??= []).push(e);
    } else c !== null && x < c.length && (Re(e, x), c.length = x);
    if (Ee() && k !== null && !O && c !== null && (e.f & (m | j | T)) === 0)
      for (_ = 0; _ < /** @type {Source[]} */
      k.length; _++)
        qt(
          k[_],
          /** @type {Effect} */
          e
        );
    if (s !== null && s !== e) {
      if (Q++, s.deps !== null)
        for (let p = 0; p < n; p += 1)
          s.deps[p].rv = Q;
      if (t !== null)
        for (const p of t)
          p.rv = Q;
      k !== null && (r === null ? r = k : r.push(.../** @type {Source[]} */
      k));
    }
    return (e.f & W) !== 0 && (e.f ^= W), h;
  } catch (p) {
    return dt(p);
  } finally {
    e.f ^= Me, A = t, x = n, k = r, d = s, B = i, ae(l), O = a, ne = f;
  }
}
function Ln(e, t) {
  let n = t.reactions;
  if (n !== null) {
    var r = Gt.call(n, e);
    if (r !== -1) {
      var s = n.length - 1;
      s === 0 ? n = t.reactions = null : (n[r] = n[s], n.pop());
    }
  }
  if (n === null && (t.f & m) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (A === null || !A.includes(t))) {
    var i = (
      /** @type {Derived} */
      t
    );
    (i.f & P) !== 0 && (i.f ^= P, i.f &= ~re), Ge(i), Et(i), Re(i, 0);
  }
}
function Re(e, t) {
  var n = e.deps;
  if (n !== null)
    for (var r = t; r < n.length; r++)
      Ln(e, n[r]);
}
function oe(e) {
  var t = e.f;
  if ((t & z) === 0) {
    w(e, b);
    var n = v, r = te;
    v = e, te = !0;
    try {
      (t & (H | Be)) !== 0 ? In(e) : Nt(e), Ot(e);
      var s = Vt(e);
      e.teardown = typeof s == "function" ? s : null, e.wv = Lt;
      var i;
      De && on && (e.f & T) !== 0 && e.deps;
    } finally {
      te = r, v = n;
    }
  }
}
async function Nr() {
  await Promise.resolve(), vn();
}
function K(e) {
  var t = e.f, n = (t & m) !== 0;
  if (d !== null && !O) {
    var r = v !== null && (v.f & z) !== 0;
    if (!r && !B?.includes(e)) {
      var s = d.deps;
      if ((d.f & Me) !== 0)
        e.rv < Q && (e.rv = Q, A === null && s !== null && s[x] === e ? x++ : A === null ? A = [e] : A.push(e));
      else {
        (d.deps ??= []).push(e);
        var i = e.reactions;
        i === null ? e.reactions = [d] : i.includes(d) || i.push(d);
      }
    }
  }
  if (se && Z.has(e))
    return Z.get(e);
  if (n) {
    var l = (
      /** @type {Derived} */
      e
    );
    if (se) {
      var a = l.v;
      return ((l.f & b) === 0 && l.reactions !== null || Ut(l)) && (a = Ke(l)), Z.set(l, a), a;
    }
    var f = (l.f & P) === 0 && !O && d !== null && (te || (d.f & P) !== 0), u = l.deps === null;
    _e(l) && (f && (l.f |= P), bt(l)), f && !u && Bt(l);
  }
  if (C?.has(e))
    return C.get(e);
  if ((e.f & W) !== 0)
    throw e.v;
  return e.v;
}
function Bt(e) {
  if (e.deps !== null) {
    e.f |= P;
    for (const t of e.deps)
      (t.reactions ??= []).push(e), (t.f & m) !== 0 && (t.f & P) === 0 && Bt(
        /** @type {Derived} */
        t
      );
  }
}
function Ut(e) {
  if (e.v === E) return !0;
  if (e.deps === null) return !1;
  for (const t of e.deps)
    if (Z.has(t) || (t.f & m) !== 0 && Ut(
      /** @type {Derived} */
      t
    ))
      return !0;
  return !1;
}
function Xe(e) {
  var t = O;
  try {
    return O = !0, e();
  } finally {
    O = t;
  }
}
function Ir(e) {
  if (!(typeof e != "object" || !e || e instanceof EventTarget)) {
    if (ee in e)
      je(e);
    else if (!Array.isArray(e))
      for (let t in e) {
        const n = e[t];
        typeof n == "object" && n && ee in n && je(n);
      }
  }
}
function je(e, t = /* @__PURE__ */ new Set()) {
  if (typeof e == "object" && e !== null && // We don't want to traverse DOM elements
  !(e instanceof EventTarget) && !t.has(e)) {
    t.add(e), e instanceof Date && e.getTime();
    for (let r in e)
      try {
        je(e[r], t);
      } catch {
      }
    const n = lt(e);
    if (n !== Object.prototype && n !== Array.prototype && n !== Map.prototype && n !== Set.prototype && n !== Date.prototype) {
      const r = zt(n);
      for (let s in r) {
        const i = r[s].get;
        if (i)
          try {
            i.call(e);
          } catch {
          }
      }
    }
  }
}
function Dr(e) {
  return e.endsWith("capture") && e !== "gotpointercapture" && e !== "lostpointercapture";
}
const jn = [
  "beforeinput",
  "click",
  "change",
  "dblclick",
  "contextmenu",
  "focusin",
  "focusout",
  "input",
  "keydown",
  "keyup",
  "mousedown",
  "mousemove",
  "mouseout",
  "mouseover",
  "mouseup",
  "pointerdown",
  "pointermove",
  "pointerout",
  "pointerover",
  "pointerup",
  "touchend",
  "touchmove",
  "touchstart"
];
function Mr(e) {
  return jn.includes(e);
}
const qn = {
  // no `class: 'className'` because we handle that separately
  formnovalidate: "formNoValidate",
  ismap: "isMap",
  nomodule: "noModule",
  playsinline: "playsInline",
  readonly: "readOnly",
  defaultvalue: "defaultValue",
  defaultchecked: "defaultChecked",
  srcobject: "srcObject",
  novalidate: "noValidate",
  allowfullscreen: "allowFullscreen",
  disablepictureinpicture: "disablePictureInPicture",
  disableremoteplayback: "disableRemotePlayback"
};
function Fr(e) {
  return e = e.toLowerCase(), qn[e] ?? e;
}
const Vn = ["touchstart", "touchmove"];
function Bn(e) {
  return Vn.includes(e);
}
const Ht = /* @__PURE__ */ new Set(), qe = /* @__PURE__ */ new Set();
function Un(e, t, n, r = {}) {
  function s(i) {
    if (r.capture || de.call(t, i), !i.cancelBubble)
      return ze(() => n?.call(this, i));
  }
  return e.startsWith("pointer") || e.startsWith("touch") || e === "wheel" ? Ce(() => {
    t.addEventListener(e, s, r);
  }) : t.addEventListener(e, s, r), s;
}
function Lr(e, t, n, r, s) {
  var i = { capture: r, passive: s }, l = Un(e, t, n, i);
  (t === document.body || // @ts-ignore
  t === window || // @ts-ignore
  t === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  t instanceof HTMLMediaElement) && Pt(() => {
    t.removeEventListener(e, l, i);
  });
}
function jr(e) {
  for (var t = 0; t < e.length; t++)
    Ht.add(e[t]);
  for (var n of qe)
    n(e);
}
let ft = null;
function de(e) {
  var t = this, n = (
    /** @type {Node} */
    t.ownerDocument
  ), r = e.type, s = e.composedPath?.() || [], i = (
    /** @type {null | Element} */
    s[0] || e.target
  );
  ft = e;
  var l = 0, a = ft === e && e.__root;
  if (a) {
    var f = s.indexOf(a);
    if (f !== -1 && (t === document || t === /** @type {any} */
    window)) {
      e.__root = t;
      return;
    }
    var u = s.indexOf(t);
    if (u === -1)
      return;
    f <= u && (l = f);
  }
  if (i = /** @type {Element} */
  s[l] || e.target, i !== t) {
    Kt(e, "currentTarget", {
      configurable: !0,
      get() {
        return i || n;
      }
    });
    var o = d, h = v;
    S(null), L(null);
    try {
      for (var c, _ = []; i !== null; ) {
        var p = i.assignedSlot || i.parentNode || /** @type {any} */
        i.host || null;
        try {
          var I = i["__" + r];
          I != null && (!/** @type {any} */
          i.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          e.target === i) && I.call(i, e);
        } catch (q) {
          c ? _.push(q) : c = q;
        }
        if (e.cancelBubble || p === t || p === null)
          break;
        i = p;
      }
      if (c) {
        for (let q of _)
          queueMicrotask(() => {
            throw q;
          });
        throw c;
      }
    } finally {
      e.__root = t, delete e.currentTarget, S(o), L(h);
    }
  }
}
function qr(e, t) {
  var n = t == null ? "" : typeof t == "object" ? t + "" : t;
  n !== (e.__t ??= e.nodeValue) && (e.__t = n, e.nodeValue = n + "");
}
function Vr(e, t) {
  return Hn(e, t);
}
const fe = /* @__PURE__ */ new Map();
function Hn(e, { target: t, anchor: n, props: r = {}, events: s, context: i, intro: l = !0 }) {
  Rn();
  var a = /* @__PURE__ */ new Set(), f = (h) => {
    for (var c = 0; c < h.length; c++) {
      var _ = h[c];
      if (!a.has(_)) {
        a.add(_);
        var p = Bn(_);
        t.addEventListener(_, de, { passive: p });
        var I = fe.get(_);
        I === void 0 ? (document.addEventListener(_, de, { passive: p }), fe.set(_, 1)) : fe.set(_, I + 1);
      }
    }
  };
  f($t(Ht)), qe.add(f);
  var u = void 0, o = Cn(() => {
    var h = n ?? t.appendChild(xt());
    return wn(
      /** @type {TemplateNode} */
      h,
      {
        pending: () => {
        }
      },
      (c) => {
        if (i) {
          cn({});
          var _ = (
            /** @type {ComponentContext} */
            y
          );
          _.c = i;
        }
        s && (r.$$events = s), u = e(c, r) || {}, i && _n();
      }
    ), () => {
      for (var c of a) {
        t.removeEventListener(c, de);
        var _ = (
          /** @type {number} */
          fe.get(c)
        );
        --_ === 0 ? (document.removeEventListener(c, de), fe.delete(c)) : fe.set(c, _);
      }
      qe.delete(f), h !== n && h.parentNode?.removeChild(h);
    };
  });
  return Ve.set(u, o), u;
}
let Ve = /* @__PURE__ */ new WeakMap();
function Br(e, t) {
  const n = Ve.get(e);
  return n ? (Ve.delete(e), n(t)) : Promise.resolve();
}
export {
  ee as $,
  pr as A,
  ar as B,
  Kn as C,
  mr as D,
  ye as E,
  Ne as F,
  Pt as G,
  Cr as H,
  M as I,
  xr as J,
  hr as K,
  yr as L,
  nr as M,
  rr as N,
  or as O,
  zt as P,
  bn as Q,
  sr as R,
  Dr as S,
  er as T,
  Un as U,
  jr as V,
  Fr as W,
  E as X,
  Mr as Y,
  Xe as Z,
  Ze as _,
  v as a,
  y as a0,
  Sr as a1,
  Ar as a2,
  lr as a3,
  Xt as a4,
  Ir as a5,
  $e as a6,
  fr as a7,
  un as a8,
  $ as a9,
  vr as aA,
  We as aB,
  gn as aC,
  G as aD,
  Nr as aE,
  rt as aF,
  Vr as aG,
  Br as aH,
  Kt as aa,
  ve as ab,
  _r as ac,
  Xn as ad,
  he as ae,
  z as af,
  Jn as ag,
  Pe as ah,
  Zn as ai,
  Wn as aj,
  Qn as ak,
  se as al,
  ur as am,
  ir as an,
  dr as ao,
  kr as ap,
  Rr as aq,
  Er as ar,
  _n as as,
  cn as at,
  br as au,
  Lr as av,
  Pr as aw,
  gr as ax,
  wr as ay,
  qr as az,
  kt as b,
  xt as c,
  kn as d,
  tr as e,
  g as f,
  lt as g,
  F as h,
  Yt as i,
  X as j,
  Nn as k,
  K as l,
  Mn as m,
  xe as n,
  Wt as o,
  Te as p,
  Ce as q,
  Or as r,
  Tr as s,
  $n as t,
  An as u,
  $t as v,
  Gn as w,
  be as x,
  Yn as y,
  zn as z
};
