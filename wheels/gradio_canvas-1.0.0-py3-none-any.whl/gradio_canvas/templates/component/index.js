import { i as hr, g as jr, o as on, q as vr, c as ot, a as _r, b as Ht, d as cn, T as fn, e as dn, f as sr, r as pr, h as _t, p as gr, j as pt, m as un, s as Hr, k as Ct, E as Yt, l as i, n as kr, t as qr, u as Ur, v as mr, w as hn, x as Er, y as vn, z as _n, A as vt, B as Qe, I as er, C as pn, D as gn, F as mn, N as bn, G as br, H as Yr, J as Kt, K as wn, L as yn, M as xn, O as kn, P as En, Q as Mn, R as Tn, S as Sn, U as zn, V as It, W as An, X as Ln, Y as Cn, Z, _ as In, $ as wr, a0 as Vt, a1 as Pn, a2 as ce, a3 as On, a4 as Mr, a5 as Le, a6 as Kr, a7 as xt, a8 as Nn, a9 as w, aa as Rn, ab as lr, ac as Fn, ad as Dn, ae as qt, af as Vn, ag as Bn, ah as Wr, ai as jn, aj as Hn, ak as qn, al as Un, am as Zr, an as zt, ao as Yn, ap as Tr, aq as Kn, ar as Q, as as Pt, at as Ot, au as O, av as de, aw as j, ax as Wn, ay as H, az as oe, aA as te, aB as Zn, aC as Gn, aD as V, aE as Gr, aF as Bt } from "./render-BuEbLTW8.js";
function Xn(t) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
const Jn = [];
function Qn(t, e = !1, r = !1) {
  return jt(t, /* @__PURE__ */ new Map(), "", Jn, null, r);
}
function jt(t, e, r, n, s = null, a = !1) {
  if (typeof t == "object" && t !== null) {
    var l = e.get(t);
    if (l !== void 0) return l;
    if (t instanceof Map) return (
      /** @type {Snapshot<T>} */
      new Map(t)
    );
    if (t instanceof Set) return (
      /** @type {Snapshot<T>} */
      new Set(t)
    );
    if (hr(t)) {
      var o = (
        /** @type {Snapshot<any>} */
        Array(t.length)
      );
      e.set(t, o), s !== null && e.set(s, o);
      for (var f = 0; f < t.length; f += 1) {
        var d = t[f];
        f in t && (o[f] = jt(d, e, r, n, null, a));
      }
      return o;
    }
    if (jr(t) === on) {
      o = {}, e.set(t, o), s !== null && e.set(s, o);
      for (var h in t)
        o[h] = jt(
          // @ts-expect-error
          t[h],
          e,
          r,
          n,
          null,
          a
        );
      return o;
    }
    if (t instanceof Date)
      return (
        /** @type {Snapshot<T>} */
        structuredClone(t)
      );
    if (typeof /** @type {T & { toJSON?: any } } */
    t.toJSON == "function" && !a)
      return jt(
        /** @type {T & { toJSON(): any } } */
        t.toJSON(),
        e,
        r,
        n,
        // Associate the instance with the toJSON clone
        t
      );
  }
  if (t instanceof EventTarget)
    return (
      /** @type {Snapshot<T>} */
      t
    );
  try {
    return (
      /** @type {Snapshot<T>} */
      structuredClone(t)
    );
  } catch {
    return (
      /** @type {Snapshot<T>} */
      t
    );
  }
}
function $n(t, e) {
  if (e) {
    const r = document.body;
    t.autofocus = !0, vr(() => {
      document.activeElement === r && t.focus();
    });
  }
}
function Xr(t) {
  var e = document.createElement("template");
  return e.innerHTML = t.replaceAll("<!>", "<!---->"), e.content;
}
function kt(t, e) {
  var r = (
    /** @type {Effect} */
    _r
  );
  r.nodes === null && (r.nodes = { start: t, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function q(t, e) {
  var r = (e & fn) !== 0, n = (e & dn) !== 0, s, a = !t.startsWith("<!>");
  return () => {
    s === void 0 && (s = Xr(a ? t : "<!>" + t), r || (s = /** @type {TemplateNode} */
    Ht(s)));
    var l = (
      /** @type {TemplateNode} */
      n || cn ? document.importNode(s, !0) : s.cloneNode(!0)
    );
    if (r) {
      var o = (
        /** @type {TemplateNode} */
        Ht(l)
      ), f = (
        /** @type {TemplateNode} */
        l.lastChild
      );
      kt(o, f);
    } else
      kt(l, l);
    return l;
  };
}
// @__NO_SIDE_EFFECTS__
function ea(t, e, r = "svg") {
  var n = !t.startsWith("<!>"), s = `<${r}>${n ? t : "<!>" + t}</${r}>`, a;
  return () => {
    if (!a) {
      var l = (
        /** @type {DocumentFragment} */
        Xr(s)
      ), o = (
        /** @type {Element} */
        Ht(l)
      );
      a = /** @type {Element} */
      Ht(o);
    }
    var f = (
      /** @type {TemplateNode} */
      a.cloneNode(!0)
    );
    return kt(f, f), f;
  };
}
// @__NO_SIDE_EFFECTS__
function Et(t, e) {
  return /* @__PURE__ */ ea(t, e, "svg");
}
function qe(t = "") {
  {
    var e = ot(t + "");
    return kt(e, e), e;
  }
}
function Ve() {
  var t = document.createDocumentFragment(), e = document.createComment(""), r = ot();
  return t.append(e, r), kt(e, r), t;
}
function k(t, e) {
  t !== null && t.before(
    /** @type {Node} */
    e
  );
}
class Wt {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #e = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #t = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #r = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #n = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #a = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, r = !0) {
    this.anchor = e, this.#a = r;
  }
  #i = () => {
    var e = (
      /** @type {Batch} */
      sr
    );
    if (this.#e.has(e)) {
      var r = (
        /** @type {Key} */
        this.#e.get(e)
      ), n = this.#t.get(r);
      if (n)
        pr(n), this.#n.delete(r);
      else {
        var s = this.#r.get(r);
        s && (this.#t.set(r, s.effect), this.#r.delete(r), s.fragment.lastChild.remove(), this.anchor.before(s.fragment), n = s.effect);
      }
      for (const [a, l] of this.#e) {
        if (this.#e.delete(a), a === e)
          break;
        const o = this.#r.get(l);
        o && (_t(o.effect), this.#r.delete(l));
      }
      for (const [a, l] of this.#t) {
        if (a === r || this.#n.has(a)) continue;
        const o = () => {
          if (Array.from(this.#e.values()).includes(a)) {
            var d = document.createDocumentFragment();
            un(l, d), d.append(ot()), this.#r.set(a, { effect: l, fragment: d });
          } else
            _t(l);
          this.#n.delete(a), this.#t.delete(a);
        };
        this.#a || !n ? (this.#n.add(a), gr(l, o, !1)) : o();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #s = (e) => {
    this.#e.delete(e);
    const r = Array.from(this.#e.values());
    for (const [n, s] of this.#r)
      r.includes(n) || (_t(s.effect), this.#r.delete(n));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, r) {
    var n = (
      /** @type {Batch} */
      sr
    ), s = Hr();
    if (r && !this.#t.has(e) && !this.#r.has(e))
      if (s) {
        var a = document.createDocumentFragment(), l = ot();
        a.append(l), this.#r.set(e, {
          effect: pt(() => r(l)),
          fragment: a
        });
      } else
        this.#t.set(
          e,
          pt(() => r(this.anchor))
        );
    if (this.#e.set(n, e), s) {
      for (const [o, f] of this.#t)
        o === e ? n.skipped_effects.delete(f) : n.skipped_effects.add(f);
      for (const [o, f] of this.#r)
        o === e ? n.skipped_effects.delete(f.effect) : n.skipped_effects.add(f.effect);
      n.oncommit(this.#i), n.ondiscard(this.#s);
    } else
      this.#i();
  }
}
function F(t, e, r = !1) {
  var n = new Wt(t), s = r ? Yt : 0;
  function a(l, o) {
    n.ensure(l, o);
  }
  Ct(() => {
    var l = !1;
    e((o, f = !0) => {
      l = !0, a(f, o);
    }), l || a(!1, null);
  }, s);
}
function wt(t, e) {
  return e;
}
function ta(t, e, r) {
  for (var n = [], s = e.length, a, l = e.length, o = 0; o < s; o++) {
    let y = e[o];
    gr(
      y,
      () => {
        if (a) {
          if (a.pending.delete(y), a.done.add(y), a.pending.size === 0) {
            var p = (
              /** @type {Set<EachOutroGroup>} */
              t.outrogroups
            );
            or(mr(a.done)), p.delete(a), p.size === 0 && (t.outrogroups = null);
          }
        } else
          l -= 1;
      },
      !1
    );
  }
  if (l === 0) {
    var f = n.length === 0 && r !== null;
    if (f) {
      var d = (
        /** @type {Element} */
        r
      ), h = (
        /** @type {Element} */
        d.parentNode
      );
      gn(h), h.append(d), t.items.clear();
    }
    or(e, !f);
  } else
    a = {
      pending: new Set(e),
      done: /* @__PURE__ */ new Set()
    }, (t.outrogroups ??= /* @__PURE__ */ new Set()).add(a);
}
function or(t, e = !0) {
  for (var r = 0; r < t.length; r++)
    _t(t[r], e);
}
var Sr;
function yt(t, e, r, n, s, a = null) {
  var l = t, o = /* @__PURE__ */ new Map(), f = (e & qr) !== 0;
  if (f) {
    var d = (
      /** @type {Element} */
      t
    );
    l = d.appendChild(ot());
  }
  var h = null, y = Ur(() => {
    var v = r();
    return hr(v) ? v : v == null ? [] : mr(v);
  }), p, T = !0;
  function S() {
    u.fallback = h, ra(u, p, l, e, n), h !== null && (p.length === 0 ? (h.f & Qe) === 0 ? pr(h) : (h.f ^= Qe, At(h, null, l)) : gr(h, () => {
      h = null;
    }));
  }
  var E = Ct(() => {
    p = /** @type {V[]} */
    i(y);
    for (var v = p.length, B = /* @__PURE__ */ new Set(), _ = (
      /** @type {Batch} */
      sr
    ), x = Hr(), z = 0; z < v; z += 1) {
      var N = p[z], b = n(N, z), U = T ? null : o.get(b);
      U ? (U.v && kr(U.v, N), U.i && kr(U.i, z), x && _.skipped_effects.delete(U.e)) : (U = na(
        o,
        T ? l : Sr ??= ot(),
        N,
        b,
        z,
        s,
        e,
        r
      ), T || (U.e.f |= Qe), o.set(b, U)), B.add(b);
    }
    if (v === 0 && a && !h && (T ? h = pt(() => a(l)) : (h = pt(() => a(Sr ??= ot())), h.f |= Qe)), !T)
      if (x) {
        for (const [D, P] of o)
          B.has(D) || _.skipped_effects.add(P.e);
        _.oncommit(S), _.ondiscard(() => {
        });
      } else
        S();
    i(y);
  }), u = { effect: E, items: o, outrogroups: null, fallback: h };
  T = !1;
}
function ra(t, e, r, n, s) {
  var a = (n & pn) !== 0, l = e.length, o = t.items, f = t.effect.first, d, h = null, y, p = [], T = [], S, E, u, v;
  if (a)
    for (v = 0; v < l; v += 1)
      S = e[v], E = s(S, v), u = /** @type {EachItem} */
      o.get(E).e, (u.f & Qe) === 0 && (u.nodes?.a?.measure(), (y ??= /* @__PURE__ */ new Set()).add(u));
  for (v = 0; v < l; v += 1) {
    if (S = e[v], E = s(S, v), u = /** @type {EachItem} */
    o.get(E).e, t.outrogroups !== null)
      for (const P of t.outrogroups)
        P.pending.delete(u), P.done.delete(u);
    if ((u.f & Qe) !== 0)
      if (u.f ^= Qe, u === f)
        At(u, null, r);
      else {
        var B = h ? h.next : f;
        u === t.effect.last && (t.effect.last = u.prev), u.prev && (u.prev.next = u.next), u.next && (u.next.prev = u.prev), st(t, h, u), st(t, u, B), At(u, B, r), h = u, p = [], T = [], f = h.next;
        continue;
      }
    if ((u.f & er) !== 0 && (pr(u), a && (u.nodes?.a?.unfix(), (y ??= /* @__PURE__ */ new Set()).delete(u))), u !== f) {
      if (d !== void 0 && d.has(u)) {
        if (p.length < T.length) {
          var _ = T[0], x;
          h = _.prev;
          var z = p[0], N = p[p.length - 1];
          for (x = 0; x < p.length; x += 1)
            At(p[x], _, r);
          for (x = 0; x < T.length; x += 1)
            d.delete(T[x]);
          st(t, z.prev, N.next), st(t, h, z), st(t, N, _), f = _, h = N, v -= 1, p = [], T = [];
        } else
          d.delete(u), At(u, f, r), st(t, u.prev, u.next), st(t, u, h === null ? t.effect.first : h.next), st(t, h, u), h = u;
        continue;
      }
      for (p = [], T = []; f !== null && f !== u; )
        (d ??= /* @__PURE__ */ new Set()).add(f), T.push(f), f = f.next;
      if (f === null)
        continue;
    }
    (u.f & Qe) === 0 && p.push(u), h = u, f = u.next;
  }
  if (t.outrogroups !== null) {
    for (const P of t.outrogroups)
      P.pending.size === 0 && (or(mr(P.done)), t.outrogroups?.delete(P));
    t.outrogroups.size === 0 && (t.outrogroups = null);
  }
  if (f !== null || d !== void 0) {
    var b = [];
    if (d !== void 0)
      for (u of d)
        (u.f & er) === 0 && b.push(u);
    for (; f !== null; )
      (f.f & er) === 0 && f !== t.fallback && b.push(f), f = f.next;
    var U = b.length;
    if (U > 0) {
      var D = (n & qr) !== 0 && l === 0 ? r : null;
      if (a) {
        for (v = 0; v < U; v += 1)
          b[v].nodes?.a?.measure();
        for (v = 0; v < U; v += 1)
          b[v].nodes?.a?.fix();
      }
      ta(t, b, D);
    }
  }
  a && vr(() => {
    if (y !== void 0)
      for (u of y)
        u.nodes?.a?.apply();
  });
}
function na(t, e, r, n, s, a, l, o) {
  var f = (l & vn) !== 0 ? (l & _n) === 0 ? vt(r, !1, !1) : Er(r) : null, d = (l & hn) !== 0 ? Er(s) : null;
  return {
    v: f,
    i: d,
    e: pt(() => (a(e, f ?? r, d ?? s, o), () => {
      t.delete(n);
    }))
  };
}
function At(t, e, r) {
  if (t.nodes)
    for (var n = t.nodes.start, s = t.nodes.end, a = e && (e.f & Qe) === 0 ? (
      /** @type {EffectNodes} */
      e.nodes.start
    ) : r; n !== null; ) {
      var l = (
        /** @type {TemplateNode} */
        mn(n)
      );
      if (a.before(n), n === s)
        return;
      n = l;
    }
}
function st(t, e, r) {
  e === null ? t.effect.first = r : e.next = r, r === null ? t.effect.last = e : r.prev = e;
}
function cr(t, e, r, n, s) {
  var a = e.$$slots?.[r], l = !1;
  a === !0 && (a = e[r === "default" ? "children" : r], l = !0), a === void 0 || a(t, l ? () => n : n);
}
function aa(t, e, ...r) {
  var n = new Wt(t);
  Ct(() => {
    const s = e() ?? null;
    n.ensure(s, s && ((a) => s(a, ...r)));
  }, Yt);
}
function ia(t, e, r) {
  var n = new Wt(t);
  Ct(() => {
    var s = e() ?? null;
    n.ensure(s, s && ((a) => r(a, s)));
  }, Yt);
}
const sa = () => performance.now(), Be = {
  // don't access requestAnimationFrame eagerly outside method
  // this allows basic testing of user code without JSDOM
  // bunder will eval and remove ternary when the user's app is built
  tick: (
    /** @param {any} _ */
    (t) => requestAnimationFrame(t)
  ),
  now: () => sa(),
  tasks: /* @__PURE__ */ new Set()
};
function Jr() {
  const t = Be.now();
  Be.tasks.forEach((e) => {
    e.c(t) || (Be.tasks.delete(e), e.f());
  }), Be.tasks.size !== 0 && Be.tick(Jr);
}
function la(t) {
  let e;
  return Be.tasks.size === 0 && Be.tick(Jr), {
    promise: new Promise((r) => {
      Be.tasks.add(e = { c: t, f: r });
    }),
    abort() {
      Be.tasks.delete(e);
    }
  };
}
function oa(t, e, r, n, s, a) {
  var l = null, o = (
    /** @type {TemplateNode} */
    t
  ), f = new Wt(o, !1);
  Ct(() => {
    const d = e() || null;
    var h = d === "svg" ? bn : null;
    if (d === null) {
      f.ensure(null, null);
      return;
    }
    return f.ensure(d, (y) => {
      if (d) {
        if (l = h ? document.createElementNS(h, d) : document.createElement(d), kt(l, l), n) {
          var p = l.appendChild(ot());
          n(l, p);
        }
        _r.nodes.end = l, y.before(l);
      }
    }), () => {
    };
  }, Yt), br(() => {
  });
}
function ca(t, e) {
  var r = void 0, n;
  Yr(() => {
    r !== (r = e()) && (n && (_t(n), n = null), r && (n = pt(() => {
      Kt(() => (
        /** @type {(node: Element) => void} */
        r(t)
      ));
    })));
  });
}
function Qr(t) {
  var e, r, n = "";
  if (typeof t == "string" || typeof t == "number") n += t;
  else if (typeof t == "object") if (Array.isArray(t)) {
    var s = t.length;
    for (e = 0; e < s; e++) t[e] && (r = Qr(t[e])) && (n && (n += " "), n += r);
  } else for (r in t) t[r] && (n && (n += " "), n += r);
  return n;
}
function fa() {
  for (var t, e, r = 0, n = "", s = arguments.length; r < s; r++) (t = arguments[r]) && (e = Qr(t)) && (n && (n += " "), n += e);
  return n;
}
function da(t) {
  return typeof t == "object" ? fa(t) : t ?? "";
}
const zr = [...` 	
\r\f \v\uFEFF`];
function ua(t, e, r) {
  var n = t == null ? "" : "" + t;
  if (e && (n = n ? n + " " + e : e), r) {
    for (var s in r)
      if (r[s])
        n = n ? n + " " + s : s;
      else if (n.length)
        for (var a = s.length, l = 0; (l = n.indexOf(s, l)) >= 0; ) {
          var o = l + a;
          (l === 0 || zr.includes(n[l - 1])) && (o === n.length || zr.includes(n[o])) ? n = (l === 0 ? "" : n.substring(0, l)) + n.substring(o + 1) : l = o;
        }
  }
  return n === "" ? null : n;
}
function Ar(t, e = !1) {
  var r = e ? " !important;" : ";", n = "";
  for (var s in t) {
    var a = t[s];
    a != null && a !== "" && (n += " " + s + ": " + a + r);
  }
  return n;
}
function tr(t) {
  return t[0] !== "-" || t[1] !== "-" ? t.toLowerCase() : t;
}
function ha(t, e) {
  if (e) {
    var r = "", n, s;
    if (Array.isArray(e) ? (n = e[0], s = e[1]) : n = e, t) {
      t = String(t).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var a = !1, l = 0, o = !1, f = [];
      n && f.push(...Object.keys(n).map(tr)), s && f.push(...Object.keys(s).map(tr));
      var d = 0, h = -1;
      const E = t.length;
      for (var y = 0; y < E; y++) {
        var p = t[y];
        if (o ? p === "/" && t[y - 1] === "*" && (o = !1) : a ? a === p && (a = !1) : p === "/" && t[y + 1] === "*" ? o = !0 : p === '"' || p === "'" ? a = p : p === "(" ? l++ : p === ")" && l--, !o && a === !1 && l === 0) {
          if (p === ":" && h === -1)
            h = y;
          else if (p === ";" || y === E - 1) {
            if (h !== -1) {
              var T = tr(t.substring(d, h).trim());
              if (!f.includes(T)) {
                p !== ";" && y++;
                var S = t.substring(d, y).trim();
                r += " " + S + ";";
              }
            }
            d = y + 1, h = -1;
          }
        }
      }
    }
    return n && (r += Ar(n)), s && (r += Ar(s, !0)), r = r.trim(), r === "" ? null : r;
  }
  return t == null ? null : String(t);
}
function Ee(t, e, r, n, s, a) {
  var l = t.__className;
  if (l !== r || l === void 0) {
    var o = ua(r, n, a);
    o == null ? t.removeAttribute("class") : e ? t.className = o : t.setAttribute("class", o), t.__className = r;
  } else if (a && s !== a)
    for (var f in a) {
      var d = !!a[f];
      (s == null || d !== !!s[f]) && t.classList.toggle(f, d);
    }
  return a;
}
function rr(t, e = {}, r, n) {
  for (var s in r) {
    var a = r[s];
    e[s] !== a && (r[s] == null ? t.style.removeProperty(s) : t.style.setProperty(s, a, n));
  }
}
function Ie(t, e, r, n) {
  var s = t.__style;
  if (s !== e) {
    var a = ha(e, n);
    a == null ? t.removeAttribute("style") : t.style.cssText = a, t.__style = e;
  } else n && (Array.isArray(n) ? (rr(t, r?.[0], n[0]), rr(t, r?.[1], n[1], "important")) : rr(t, r, n));
  return n;
}
function fr(t, e, r = !1) {
  if (t.multiple) {
    if (e == null)
      return;
    if (!hr(e))
      return wn();
    for (var n of t.options)
      n.selected = e.includes(Lr(n));
    return;
  }
  for (n of t.options) {
    var s = Lr(n);
    if (yn(s, e)) {
      n.selected = !0;
      return;
    }
  }
  (!r || e !== void 0) && (t.selectedIndex = -1);
}
function va(t) {
  var e = new MutationObserver(() => {
    fr(t, t.__value);
  });
  e.observe(t, {
    // Listen to option element changes
    childList: !0,
    subtree: !0,
    // because of <optgroup>
    // Listen to option element value attribute changes
    // (doesn't get notified of select value changes,
    // because that property is not reflected as an attribute)
    attributes: !0,
    attributeFilter: ["value"]
  }), br(() => {
    e.disconnect();
  });
}
function Lr(t) {
  return "__value" in t ? t.__value : t.value;
}
const Lt = /* @__PURE__ */ Symbol("class"), bt = /* @__PURE__ */ Symbol("style"), $r = /* @__PURE__ */ Symbol("is custom element"), en = /* @__PURE__ */ Symbol("is html");
function _a(t, e) {
  e ? t.hasAttribute("selected") || t.setAttribute("selected", "") : t.removeAttribute("selected");
}
function Ce(t, e, r, n) {
  var s = tn(t);
  s[e] !== (s[e] = r) && (e === "loading" && (t[kn] = r), r == null ? t.removeAttribute(e) : typeof r != "string" && rn(t).includes(e) ? t[e] = r : t.setAttribute(e, r));
}
function pa(t, e, r, n, s = !1, a = !1) {
  var l = tn(t), o = l[$r], f = !l[en], d = e || {}, h = t.tagName === "OPTION";
  for (var y in e)
    y in r || (r[y] = null);
  r.class ? r.class = da(r.class) : r.class = null, r[bt] && (r.style ??= null);
  var p = rn(t);
  for (const _ in r) {
    let x = r[_];
    if (h && _ === "value" && x == null) {
      t.value = t.__value = "", d[_] = x;
      continue;
    }
    if (_ === "class") {
      var T = t.namespaceURI === "http://www.w3.org/1999/xhtml";
      Ee(t, T, x, n, e?.[Lt], r[Lt]), d[_] = x, d[Lt] = r[Lt];
      continue;
    }
    if (_ === "style") {
      Ie(t, x, e?.[bt], r[bt]), d[_] = x, d[bt] = r[bt];
      continue;
    }
    var S = d[_];
    if (!(x === S && !(x === void 0 && t.hasAttribute(_)))) {
      d[_] = x;
      var E = _[0] + _[1];
      if (E !== "$$")
        if (E === "on") {
          const z = {}, N = "$$" + _;
          let b = _.slice(2);
          var u = Cn(b);
          if (Sn(b) && (b = b.slice(0, -7), z.capture = !0), !u && S) {
            if (x != null) continue;
            t.removeEventListener(b, d[N], z), d[N] = null;
          }
          if (x != null)
            if (u)
              t[`__${b}`] = x, It([b]);
            else {
              let U = function(D) {
                d[_].call(this, D);
              };
              d[N] = zn(b, t, U, z);
            }
          else u && (t[`__${b}`] = void 0);
        } else if (_ === "style")
          Ce(t, _, x);
        else if (_ === "autofocus")
          $n(
            /** @type {HTMLElement} */
            t,
            !!x
          );
        else if (!o && (_ === "__value" || _ === "value" && x != null))
          t.value = t.__value = x;
        else if (_ === "selected" && h)
          _a(
            /** @type {HTMLOptionElement} */
            t,
            x
          );
        else {
          var v = _;
          f || (v = An(v));
          var B = v === "defaultValue" || v === "defaultChecked";
          if (x == null && !o && !B)
            if (l[_] = null, v === "value" || v === "checked") {
              let z = (
                /** @type {HTMLInputElement} */
                t
              );
              const N = e === void 0;
              if (v === "value") {
                let b = z.defaultValue;
                z.removeAttribute(v), z.defaultValue = b, z.value = z.__value = N ? b : null;
              } else {
                let b = z.defaultChecked;
                z.removeAttribute(v), z.defaultChecked = b, z.checked = N ? b : !1;
              }
            } else
              t.removeAttribute(_);
          else B || p.includes(v) && (o || typeof x != "string") ? (t[v] = x, v in l && (l[v] = Ln)) : typeof x != "function" && Ce(t, v, x);
        }
    }
  }
  return d;
}
function ga(t, e, r = [], n = [], s = [], a, l = !1, o = !1) {
  Mn(s, r, n, (f) => {
    var d = void 0, h = {}, y = t.nodeName === "SELECT", p = !1;
    if (Yr(() => {
      var S = e(...f.map(i)), E = pa(
        t,
        d,
        S,
        a,
        l,
        o
      );
      p && y && "value" in S && fr(
        /** @type {HTMLSelectElement} */
        t,
        S.value
      );
      for (let v of Object.getOwnPropertySymbols(h))
        S[v] || _t(h[v]);
      for (let v of Object.getOwnPropertySymbols(S)) {
        var u = S[v];
        v.description === Tn && (!d || u !== d[v]) && (h[v] && _t(h[v]), h[v] = pt(() => ca(t, () => u))), E[v] = u;
      }
      d = E;
    }), y) {
      var T = (
        /** @type {HTMLSelectElement} */
        t
      );
      Kt(() => {
        fr(
          T,
          /** @type {Record<string | symbol, any>} */
          d.value,
          !0
        ), va(T);
      });
    }
    p = !0;
  });
}
function tn(t) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    t.__attributes ??= {
      [$r]: t.nodeName.includes("-"),
      [en]: t.namespaceURI === xn
    }
  );
}
var Cr = /* @__PURE__ */ new Map();
function rn(t) {
  var e = t.getAttribute("is") || t.nodeName, r = Cr.get(e);
  if (r) return r;
  Cr.set(e, r = []);
  for (var n, s = t, a = Element.prototype; a !== s; ) {
    n = En(s);
    for (var l in n)
      n[l].set && r.push(l);
    s = jr(s);
  }
  return r;
}
class yr {
  /** */
  #e = /* @__PURE__ */ new WeakMap();
  /** @type {ResizeObserver | undefined} */
  #t;
  /** @type {ResizeObserverOptions} */
  #r;
  /** @static */
  static entries = /* @__PURE__ */ new WeakMap();
  /** @param {ResizeObserverOptions} options */
  constructor(e) {
    this.#r = e;
  }
  /**
   * @param {Element} element
   * @param {(entry: ResizeObserverEntry) => any} listener
   */
  observe(e, r) {
    var n = this.#e.get(e) || /* @__PURE__ */ new Set();
    return n.add(r), this.#e.set(e, n), this.#n().observe(e, this.#r), () => {
      var s = this.#e.get(e);
      s.delete(r), s.size === 0 && (this.#e.delete(e), this.#t.unobserve(e));
    };
  }
  #n() {
    return this.#t ?? (this.#t = new ResizeObserver(
      /** @param {any} entries */
      (e) => {
        for (var r of e) {
          yr.entries.set(r.target, r);
          for (var n of this.#e.get(r.target) || [])
            n(r);
        }
      }
    ));
  }
}
var ma = /* @__PURE__ */ new yr({
  box: "border-box"
});
function nr(t, e, r) {
  var n = ma.observe(t, () => r(t[e]));
  Kt(() => (Z(() => r(t[e])), n));
}
function Ir(t, e) {
  return t === e || t?.[wr] === e;
}
function lt(t = {}, e, r, n) {
  return Kt(() => {
    var s, a;
    return In(() => {
      s = a, a = n?.() || [], Z(() => {
        t !== r(...a) && (e(t, ...a), s && Ir(r(...s), t) && e(null, ...s));
      });
    }), () => {
      vr(() => {
        a && Ir(r(...a), t) && e(null, ...a);
      });
    };
  }), t;
}
function ba(t = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    Vt
  ), r = e.l.u;
  if (!r) return;
  let n = () => Le(e.s);
  if (t) {
    let s = 0, a = (
      /** @type {Record<string, any>} */
      {}
    );
    const l = Kr(() => {
      let o = !1;
      const f = e.s;
      for (const d in f)
        f[d] !== a[d] && (a[d] = f[d], o = !0);
      return o && s++, s;
    });
    n = () => i(l);
  }
  r.b.length && Pn(() => {
    Pr(e, n), Mr(r.b);
  }), ce(() => {
    const s = Z(() => r.m.map(On));
    return () => {
      for (const a of s)
        typeof a == "function" && a();
    };
  }), r.a.length && ce(() => {
    Pr(e, n), Mr(r.a);
  });
}
function Pr(t, e) {
  if (t.l.s)
    for (const r of t.l.s) i(r);
  e();
}
function nn(t, e, r) {
  if (t == null)
    return e(void 0), xt;
  const n = Z(
    () => t.subscribe(
      e,
      // @ts-expect-error
      r
    )
  );
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const mt = [];
function wa(t, e = xt) {
  let r = null;
  const n = /* @__PURE__ */ new Set();
  function s(o) {
    if (Nn(t, o) && (t = o, r)) {
      const f = !mt.length;
      for (const d of n)
        d[1](), mt.push(d, t);
      if (f) {
        for (let d = 0; d < mt.length; d += 2)
          mt[d][0](mt[d + 1]);
        mt.length = 0;
      }
    }
  }
  function a(o) {
    s(o(
      /** @type {T} */
      t
    ));
  }
  function l(o, f = xt) {
    const d = [o, f];
    return n.add(d), n.size === 1 && (r = e(s, a) || xt), o(
      /** @type {T} */
      t
    ), () => {
      n.delete(d), n.size === 0 && r && (r(), r = null);
    };
  }
  return { set: s, update: a, subscribe: l };
}
function an(t) {
  let e;
  return nn(t, (r) => e = r)(), e;
}
let Ft = !1, dr = /* @__PURE__ */ Symbol();
function Or(t, e, r) {
  const n = r[e] ??= {
    store: null,
    source: vt(void 0),
    unsubscribe: xt
  };
  if (n.store !== t && !(dr in r))
    if (n.unsubscribe(), n.store = t ?? null, t == null)
      n.source.v = void 0, n.unsubscribe = xt;
    else {
      var s = !0;
      n.unsubscribe = nn(t, (a) => {
        s ? n.source.v = a : w(n.source, a);
      }), s = !1;
    }
  return t && dr in r ? an(t) : i(n.source);
}
function ya() {
  const t = {};
  function e() {
    br(() => {
      for (var r in t)
        t[r].unsubscribe();
      Rn(t, dr, {
        enumerable: !1,
        value: !0
      });
    });
  }
  return [t, e];
}
function xa(t) {
  var e = Ft;
  try {
    return Ft = !1, [t(), Ft];
  } finally {
    Ft = e;
  }
}
const ka = {
  get(t, e) {
    if (!t.exclude.includes(e))
      return t.props[e];
  },
  set(t, e) {
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    if (!t.exclude.includes(e) && e in t.props)
      return {
        enumerable: !0,
        configurable: !0,
        value: t.props[e]
      };
  },
  has(t, e) {
    return t.exclude.includes(e) ? !1 : e in t.props;
  },
  ownKeys(t) {
    return Reflect.ownKeys(t.props).filter((e) => !t.exclude.includes(e));
  }
};
// @__NO_SIDE_EFFECTS__
function Ea(t, e, r) {
  return new Proxy(
    { props: t, exclude: e },
    ka
  );
}
const Ma = {
  get(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let n = t.props[r];
      if (zt(n) && (n = n()), typeof n == "object" && n !== null && e in n) return n[e];
    }
  },
  set(t, e, r) {
    let n = t.props.length;
    for (; n--; ) {
      let s = t.props[n];
      zt(s) && (s = s());
      const a = lr(s, e);
      if (a && a.set)
        return a.set(r), !0;
    }
    return !1;
  },
  getOwnPropertyDescriptor(t, e) {
    let r = t.props.length;
    for (; r--; ) {
      let n = t.props[r];
      if (zt(n) && (n = n()), typeof n == "object" && n !== null && e in n) {
        const s = lr(n, e);
        return s && !s.configurable && (s.configurable = !0), s;
      }
    }
  },
  has(t, e) {
    if (e === wr || e === Zr) return !1;
    for (let r of t.props)
      if (zt(r) && (r = r()), r != null && e in r) return !0;
    return !1;
  },
  ownKeys(t) {
    const e = [];
    for (let r of t.props)
      if (zt(r) && (r = r()), !!r) {
        for (const n in r)
          e.includes(n) || e.push(n);
        for (const n of Object.getOwnPropertySymbols(r))
          e.includes(n) || e.push(n);
      }
    return e;
  }
};
function Ta(...t) {
  return new Proxy({ props: t }, Ma);
}
function m(t, e, r, n) {
  var s = !Wr || (r & jn) !== 0, a = (r & Bn) !== 0, l = (r & qn) !== 0, o = (
    /** @type {V} */
    n
  ), f = !0, d = () => (f && (f = !1, o = l ? Z(
    /** @type {() => V} */
    n
  ) : (
    /** @type {V} */
    n
  )), o), h;
  if (a) {
    var y = wr in t || Zr in t;
    h = lr(t, e)?.set ?? (y && e in t ? (_) => t[e] = _ : void 0);
  }
  var p, T = !1;
  a ? [p, T] = xa(() => (
    /** @type {V} */
    t[e]
  )) : p = /** @type {V} */
  t[e], p === void 0 && n !== void 0 && (p = d(), h && (s && Fn(), h(p)));
  var S;
  if (s ? S = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ === void 0 ? d() : (f = !0, _);
  } : S = () => {
    var _ = (
      /** @type {V} */
      t[e]
    );
    return _ !== void 0 && (o = /** @type {V} */
    void 0), _ === void 0 ? o : _;
  }, s && (r & Dn) === 0)
    return S;
  if (h) {
    var E = t.$$legacy;
    return (
      /** @type {() => V} */
      (function(_, x) {
        return arguments.length > 0 ? ((!s || !x || E || T) && h(x ? S() : _), _) : S();
      })
    );
  }
  var u = !1, v = ((r & Hn) !== 0 ? Kr : Ur)(() => (u = !1, S()));
  a && i(v);
  var B = (
    /** @type {Effect} */
    _r
  );
  return (
    /** @type {() => V} */
    (function(_, x) {
      if (arguments.length > 0) {
        const z = x ? i(v) : s && a ? qt(_) : _;
        return w(v, z), u = !0, o !== void 0 && (o = z), _;
      }
      return Un && u || (B.f & Vn) !== 0 ? v.v : i(v);
    })
  );
}
Yn();
var Sa = /* @__PURE__ */ Et('<svg class="resize-handle svelte-1brspkc" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-1brspkc"></line></svg>'), za = /* @__PURE__ */ q("<!> <!>", 1), Aa = /* @__PURE__ */ q('<div class="placeholder svelte-1brspkc"></div>'), La = /* @__PURE__ */ q("<!> <!>", 1);
function Ca(t, e) {
  Ot(e, !1);
  let r = m(e, "height", 8, void 0), n = m(e, "min_height", 8, void 0), s = m(e, "max_height", 8, void 0), a = m(e, "width", 8, void 0), l = m(e, "elem_id", 8, ""), o = m(e, "elem_classes", 24, () => []), f = m(e, "variant", 8, "solid"), d = m(e, "border_mode", 8, "base"), h = m(e, "padding", 8, !0), y = m(e, "type", 8, "normal"), p = m(e, "test_id", 8, void 0), T = m(e, "explicit_call", 8, !1), S = m(e, "container", 8, !0), E = m(e, "visible", 8, !0), u = m(e, "allow_overflow", 8, !0), v = m(e, "overflow_behavior", 8, "auto"), B = m(e, "scale", 8, null), _ = m(e, "min_width", 8, 0), x = m(e, "flex", 12, !1), z = m(e, "resizable", 8, !1), N = m(e, "rtl", 8, !1), b = m(e, "fullscreen", 12, !1), U = m(e, "label", 8, void 0), D = vt(b()), P = vt(), Me = y() === "fieldset" ? "fieldset" : "div", Ue = vt(0), Ye = vt(0), Y = vt(null);
  function ct(G) {
    b() && G.key === "Escape" && b(!1);
  }
  const Ke = (G) => {
    if (G !== void 0) {
      if (typeof G == "number")
        return G + "px";
      if (typeof G == "string")
        return G;
    }
  }, $e = (G) => {
    let re = G.clientY;
    const W = (tt) => {
      const ne = tt.clientY - re;
      re = tt.clientY, Wn(P, i(P).style.height = `${i(P).offsetHeight + ne}px`);
    }, ue = () => {
      window.removeEventListener("mousemove", W), window.removeEventListener("mouseup", ue);
    };
    window.addEventListener("mousemove", W), window.addEventListener("mouseup", ue);
  };
  Tr(
    () => (Le(b()), i(D), i(P)),
    () => {
      b() !== i(D) && (w(D, b()), b() ? (w(Y, i(P).getBoundingClientRect()), w(Ue, i(P).offsetHeight), w(Ye, i(P).offsetWidth), window.addEventListener("keydown", ct)) : (w(Y, null), window.removeEventListener("keydown", ct)));
    }
  ), Tr(() => Le(E()), () => {
    E() || x(!1);
  }), Kn(), ba();
  var et = Ve(), Te = Q(et);
  {
    var Se = (G) => {
      var re = La(), W = Q(re);
      oa(W, () => Me, !1, (ne, je) => {
        lt(ne, (Pe) => w(P, Pe), () => i(P)), ga(
          ne,
          (Pe, Oe) => ({
            "data-testid": p(),
            id: l(),
            class: `block ${Pe ?? ""}`,
            dir: N() ? "rtl" : "ltr",
            "aria-label": U(),
            style: "",
            [Lt]: {
              hidden: E() === "hidden",
              padded: h(),
              flex: x(),
              border_focus: d() === "focus",
              border_contrast: d() === "contrast",
              "hide-container": !T() && !S(),
              fullscreen: b(),
              animating: b() && i(Y) !== null,
              "auto-margin": B() === null
            },
            [bt]: Oe
          }),
          [
            () => (Le(o()), Z(() => o()?.join(" ") || "")),
            () => ({
              height: (Le(b()), Le(r()), Z(() => b() ? void 0 : Ke(r()))),
              "min-height": (Le(b()), Le(n()), Z(() => b() ? void 0 : Ke(n()))),
              "max-height": (Le(b()), Le(s()), Z(() => b() ? void 0 : Ke(s()))),
              "--start-top": (i(Y), Z(() => i(Y) ? `${i(Y).top}px` : "0px")),
              "--start-left": (i(Y), Z(() => i(Y) ? `${i(Y).left}px` : "0px")),
              "--start-width": (i(Y), Z(() => i(Y) ? `${i(Y).width}px` : "0px")),
              "--start-height": (i(Y), Z(() => i(Y) ? `${i(Y).height}px` : "0px")),
              width: (Le(b()), Le(a()), Z(() => b() ? void 0 : typeof a() == "number" ? `calc(min(${a()}px, 100%))` : Ke(a()))),
              "border-style": f(),
              overflow: u() ? v() : "hidden",
              "flex-grow": B(),
              "min-width": `calc(min(${_()}px, 100%))`
            })
          ],
          void 0,
          void 0,
          "svelte-1brspkc"
        );
        var pe = za(), ge = Q(pe);
        cr(ge, e, "default", {});
        var xe = O(ge, 2);
        {
          var Mt = (Pe) => {
            var Oe = Sa();
            de("mousedown", Oe, $e), k(Pe, Oe);
          };
          F(xe, (Pe) => {
            z() && Pe(Mt);
          });
        }
        k(je, pe);
      });
      var ue = O(W, 2);
      {
        var tt = (ne) => {
          var je = Aa();
          let pe;
          j(() => pe = Ie(je, "", pe, {
            height: i(Ue) + "px",
            width: i(Ye) + "px"
          })), k(ne, je);
        };
        F(ue, (ne) => {
          b() && ne(tt);
        });
      }
      k(G, re);
    };
    F(Te, (G) => {
      (E() === !0 || E() === "hidden") && G(Se);
    });
  }
  k(t, et), Pt();
}
var Ia = /* @__PURE__ */ q('<label for="" data-testid="block-label"><span class="svelte-29fz3m"><!></span> </label>');
function Pa(t, e) {
  let r = m(e, "label", 8, null), n = m(e, "Icon", 8), s = m(e, "show_label", 8, !0), a = m(e, "disable", 8, !1), l = m(e, "float", 8, !0), o = m(e, "rtl", 8, !1);
  var f = Ia();
  let d;
  var h = H(f), y = H(h);
  n()(y, {});
  var p = O(h);
  j(() => {
    Ce(f, "dir", o() ? "rtl" : "ltr"), d = Ee(f, 1, "svelte-29fz3m", null, d, {
      hide: !s(),
      "sr-only": !s(),
      float: l(),
      "hide-label": a()
    }), oe(p, ` ${r() ?? ""}`), f.dir = f.dir;
  }), k(t, f);
}
function Oa(t) {
  Vt === null && Xn(), Wr && Vt.l !== null ? Na(Vt).m.push(t) : ce(() => {
    const e = Z(t);
    if (typeof e == "function") return (
      /** @type {() => void} */
      e
    );
  });
}
function Na(t) {
  var e = (
    /** @type {ComponentContextLegacy} */
    t.l
  );
  return e.u ??= { a: [], b: [], m: [] };
}
var Ra = /* @__PURE__ */ q('<span class="svelte-y5xc0a"> </span>'), Fa = /* @__PURE__ */ q("<button><!> <div><!> <!></div></button>");
function Ut(t, e) {
  let r = m(e, "label", 3, ""), n = m(e, "show_label", 3, !1), s = m(e, "pending", 3, !1), a = m(e, "size", 3, "small"), l = m(e, "padded", 3, !0), o = m(e, "highlight", 3, !1), f = m(e, "disabled", 3, !1), d = m(e, "hasPopup", 3, !1), h = m(e, "color", 3, "var(--block-label-text-color)"), y = m(e, "transparent", 3, !1), p = m(e, "background", 3, "var(--block-background-fill)"), T = m(e, "border", 3, "transparent"), S = te(() => o() ? "var(--color-accent)" : h());
  var E = Fa();
  let u;
  E.__click = function(...D) {
    e.onclick?.apply(this, D);
  };
  let v;
  var B = H(E);
  {
    var _ = (D) => {
      var P = Ra(), Me = H(P);
      j(() => oe(Me, r())), k(D, P);
    };
    F(B, (D) => {
      n() && D(_);
    });
  }
  var x = O(B, 2);
  let z;
  var N = H(x);
  ia(N, () => e.Icon, (D, P) => {
    P(D, {});
  });
  var b = O(N, 2);
  {
    var U = (D) => {
      var P = Ve(), Me = Q(P);
      aa(Me, () => e.children), k(D, P);
    };
    F(b, (D) => {
      e.children && D(U);
    });
  }
  j(() => {
    u = Ee(E, 1, "icon-button svelte-y5xc0a", null, u, {
      pending: s(),
      padded: l(),
      highlight: o(),
      transparent: y()
    }), E.disabled = f(), Ce(E, "aria-label", r()), Ce(E, "aria-haspopup", d()), Ce(E, "title", r()), v = Ie(E, "", v, {
      "--border-color": T(),
      color: !f() && i(S) ? i(S) : "var(--block-label-text-color)",
      "--bg-color": f() ? "auto" : p()
    }), z = Ee(x, 1, "svelte-y5xc0a", null, z, {
      "x-small": a() === "x-small",
      small: a() === "small",
      large: a() === "large",
      medium: a() === "medium"
    });
  }), k(t, E);
}
It(["click"]);
var Da = /* @__PURE__ */ Et('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
function Nr(t) {
  var e = Da();
  k(t, e);
}
var Va = /* @__PURE__ */ Et('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
function Ba(t) {
  var e = Va();
  k(t, e);
}
var ja = /* @__PURE__ */ Et('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
function Ha(t) {
  var e = ja();
  k(t, e);
}
var qa = /* @__PURE__ */ Et('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
function Ua(t) {
  var e = qa();
  k(t, e);
}
const Ya = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Rr = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ya.reduce((t, { color: e, primary: r, secondary: n }) => ({
  ...t,
  [e]: {
    primary: Rr[e][r],
    secondary: Rr[e][n]
  }
}), {});
function Ka(t) {
  let e;
  const r = Gn((s) => {
    let a = !1;
    const l = t.subscribe((o) => {
      e = o, a && s();
    });
    return a = !0, l;
  });
  function n() {
    return Zn() ? (r(), e) : an(t);
  }
  return "set" in t ? {
    get current() {
      return n();
    },
    set current(s) {
      t.set(s);
    }
  } : {
    get current() {
      return n();
    }
  };
}
const Wa = "__i18n__", Za = [
  "label",
  "info",
  "placeholder",
  "description",
  "title",
  "value"
], Ga = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events",
  "register_component",
  "dispatcher"
];
function Xa(t) {
  return typeof t == "string" && t.includes(Wa);
}
class Ja {
  load_component;
  #e = V(qt({}));
  get shared() {
    return i(this.#e);
  }
  set shared(e) {
    w(this.#e, e, !0);
  }
  #t = V(qt({}));
  get props() {
    return i(this.#t);
  }
  set props(e) {
    w(this.#t, e, !0);
  }
  #r = V((e) => e);
  get i18n() {
    return i(this.#r);
  }
  set i18n(e) {
    w(this.#r, e, !0);
  }
  i18n_store;
  _i18n_from_store;
  translatable_props = {};
  dispatcher;
  last_update = null;
  shared_props = Ga;
  mounted = !1;
  old_value;
  register_component;
  constructor(e, r) {
    for (const n in e.shared_props)
      this.shared[n] = e.shared_props[n];
    for (const n in e.props)
      n !== "i18n_store" && (this.props[n] = e.props[n]);
    if (r)
      for (const n in r)
        this.props[n] === void 0 && (this.props[n] = r[n]);
    this.i18n = this.props.i18n ?? ((n) => n), this.i18n_store = e.props.i18n_store, this._i18n_from_store = this.i18n_store ? Ka(this.i18n_store) : void 0;
    for (const n of Za)
      this.shared[n] = this._translate_and_store(
        "shared",
        n,
        // @ts-ignore
        e.shared_props[n]
      ), this.props[n] = this._translate_and_store(
        "props",
        n,
        // @ts-ignore
        e.props[n]
      );
    this.load_component = this.shared.load_component, this.register_component = this.shared.register_component || (() => {
    }), this.dispatcher = this.shared.dispatcher || (() => {
    }), this.register_component(
      e.shared_props.id,
      // @ts-ignore
      this.set_data.bind(this),
      this.get_data.bind(this)
    ), ce(() => {
      for (const n in e.shared_props)
        this._is_i18n_managed(`shared.${n}`, e.shared_props[n]) || (this.shared[n] = e.shared_props[n]);
      for (const n in e.props)
        n !== "i18n_store" && (this._is_i18n_managed(`props.${n}`, e.props[n]) || (this.props[n] = e.props[n]));
      this.register_component(
        e.shared_props.id,
        // @ts-ignore
        this.set_data.bind(this),
        this.get_data.bind(this)
      ), Z(() => {
        this.shared.id = e.shared_props.id;
      });
    }), ce(() => this.i18n_store ? this.i18n_store.subscribe(() => {
      for (const [s, a] of Object.entries(this.translatable_props)) {
        const [l, o] = s.split("."), f = this.i18n(a);
        l === "shared" ? this.shared[o] = f : this.props[o] = f;
      }
    }) : void 0);
  }
  // check if props are translatable
  _is_i18n_managed(e, r) {
    const n = this.translatable_props[e];
    return n ? r === n ? !0 : (delete this.translatable_props[e], !1) : !1;
  }
  _translate_and_store(e, r, n) {
    if (typeof n != "string") return n;
    const s = this.i18n(n);
    return s !== n && (this.translatable_props[`${e}.${r}`] = n), s;
  }
  // Reactive variant of `i18n`. Reading it inside a derived or template
  // subscribes to the live locale store (via Svelte's createSubscriber), so
  // the caller re-runs when the locale changes at runtime. The store is only
  // the reactivity trigger; translation always goes through `this.i18n` so a
  // custom formatter passed via props keeps taking effect.
  live_i18n = (e) => (this._i18n_from_store?.current, this.i18n(e));
  dispatch(e, r) {
    this.dispatcher(this.shared.id, e, r);
  }
  async get_data() {
    return Qn(this.props);
  }
  update(e) {
    this.set_data(e);
  }
  set_data(e) {
    for (const r in e) {
      const n = e[r], s = Xa(n) ? this._translate_and_store(this.shared_props.includes(r) ? "shared" : "props", r, n) : n;
      if (this.shared_props.includes(r)) {
        const a = r;
        this.shared[a] = s;
        continue;
      }
      this.props[r] = s;
    }
  }
  watch_for_change() {
    ce(() => {
      this.mounted || (this.old_value = this.props.value, this.mounted = !0), this.old_value != this.props.value && (this.old_value = this.props.value, this.dispatch("change"));
    });
  }
}
It(["click"]);
function ar(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], r = 0;
  for (; t > 1e3 && r < e.length - 1; )
    t /= 1e3, r++;
  let n = e[r];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + n;
}
function Fr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function ur(t, e, r, n) {
  if (typeof r == "number" || Fr(r)) {
    const s = n - r, a = (r - e) / (t.dt || 1 / 60), l = t.opts.stiffness * s, o = t.opts.damping * a, f = (l - o) * t.inv_mass, d = (a + f) * t.dt;
    return Math.abs(d) < t.opts.precision && Math.abs(s) < t.opts.precision ? n : (t.settled = !1, Fr(r) ? new Date(r.getTime() + d) : r + d);
  } else {
    if (Array.isArray(r))
      return r.map(
        (s, a) => (
          // @ts-ignore
          ur(t, e[a], r[a], n[a])
        )
      );
    if (typeof r == "object") {
      const s = {};
      for (const a in r)
        s[a] = ur(t, e[a], r[a], n[a]);
      return s;
    } else
      throw new Error(`Cannot spring ${typeof r} values`);
  }
}
function Dr(t, e = {}) {
  const r = wa(t), { stiffness: n = 0.15, damping: s = 0.8, precision: a = 0.01 } = e;
  let l, o, f, d = (
    /** @type {T} */
    t
  ), h = (
    /** @type {T | undefined} */
    t
  ), y = 1, p = 0, T = !1;
  function S(u, v = {}) {
    h = u;
    const B = f = {};
    return t == null || v.hard || E.stiffness >= 1 && E.damping >= 1 ? (T = !0, l = Be.now(), d = u, r.set(t = h), Promise.resolve()) : (v.soft && (p = 1 / ((v.soft === !0 ? 0.5 : +v.soft) * 60), y = 0), o || (l = Be.now(), T = !1, o = la((_) => {
      if (T)
        return T = !1, o = null, !1;
      y = Math.min(y + p, 1);
      const x = Math.min(_ - l, 1e3 / 30), z = {
        inv_mass: y,
        opts: E,
        settled: !0,
        dt: x * 60 / 1e3
      }, N = ur(z, d, t, h);
      return l = _, d = /** @type {T} */
      t, r.set(t = /** @type {T} */
      N), z.settled && (o = null), !z.settled;
    })), new Promise((_) => {
      o.promise.then(() => {
        B === f && _();
      });
    }));
  }
  const E = {
    set: S,
    update: (u, v) => S(u(
      /** @type {T} */
      h,
      /** @type {T} */
      t
    ), v),
    subscribe: r.subscribe,
    stiffness: n,
    damping: s,
    precision: a
  };
  return E;
}
var Qa = /* @__PURE__ */ q('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-13if8lc"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-13if8lc"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-13if8lc"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-13if8lc"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-13if8lc"></path></g></svg></div>');
function $a(t, e) {
  Ot(e, !0);
  const r = () => Or(o, "$top", s), n = () => Or(f, "$bottom", s), [s, a] = ya();
  let l = m(e, "margin", 3, !0);
  const o = Dr([0, 0]), f = Dr([0, 0]);
  let d = V(!1);
  async function h() {
    await Promise.all([o.set([125, 140]), f.set([-125, -140])]), await Promise.all([o.set([-125, 140]), f.set([125, -140])]), await Promise.all([o.set([-125, 0]), f.set([125, -0])]), await Promise.all([o.set([125, 0]), f.set([-125, 0])]);
  }
  async function y() {
    await h(), i(d) || y();
  }
  async function p() {
    await Promise.all([o.set([125, 0]), f.set([-125, 0])]), y();
  }
  ce(() => (p(), () => {
    w(d, !0);
  }));
  var T = Qa();
  let S;
  var E = H(T), u = H(E), v = O(u);
  j(() => {
    S = Ee(T, 1, "svelte-13if8lc", null, S, { margin: l() }), Ie(u, `transform: translate(${r()[0] ?? ""}px, ${r()[1] ?? ""}px);`), Ie(v, `transform: translate(${n()[0] ?? ""}px, ${n()[1] ?? ""}px);`);
  }), k(t, T), Pt(), a();
}
let Dt = [], ir = !1;
const ei = typeof window < "u", sn = ei ? window.requestAnimationFrame : (t) => {
}, Vr = /* @__PURE__ */ new Set();
async function ti(t, e = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && e !== !0)) {
    if (Dt.push(t), !ir) ir = !0;
    else return;
    await Gr(), sn(() => {
      let r = [0, 0];
      for (let n = 0; n < Dt.length; n++) {
        const a = Dt[n].getBoundingClientRect();
        (n === 0 || a.top + window.scrollY <= r[0]) && (r[0] = a.top + window.scrollY, r[1] = n);
      }
      window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), ir = !1, Dt = [];
    });
  }
}
var ri = /* @__PURE__ */ q('<div class="validation-error svelte-1uvc87p"> <button class="svelte-1uvc87p"><!></button></div>'), ni = /* @__PURE__ */ q('<div class="eta-bar svelte-1uvc87p"></div>'), ai = /* @__PURE__ */ q("<!> ", 1), ii = /* @__PURE__ */ q("<!> <!> <!> <!>", 1), si = /* @__PURE__ */ q('<div class="progress-level svelte-1uvc87p"><div class="progress-level-inner svelte-1uvc87p"><!></div> <div class="progress-bar-wrap svelte-1uvc87p"><div class="progress-bar svelte-1uvc87p"></div></div></div>'), li = /* @__PURE__ */ q('<p class="loading svelte-1uvc87p"> </p> <!>', 1), oi = /* @__PURE__ */ q("<!> <div><!> <!></div> <!> <!>", 1), ci = /* @__PURE__ */ q('<div class="clear-status svelte-1uvc87p"><!></div> <span class="error svelte-1uvc87p"> </span> <!>', 1), fi = /* @__PURE__ */ q("<div> <!> </div>"), di = /* @__PURE__ */ q('<div data-testid="status-tracker"><!> <!></div> <!>', 1);
function ui(t, e) {
  Ot(e, !0);
  let r = m(e, "eta", 3, null), n = m(e, "component_id", 3, null), s = m(e, "fn_index", 3, null), a = m(e, "scroll_to_output", 3, !1), l = m(e, "timer", 3, !0), o = m(e, "show_progress", 3, "full"), f = m(e, "message", 3, null), d = m(e, "progress", 3, null), h = m(e, "variant", 3, "default"), y = m(e, "loading_text", 3, "Loading..."), p = m(e, "absolute", 3, !0), T = m(e, "translucent", 3, !1), S = m(e, "border", 3, !1), E = m(e, "validation_error", 7, null), u = m(e, "show_validation_error", 3, !0), v = m(e, "type", 3, null), B = m(e, "used_cache", 3, null), _ = m(e, "cache_duration", 3, null), x = m(e, "avg_time", 3, null), z = m(e, "cache_event_id", 3, null), N, b = !1, U = V(0), D = V(null), P = V(null), Me = V(!1), Ue = V(null), Ye = V(!1), Y = V(!1), ct = V(null), Ke = V(null), $e = V("from cache"), et = V(!1), Te = null, Se = null, G = null;
  function re() {
    Te && clearTimeout(Te), Se && clearTimeout(Se), Te = null, Se = null, w(Ye, !1), w(Y, !1);
  }
  const W = te(() => !(u() && E()) && (v() === "input" || !e.status || e.status === "complete" || o() === "hidden" || e.status == "streaming"));
  let ue = V(0);
  const tt = te(() => i(P) === null || i(P) <= 0 || !i(ue) ? 0 : Math.min(i(ue) / i(P), 1)), ne = te(() => i(ue).toFixed(1));
  let je = te(() => d() == null), pe = te(() => r() ?? i(D));
  function ge() {
    sn(() => {
      w(ue, (performance.now() - i(U)) / 1e3), b && ge();
    });
  }
  let xe = te(() => {
    let R = null;
    d() != null ? R = d().map((ie) => {
      if (ie.index != null && ie.length != null)
        return ie.index / ie.length;
      if (ie.progress != null)
        return ie.progress;
    }) : R = null;
    let X, ae = "";
    return R ? (X = R[R.length - 1], X === 0 ? ae = "0" : ae = "150ms") : X = void 0, {
      progress_level: R,
      last_progress_level: X,
      progress_bar_transition: ae
    };
  });
  function Mt() {
    b || (w(D, w(Ue, null), !0), w(U, performance.now(), !0), b = !0, ge());
  }
  function Pe() {
    w(D, w(Ue, null), !0), b && (b = !1);
  }
  ce(() => {
    e.status === "pending" ? Mt() : Z(() => {
      Pe();
    });
  }), ce(() => {
    N && a() && (e.status === "pending" || e.status === "complete") && ti(N, e.autoscroll);
  }), ce(() => {
    i(pe) != null && i(D) !== i(pe) && (w(P, (performance.now() - i(U)) / 1e3 + i(pe)), w(Ue, i(P).toFixed(1), !0), w(D, i(pe), !0));
  });
  function Oe() {
    w(Me, !1);
  }
  ce(() => {
    Z(() => {
      Oe();
    }), e.status === "error" && f() && w(Me, !0);
  }), ce(() => {
    if (e.status === "complete" && v() === "output" && B() && _() != null) {
      const R = z() == null ? null : `${n() ?? s() ?? "unknown"}:${s() ?? "unknown"}:${z()}`;
      if (R === G || R != null && Vr.has(R))
        return;
      G = R, R != null && Vr.add(R), w(ct, _().toFixed(1), !0), w($e, B() === "full" ? "from cache" : "used cache", !0), w(et, x() != null && x() > _() && x() > 0, !0), w(Ke, i(et) ? x().toFixed(1) : null, !0), w(Ye, !0), w(Y, !1), Te && clearTimeout(Te), Se && clearTimeout(Se), Te = setTimeout(
        () => {
          w(Y, !0), Se = setTimeout(
            () => {
              w(Ye, !1), w(Y, !1);
            },
            500
          );
        },
        1750
      );
    } else v() === "output" && !B() && re();
  });
  var Tt = di(), ft = Q(Tt);
  let Nt, We;
  var Ne = H(ft);
  {
    var gt = (R) => {
      var X = ri(), ae = H(X), ie = O(ae), me = H(ie);
      {
        let ze = te(() => e.i18n ? e.i18n("common.clear") : "Clear");
        Ut(me, {
          get Icon() {
            return Nr;
          },
          get label() {
            return i(ze);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          onclick: () => E(null)
        });
      }
      j(() => oe(ae, `${E() ?? ""} `)), k(R, X);
    };
    F(Ne, (R) => {
      E() && u() && R(gt);
    });
  }
  var Zt = O(Ne, 2);
  {
    var Gt = (R) => {
      var X = oi(), ae = Q(X);
      {
        var ie = (L) => {
          var K = ni();
          let se;
          j(() => se = Ie(K, "", se, {
            transform: `translateX(${(i(tt) || 0) * 100 - 100}%)`
          })), k(L, K);
        };
        F(ae, (L) => {
          h() === "default" && i(je) && o() === "full" && L(ie);
        });
      }
      var me = O(ae, 2);
      let ze;
      var Ze = H(me);
      {
        var c = (L) => {
          var K = Ve(), se = Q(K);
          yt(se, 17, d, wt, (he, $) => {
            var fe = Ve(), we = Q(fe);
            {
              var rt = (Re) => {
                var Fe = ai(), Ge = Q(Fe);
                {
                  var St = (ye) => {
                    var He = qe();
                    j((at, ut) => oe(He, `${at ?? ""}/${ut ?? ""}`), [
                      () => ar(i($).index || 0),
                      () => ar(i($).length)
                    ]), k(ye, He);
                  }, Xe = (ye) => {
                    var He = qe();
                    j((at) => oe(He, at), [() => ar(i($).index || 0)]), k(ye, He);
                  };
                  F(Ge, (ye) => {
                    i($).length != null ? ye(St) : ye(Xe, !1);
                  });
                }
                var nt = O(Ge);
                j(() => oe(nt, ` ${i($).unit ?? ""} |  `)), k(Re, Fe);
              };
              F(we, (Re) => {
                i($).index != null && Re(rt);
              });
            }
            k(he, fe);
          }), k(L, K);
        }, g = (L) => {
          var K = Ve(), se = Q(K);
          {
            var he = (fe) => {
              var we = qe();
              j(() => oe(we, `queue: ${e.queue_position + 1}/${e.queue_size ?? ""} |`)), k(fe, we);
            }, $ = (fe) => {
              var we = Ve(), rt = Q(we);
              {
                var Re = (Fe) => {
                  var Ge = qe("processing |");
                  k(Fe, Ge);
                };
                F(
                  rt,
                  (Fe) => {
                    e.queue_position === 0 && Fe(Re);
                  },
                  !0
                );
              }
              k(fe, we);
            };
            F(
              se,
              (fe) => {
                e.queue_position !== null && e.queue_size !== void 0 && e.queue_position >= 0 ? fe(he) : fe($, !1);
              },
              !0
            );
          }
          k(L, K);
        };
        F(Ze, (L) => {
          d() ? L(c) : L(g, !1);
        });
      }
      var M = O(Ze, 2);
      {
        var C = (L) => {
          var K = qe();
          j(() => oe(K, `${i(ne) ?? ""}${r() ? `/${i(Ue)}` : ""}s`)), k(L, K);
        };
        F(M, (L) => {
          l() && L(C);
        });
      }
      var I = O(me, 2);
      {
        var ke = (L) => {
          var K = si(), se = H(K), he = H(se);
          {
            var $ = (Re) => {
              var Fe = Ve(), Ge = Q(Fe);
              yt(Ge, 17, d, wt, (St, Xe, nt) => {
                var ye = Ve(), He = Q(ye);
                {
                  var at = (ut) => {
                    var Rt = ii(), A = Q(Rt);
                    {
                      var le = (J) => {
                        var _e = qe(" /");
                        k(J, _e);
                      };
                      F(A, (J) => {
                        nt !== 0 && J(le);
                      });
                    }
                    var ee = O(A, 2);
                    {
                      var ve = (J) => {
                        var _e = qe();
                        j(() => oe(_e, i(Xe).desc)), k(J, _e);
                      };
                      F(ee, (J) => {
                        i(Xe).desc != null && J(ve);
                      });
                    }
                    var De = O(ee, 2);
                    {
                      var it = (J) => {
                        var _e = qe("-");
                        k(J, _e);
                      };
                      F(De, (J) => {
                        i(Xe).desc != null && i(xe).progress_level && i(xe).progress_level[nt] != null && J(it);
                      });
                    }
                    var Je = O(De, 2);
                    {
                      var ht = (J) => {
                        var _e = qe();
                        j(($t) => oe(_e, `${$t ?? ""}%`), [
                          () => (100 * (i(xe).progress_level[nt] || 0)).toFixed(1)
                        ]), k(J, _e);
                      };
                      F(Je, (J) => {
                        i(xe).progress_level != null && J(ht);
                      });
                    }
                    k(ut, Rt);
                  };
                  F(He, (ut) => {
                    (i(Xe).desc != null || i(xe).progress_level && i(xe).progress_level[nt] != null) && ut(at);
                  });
                }
                k(St, ye);
              }), k(Re, Fe);
            };
            F(he, (Re) => {
              d() != null && Re($);
            });
          }
          var fe = O(se, 2), we = H(fe);
          let rt;
          j(() => rt = Ie(we, "", rt, {
            width: `${i(xe).last_progress_level * 100}%`,
            transition: i(xe).progress_bar_transition
          })), k(L, K);
        }, be = (L) => {
          var K = Ve(), se = Q(K);
          {
            var he = ($) => {
              {
                let fe = te(() => h() === "default");
                $a($, {
                  get margin() {
                    return i(fe);
                  }
                });
              }
            };
            F(
              se,
              ($) => {
                o() === "full" && $(he);
              },
              !0
            );
          }
          k(L, K);
        };
        F(I, (L) => {
          i(xe).last_progress_level != null ? L(ke) : L(be, !1);
        });
      }
      var Ae = O(I, 2);
      {
        var dt = (L) => {
          var K = li(), se = Q(K), he = H(se), $ = O(se, 2);
          cr($, e, "additional-loading-text", {}), j(() => oe(he, y())), k(L, K);
        };
        F(Ae, (L) => {
          l() || L(dt);
        });
      }
      j(() => ze = Ee(me, 1, "progress-text svelte-1uvc87p", null, ze, {
        "meta-text-center": h() === "center",
        "meta-text": h() === "default"
      })), k(R, X);
    }, Xt = (R) => {
      var X = Ve(), ae = Q(X);
      {
        var ie = (me) => {
          var ze = ci(), Ze = Q(ze), c = H(Ze);
          {
            let I = te(() => e.i18n("common.clear"));
            Ut(c, {
              get Icon() {
                return Nr;
              },
              get label() {
                return i(I);
              },
              disabled: !1,
              onclick: () => {
                e.on_clear_status?.();
              }
            });
          }
          var g = O(Ze, 2), M = H(g), C = O(g, 2);
          cr(C, e, "error", {}), j((I) => oe(M, I), [() => e.i18n("common.error")]), k(me, ze);
        };
        F(
          ae,
          (me) => {
            e.status === "error" && me(ie);
          },
          !0
        );
      }
      k(R, X);
    };
    F(Zt, (R) => {
      e.status === "pending" ? R(Gt) : R(Xt, !1);
    });
  }
  lt(ft, (R) => N = R, () => N);
  var Jt = O(ft, 2);
  {
    var Qt = (R) => {
      var X = fi();
      let ae, ie;
      var me = H(X), ze = O(me);
      {
        var Ze = (g) => {
          var M = qe();
          j(() => oe(M, `~${i(Ke) ?? ""}s
			→ `)), k(g, M);
        };
        F(ze, (g) => {
          i(et) && g(Ze);
        });
      }
      var c = O(ze);
      j(() => {
        ae = Ee(X, 1, "cache-indicator svelte-1uvc87p", null, ae, { "fade-out": i(Y) }), ie = Ie(X, "", ie, { position: p() ? "absolute" : "static" }), oe(me, `⚡ ${i($e) ?? ""}: `), oe(c, `${i(ct) ?? ""}s`);
      }), k(R, X);
    };
    F(Jt, (R) => {
      i(Ye) && R(Qt);
    });
  }
  j(() => {
    Nt = Ee(ft, 1, `wrap ${h() ?? ""} ${o() ?? ""}`, "svelte-1uvc87p", Nt, {
      "no-click": E() && u(),
      hide: i(W),
      translucent: h() === "center" && (e.status === "pending" || e.status === "error") || T() || o() === "minimal" || E(),
      generating: e.status === "generating" && o() === "full",
      border: S()
    }), We = Ie(ft, "", We, {
      position: p() ? "absolute" : "static",
      padding: p() ? "0" : "var(--size-8) 0"
    });
  }), k(t, Tt), Pt();
}
const hi = (t) => {
  const e = {};
  for (let r = 0, n = t.length; r < n; r++) {
    const s = t[r];
    for (const a in s)
      e[a] ? e[a] = e[a].concat(s[a]) : e[a] = s[a];
  }
  return e;
}, vi = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], _i = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], pi = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
hi([
  Object.fromEntries(vi.map((t) => [t, ["*"]])),
  Object.fromEntries(_i.map((t) => [t, ["svg:*"]])),
  Object.fromEntries(pi.map((t) => [t, ["math:*"]]))
]);
It(["touchstart", "touchmove", "touchend", "click", "keydown"]);
function gi(t, e) {
  Ot(e, !0);
  function r(f) {
    return f instanceof HTMLElement && (f.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(f.tagName));
  }
  function n(f) {
    f.key.toLowerCase() !== "f" || f.repeat || f.defaultPrevented || f.altKey || f.ctrlKey || f.metaKey || r(f.target) && !e.hovered() || (f.preventDefault(), e.onclick(!e.fullscreen));
  }
  var s = Ve();
  de("keydown", Bt, n);
  var a = Q(s);
  {
    var l = (f) => {
      Ut(f, {
        get Icon() {
          return Ua;
        },
        get label() {
          return e.exit_label;
        },
        onclick: () => e.onclick(!1)
      });
    }, o = (f) => {
      Ut(f, {
        get Icon() {
          return Ha;
        },
        get label() {
          return e.label;
        },
        onclick: () => e.onclick(!0)
      });
    };
    F(a, (f) => {
      e.fullscreen ? f(l) : f(o, !1);
    });
  }
  k(t, s), Pt();
}
const mi = "canvas-host", Br = "canvas-host-request";
class bi extends EventTarget {
  constructor(e, r, n, s, a, l, o) {
    super(), this.id = e, this.doc_el = r, this.frame = n, this.image = s, this.area = a, this.toolbars = l, this.tool_groups = o, this.#e = o.flat()[0] ?? null;
  }
  id;
  doc_el;
  frame;
  image;
  area;
  toolbars;
  tool_groups;
  #e;
  /** ID of the active tool, if any. */
  get tool() {
    return this.#e;
  }
  set tool(e) {
    e !== this.#e && (this.#e = e, this.#t(), this.dispatchEvent(new Event("tool-change")));
  }
  /** Press the button of the active tool, release the others. */
  #t() {
    for (const e of this.toolbars)
      for (const r of e.children)
        r.querySelector("button")?.setAttribute(
          "aria-pressed",
          String(Number(r.dataset.tool) === this.#e)
        );
  }
  /** Add the button of a tool to the toolbar of its group, in tools order. */
  add_tool(e, r) {
    const n = this.tool_groups.findIndex((o) => o.includes(e)), s = this.toolbars[n];
    if (!s) return;
    const a = (o) => this.tool_groups[n].indexOf(Number(o.dataset.tool));
    r.dataset.tool = String(e);
    const l = [...s.children].find((o) => a(o) > a(r));
    s.insertBefore(r, l ?? null), this.#t();
  }
}
var wi = /* @__PURE__ */ Et('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="9.3 14.3 41.7 37.8"><defs><clipPath id="canvas-photos-clip"><rect x="-16" y="-11" width="32" height="22" rx="0.5"></rect></clipPath><g id="canvas-photos-hills"><circle cx="-14" cy="16" r="12" fill="#56b65b"></circle><circle cx="0" cy="17" r="13" fill="#66c763"></circle><circle cx="15" cy="15" r="14" fill="#7be161"></circle></g></defs><g transform="translate(29 36.5) rotate(9)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#ff9e7a"></rect><circle cx="-11" cy="3" r="3.5" fill="#ffd166"></circle><rect x="-16" y="3" width="32" height="8" fill="#3a8fd9"></rect><g fill="#8cc8ff"><rect x="-14" y="4.5" width="6" height="0.8" rx="0.4"></rect><rect x="-12.5" y="6.2" width="3" height="0.8" rx="0.4"></rect></g><ellipse cx="4" cy="15" rx="18" ry="6.5" fill="#f2d29b"></ellipse></g></g><g transform="translate(31.8 29) rotate(-6)"><rect x="-17.2" y="-12.2" width="34.4" height="24.4" rx="1" fill="#f2f3fa"></rect><g clip-path="url(#canvas-photos-clip)"><rect x="-16" y="-11" width="32" height="22" fill="#52b2ff"></rect><circle cx="-4" cy="-4" r="2.5" fill="#ffcb57"></circle><g fill="#e6e6f6"><circle cx="-15" cy="-1" r="4"></circle><circle cx="-10" cy="0" r="3"></circle><circle cx="10.5" cy="-6.8" r="1.2"></circle><circle cx="12.2" cy="-7.2" r="1.6"></circle><rect x="9.3" y="-6.6" width="6" height="1.6" rx="0.8"></rect></g><use href="#canvas-photos-hills"></use></g></g></svg>');
function yi(t) {
  var e = wi();
  k(t, e);
}
var xi = /* @__PURE__ */ q('<img class="layer svelte-1sbzryu" alt=""/>'), ki = /* @__PURE__ */ q('<div class="zoom-hint svelte-1sbzryu"> </div>'), Ei = /* @__PURE__ */ q('<p class="svelte-1sbzryu"> </p>'), Mi = /* @__PURE__ */ q('<div class="placeholder svelte-1sbzryu"><div class="placeholder-art svelte-1sbzryu" aria-hidden="true"><!></div> <!></div>'), Ti = /* @__PURE__ */ q('<img class="layer svelte-1sbzryu" alt="" loading="lazy"/>'), Si = /* @__PURE__ */ q('<button class="thumb svelte-1sbzryu" role="option"></button>'), zi = /* @__PURE__ */ q('<div class="thumbs-bar svelte-1sbzryu"><button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Previous"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M10 4L6 8L10 12"></path></svg></button> <div role="listbox" aria-orientation="horizontal" tabindex="-1"></div> <button class="thumbs-arrow svelte-1sbzryu" tabindex="-1" aria-label="Next"><svg viewBox="0 0 16 16" aria-hidden="true" class="svelte-1sbzryu"><path d="M6 4L10 8L6 12"></path></svg></button></div>'), Ai = /* @__PURE__ */ q('<div class="group svelte-1sbzryu"><!></div>'), Li = /* @__PURE__ */ q('<div class="group toolbar svelte-1sbzryu" role="toolbar"></div>'), Ci = /* @__PURE__ */ q('<!> <!> <div role="group"><div><div><img class="layer svelte-1sbzryu" alt=""/> <!></div> <!></div> <!> <!>  <div><!> <!></div></div>', 1);
function Pi(t, e) {
  Ot(e, !0);
  let r = null;
  class n extends Ja {
    // Events wait for dropped images, to pass them.
    async get_data() {
      return r && (await r, await Gr()), super.get_data();
    }
  }
  const s = /* @__PURE__ */ Ea(e, ["$$slots", "$$events", "$$legacy"]), a = new n(s), l = te(() => a.props.value ?? { docs: [], index: null }), o = te(() => i(l).index === null ? null : i(l).docs[i(l).index] ?? null);
  let f = V(!1), d = V(!1), h = !1, y, p, T, S;
  const E = [];
  let u = V(void 0), v = V(0);
  function B(c) {
    return c.layers[0].object.path;
  }
  function _(c) {
    return { index: c, path: B(i(l).docs[c]) };
  }
  function x(c, g) {
    a.props.value = { docs: c, index: g };
  }
  function z(c) {
    c !== i(l).index && (x(i(l).docs, c), a.dispatch("input"));
  }
  let N = Z(() => i(l).docs.map(B)), b = Z(() => i(o) && B(i(o)));
  ce(() => {
    const c = i(l).docs.map(B), g = i(o) && B(i(o));
    Z(() => U(c, g));
  });
  function U(c, g) {
    g === b && c.join(`
`) === N.join(`
`) || (N.forEach((M, C) => {
      c.includes(M) || a.dispatch("doc_deleted", { index: C, path: M });
    }), c.forEach((M, C) => {
      N.includes(M) || a.dispatch("doc_added", { index: C, path: M });
    }), N.length && !c.length ? a.dispatch("empty") : !N.length && c.length && a.dispatch("filled"), g !== b && i(l).index !== null && a.dispatch("select", _(i(l).index)), N = c, b = g, a.dispatch("change"));
  }
  ce(() => {
    const c = i(l).index === null ? null : i(u)?.children[i(l).index];
    c instanceof HTMLElement && (c.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" }), i(u)?.contains(document.activeElement) && c.focus({ preventScroll: !0 }));
  });
  let D = V(!1), P = V(!1);
  function Me() {
    if (!i(u)) return;
    const { scrollLeft: c, scrollWidth: g, clientWidth: M } = i(u);
    w(D, c > 1), w(P, c + M < g - 1);
  }
  ce(() => {
    if (!i(u)) return;
    i(l).docs.length, Me();
    const c = new ResizeObserver(Me);
    return c.observe(i(u)), () => c.disconnect();
  });
  function Ue(c) {
    a.dispatch("thumb_click", _(c)), z(c);
  }
  function Ye(c) {
    const g = i(l).index, M = i(l).docs.length - 1;
    if (g === null || c.altKey || c.ctrlKey || c.metaKey) return;
    const I = {
      ArrowLeft: Math.max(0, g - 1),
      ArrowRight: Math.min(M, g + 1),
      Home: 0,
      End: M
    }[c.key];
    I !== void 0 && (c.preventDefault(), z(I));
  }
  function Y() {
    let c = 0;
    return (g) => {
      const M = g.deltaMode === WheelEvent.DOM_DELTA_PIXEL ? g.deltaY : g.deltaY * 40;
      if (Math.sign(M) !== Math.sign(c) && (c = 0), c += M, Math.abs(c) < 50) return 0;
      const C = Math.sign(c);
      return c = 0, C;
    };
  }
  const ct = Y();
  function Ke(c) {
    if (i(l).index === null || c.ctrlKey || Math.abs(c.deltaY) <= Math.abs(c.deltaX))
      return;
    c.preventDefault();
    const g = ct(c);
    g && $e(g);
  }
  function $e(c) {
    i(l).index !== null && z(Math.min(i(l).docs.length - 1, Math.max(0, i(l).index + c)));
  }
  const et = 2 ** (1 / 3);
  let Te = V(0), Se = V(0);
  const G = te(() => [i(Te), i(Se)]);
  let re = V(null), W = V(0), ue = V(qt([0.5, 0.5]));
  const tt = Y();
  function ne(c) {
    const g = et ** c, M = i(Te) * g, C = i(Se) * g;
    if (!i(re)) return [M, C];
    const I = Math.min(M / i(re).width, C / i(re).height);
    return [i(re).width * I, i(re).height * I];
  }
  function je(c, g, M) {
    return g <= c ? (c - g) / 2 : Math.min(0, Math.max(c - g, c / 2 - M * g));
  }
  function pe(c, g) {
    const M = ne(c);
    return [0, 1].map((C) => {
      const I = i(G)[C];
      return (I / 2 - je(I, M[C], g[C])) / M[C];
    });
  }
  const ge = te(() => {
    if (!i(re)) return null;
    const c = ne(i(W)), [g, M] = [0, 1].map((C) => je(i(G)[C], c[C], i(ue)[C]));
    return { left: g, top: M, width: c[0], height: c[1] };
  }), xe = te(() => i(W) > 0 && !!i(re) && ne(i(W))[0] * devicePixelRatio >= i(re).width);
  ce(() => {
    i(o) || w(W, 0);
  });
  function Mt(c) {
    const g = a.props.max_zoom_levels ?? 0;
    if (!i(o) || g <= 0 || Math.abs(c.deltaY) <= Math.abs(c.deltaX)) return;
    c.preventDefault();
    const M = Math.min(g, Math.max(0, i(W) - tt(c)));
    if (M === i(W)) return;
    const C = p.getBoundingClientRect(), I = [c.clientX - C.left, c.clientY - C.top], ke = ne(i(W)), be = ne(M);
    w(
      ue,
      pe(M, [0, 1].map((Ae) => {
        const dt = i(G)[Ae];
        return (I[Ae] - je(dt, ke[Ae], i(ue)[Ae])) / ke[Ae] + (dt / 2 - I[Ae]) / be[Ae];
      })),
      !0
    ), w(W, M, !0);
  }
  function Pe() {
    w(re, { width: S.naturalWidth, height: S.naturalHeight }, !0);
  }
  let Oe = V(!1);
  ce(() => {
    if (!i(W)) return;
    w(Oe, !0);
    const c = setTimeout(() => w(Oe, !1), 2500);
    return () => {
      clearTimeout(c), w(Oe, !1);
    };
  });
  function Tt(c, g, M) {
    const C = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="-3.5 -3.5 31 31" fill="none" stroke-linecap="round" stroke-linejoin="round"><g stroke="white" stroke-width="4">${c}</g><path fill="white" d="${g}"/><g stroke="black" stroke-width="2">${c}</g></svg>`;
    return `url("data:image/svg+xml,${encodeURIComponent(C)}") 12 12, ${M}`;
  }
  const ft = Tt('<path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>', "M6 14V6a2 2 0 0 1 4 0V4a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82Z", "grab"), Nt = Tt('<path d="M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4"/><path d="M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5"/><path d="M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0"/>', "M2 14a2 2 0 0 1 4 0V9a2 2 0 0 1 4 0V8a2 2 0 0 1 4 0v1a2 2 0 0 1 4 0v2a2 2 0 0 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8Z", "grabbing");
  let We = V(!1), Ne = V(null);
  const gt = te(() => i(Ne) ? Nt : i(We) && i(W) ? ft : null);
  function Zt(c) {
    c.code !== "Space" || c.altKey || c.ctrlKey || c.metaKey || !p.matches(":hover") || (c.preventDefault(), w(We, !0));
  }
  function Gt(c) {
    c.code !== "Space" || !i(We) || (c.preventDefault(), w(We, !1));
  }
  function Xt() {
    document.activeElement instanceof HTMLElement && document.activeElement.blur();
  }
  function Jt(c) {
    Xt(), !(!i(We) || !i(W) || c.button !== 0 || !T.contains(c.target)) && (c.preventDefault(), c.stopPropagation(), p.setPointerCapture(c.pointerId), w(
      Ne,
      {
        id: c.pointerId,
        client: [c.clientX, c.clientY],
        center: pe(i(W), i(ue))
      },
      !0
    ));
  }
  function Qt(c) {
    if (c.pointerId !== i(Ne)?.id) return;
    const { client: g, center: M } = i(Ne), C = ne(i(W)), I = [c.clientX - g[0], c.clientY - g[1]];
    w(ue, pe(i(W), [0, 1].map((ke) => M[ke] - I[ke] / C[ke])), !0);
  }
  function R(c) {
    c.pointerId === i(Ne)?.id && w(Ne, null);
  }
  function X(c) {
    if (i(gt)) {
      c.preventDefault();
      return;
    }
    const g = c.target;
    !(g instanceof HTMLImageElement) || !c.dataTransfer || (h = !0, c.dataTransfer.setData("text/uri-list", g.currentSrc));
  }
  function ae(c) {
    return a.shared.interactive !== !1 && !h && !!c.dataTransfer?.types.includes("Files");
  }
  function ie(c) {
    ae(c) && (c.preventDefault(), c.dataTransfer.dropEffect = "copy", w(d, !0));
  }
  function me(c) {
    y.contains(c.relatedTarget) || w(d, !1);
  }
  function ze(c) {
    if (w(d, !1), !ae(c)) return;
    c.preventDefault();
    const g = [...c.dataTransfer.files].filter((M) => M.type.startsWith("image/"));
    g.length && (r = Ze(g).finally(() => r = null));
  }
  async function Ze(c) {
    let g;
    try {
      g = await a.shared.client.upload(
        c.map((I) => ({
          path: I.name,
          orig_name: I.name,
          blob: I,
          size: I.size,
          mime_type: I.type,
          is_stream: !1,
          meta: { _type: "gradio.FileData" }
        })),
        a.shared.root,
        void 0,
        a.shared.max_file_size ?? void 0
      );
    } catch (I) {
      a.dispatch("error", I instanceof Error ? I.message : String(I));
      return;
    }
    const M = (g ?? []).filter((I) => I !== null).map((I) => ({
      layers: [{ object: I, imported: !0, source_file: null }],
      caption: null
    }));
    if (!M.length) return;
    const C = i(l).docs.length;
    x([...i(l).docs, ...M], C + M.length - 1), M.forEach((I, ke) => a.dispatch("doc_dropped", _(C + ke))), a.dispatch("input");
  }
  Oa(() => {
    const c = new bi(a.shared.id, T, p, S, y, E, a.props.tools ?? []);
    c.addEventListener("tool-change", () => a.dispatch("tool_selected", { tool: c.tool }));
    const g = (M) => {
      const C = M.detail;
      C.canvas_id === c.id && C.resolve(c);
    };
    return window.addEventListener(Br, g), window.dispatchEvent(new CustomEvent(mi, { detail: c })), () => window.removeEventListener(Br, g);
  }), de("keydown", Bt, Zt), de("keyup", Bt, Gt), de("blur", Bt, () => w(We, !1));
  {
    let c = te(() => a.props.height ?? void 0);
    Ca(t, {
      get visible() {
        return a.shared.visible;
      },
      variant: "solid",
      padding: !1,
      get elem_id() {
        return a.shared.elem_id;
      },
      get elem_classes() {
        return a.shared.elem_classes;
      },
      get container() {
        return a.shared.container;
      },
      get scale() {
        return a.shared.scale;
      },
      get min_width() {
        return a.shared.min_width;
      },
      allow_overflow: !1,
      get height() {
        return i(c);
      },
      get fullscreen() {
        return i(f);
      },
      set fullscreen(g) {
        w(f, g, !0);
      },
      children: (g, M) => {
        var C = Ci(), I = Q(C);
        ui(I, Ta(
          {
            get autoscroll() {
              return a.shared.autoscroll;
            },
            get i18n() {
              return a.i18n;
            }
          },
          () => a.shared.loading_status,
          {
            on_clear_status: () => a.dispatch("clear_status", a.shared.loading_status)
          }
        ));
        var ke = O(I, 2);
        {
          let A = te(() => a.shared.label || "Canvas");
          Pa(ke, {
            get show_label() {
              return a.shared.show_label;
            },
            get Icon() {
              return Ba;
            },
            get label() {
              return i(A);
            }
          });
        }
        var be = O(ke, 2);
        let Ae, dt;
        var L = H(be);
        let K;
        L.__pointermove = Qt, L.__pointerup = R;
        let se;
        var he = H(L);
        let $, fe;
        var we = H(he);
        lt(we, (A) => S = A, () => S);
        var rt = O(we, 2);
        yt(rt, 17, () => i(o)?.layers.slice(1) ?? [], wt, (A, le) => {
          var ee = xi();
          j(() => Ce(ee, "src", i(le).object.url)), k(A, ee);
        }), lt(he, (A) => T = A, () => T);
        var Re = O(he, 2);
        {
          var Fe = (A) => {
            var le = ki(), ee = H(le);
            j(() => oe(ee, a.props.pan_tooltip)), k(A, le);
          };
          F(Re, (A) => {
            i(Oe) && a.props.pan_tooltip && A(Fe);
          });
        }
        lt(L, (A) => p = A, () => p);
        var Ge = O(L, 2);
        {
          var St = (A) => {
            var le = Mi(), ee = H(le), ve = H(ee);
            yi(ve);
            var De = O(ee, 2);
            {
              var it = (Je) => {
                var ht = Ei(), J = H(ht);
                j(() => oe(J, a.props.placeholder)), k(Je, ht);
              };
              F(De, (Je) => {
                a.props.placeholder && Je(it);
              });
            }
            k(A, le);
          };
          F(Ge, (A) => {
            i(o) || A(St);
          });
        }
        var Xe = O(Ge, 2);
        {
          var nt = (A) => {
            var le = zi(), ee = H(le);
            ee.__click = () => $e(-1);
            var ve = O(ee, 2);
            let De;
            ve.__keydown = Ye, yt(ve, 21, () => i(l).docs, wt, (Je, ht, J) => {
              var _e = Si();
              _e.__click = () => Ue(J), yt(_e, 21, () => i(ht).layers, wt, ($t, ln) => {
                var xr = Ti();
                j(() => Ce(xr, "src", i(ln).object.url)), k($t, xr);
              }), j(() => {
                Ce(_e, "aria-selected", J === i(l).index), Ce(_e, "title", i(ht).caption ?? void 0);
              }), k(Je, _e);
            }), lt(ve, (Je) => w(u, Je), () => i(u));
            var it = O(ve, 2);
            it.__click = () => $e(1), j(() => {
              ee.disabled = !i(l).index, De = Ee(ve, 1, "thumbs svelte-1sbzryu", null, De, {
                "fade-start": i(D),
                "fade-end": i(P)
              }), it.disabled = i(l).index === null || i(l).index === i(l).docs.length - 1;
            }), de("wheel", le, Ke), de("scroll", ve, Me), k(A, le);
          };
          F(Xe, (A) => {
            i(l).docs.length && A(nt);
          });
        }
        var ye = O(Xe, 2);
        let He;
        ye.__mousedown = (A) => A.preventDefault();
        var at = H(ye);
        {
          var ut = (A) => {
            var le = Ai(), ee = H(le);
            gi(ee, {
              get fullscreen() {
                return i(f);
              },
              onclick: (ve) => w(f, ve, !0),
              get label() {
                return a.props.fullscreen_tooltip;
              },
              get exit_label() {
                return a.props.exit_fullscreen_tooltip;
              },
              hovered: () => y.matches(":hover")
            }), k(A, le);
          };
          F(at, (A) => {
            a.props.buttons?.includes("fullscreen") && A(ut);
          });
        }
        var Rt = O(at, 2);
        yt(Rt, 17, () => a.props.tools ?? [], wt, (A, le, ee) => {
          var ve = Li();
          lt(ve, (De, it) => E[it] = De, (De) => E?.[De], () => [ee]), k(A, ve);
        }), lt(be, (A) => y = A, () => y), j(() => {
          Ae = Ee(be, 1, "canvas svelte-1sbzryu", null, Ae, { "drag-over": i(d), panning: !!i(Ne) }), Ce(be, "aria-label", a.shared.label), dt = Ie(be, "", dt, { cursor: i(Ne) ? i(gt) : void 0 }), K = Ee(L, 1, "frame svelte-1sbzryu", null, K, { hidden: !i(o) }), se = Ie(L, "", se, {
            "margin-inline": i(v) ? `calc(${i(v)}px + var(--spacing-lg))` : void 0
          }), $ = Ee(he, 1, "doc svelte-1sbzryu", null, $, { pixelated: i(xe), panning: !!i(gt) }), fe = Ie(he, "", fe, {
            cursor: i(gt),
            left: i(ge) && `${i(ge).left}px`,
            top: i(ge) && `${i(ge).top}px`,
            width: i(ge) && `${i(ge).width}px`,
            height: i(ge) && `${i(ge).height}px`
          }), Ce(we, "src", i(o)?.layers[0].object.url), He = Ee(ye, 1, "buttons svelte-1sbzryu", null, He, { "below-label": a.shared.show_label });
        }), de("dragstart", be, X), de("dragend", be, () => h = !1), de("dragover", be, ie), de("dragleave", be, me), de("drop", be, ze), de("wheel", L, Mt), de("pointerdown", L, Jt, !0), de("pointercancel", L, R), de("load", we, Pe), nr(L, "clientWidth", (A) => w(Te, A)), nr(L, "clientHeight", (A) => w(Se, A)), nr(ye, "offsetWidth", (A) => w(v, A)), k(g, C);
      },
      $$slots: { default: !0 }
    });
  }
  Pt();
}
It(["pointermove", "pointerup", "click", "keydown", "mousedown"]);
export {
  Pi as default
};
