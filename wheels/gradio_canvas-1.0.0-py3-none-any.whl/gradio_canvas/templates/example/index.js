import { e as U, g as Y, i as q, T as G, a as B, c as P, b as D, r as H, d as p, p as j, f as M, m as z, s as J, h as K, E as W, j as Q, u as V, k as O, l as R, n as A, o as X, q as v, t as T, v as Z, w as $, x as ee, P as te, y as se, z as ae, D as re, A as ne, B as ie, C as fe, F as le, G as ce, S as ue, L as oe, H as L, I as de, J as he, K as _e, M as ve } from "./render-Auu2J1pj.js";
U();
function ge(a) {
  var e = document.createElement("template");
  return e.innerHTML = a.replaceAll("<!>", "<!---->"), e.content;
}
function F(a, e) {
  var s = (
    /** @type {Effect} */
    B
  );
  s.nodes === null && (s.nodes = { start: a, end: e, a: null, t: null });
}
// @__NO_SIDE_EFFECTS__
function me(a, e) {
  var s = (e & G) !== 0, t, i = !a.startsWith("<!>");
  return () => {
    t === void 0 && (t = ge(i ? a : "<!>" + a), t = /** @type {TemplateNode} */
    Y(t));
    var r = (
      /** @type {TemplateNode} */
      s || q ? document.importNode(t, !0) : t.cloneNode(!0)
    );
    return F(r, r), r;
  };
}
function x(a = "") {
  {
    var e = P(a + "");
    return F(e, e), e;
  }
}
function E(a, e) {
  a !== null && a.before(
    /** @type {Node} */
    e
  );
}
class be {
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #t = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #s = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #e = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #a = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #r = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(e, s = !0) {
    this.anchor = e, this.#r = s;
  }
  #n = () => {
    var e = (
      /** @type {Batch} */
      D
    );
    if (this.#t.has(e)) {
      var s = (
        /** @type {Key} */
        this.#t.get(e)
      ), t = this.#s.get(s);
      if (t)
        H(t), this.#a.delete(s);
      else {
        var i = this.#e.get(s);
        i && (this.#s.set(s, i.effect), this.#e.delete(s), i.fragment.lastChild.remove(), this.anchor.before(i.fragment), t = i.effect);
      }
      for (const [r, n] of this.#t) {
        if (this.#t.delete(r), r === e)
          break;
        const f = this.#e.get(n);
        f && (p(f.effect), this.#e.delete(n));
      }
      for (const [r, n] of this.#s) {
        if (r === s || this.#a.has(r)) continue;
        const f = () => {
          if (Array.from(this.#t.values()).includes(r)) {
            var c = document.createDocumentFragment();
            z(n, c), c.append(P()), this.#e.set(r, { effect: n, fragment: c });
          } else
            p(n);
          this.#a.delete(r), this.#s.delete(r);
        };
        this.#r || !t ? (this.#a.add(r), j(n, f, !1)) : f();
      }
    }
  };
  /**
   * @param {Batch} batch
   */
  #i = (e) => {
    this.#t.delete(e);
    const s = Array.from(this.#t.values());
    for (const [t, i] of this.#e)
      s.includes(t) || (p(i.effect), this.#e.delete(t));
  };
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(e, s) {
    var t = (
      /** @type {Batch} */
      D
    ), i = J();
    if (s && !this.#s.has(e) && !this.#e.has(e))
      if (i) {
        var r = document.createDocumentFragment(), n = P();
        r.append(n), this.#e.set(e, {
          effect: M(() => s(n)),
          fragment: r
        });
      } else
        this.#s.set(
          e,
          M(() => s(this.anchor))
        );
    if (this.#t.set(t, e), i) {
      for (const [f, l] of this.#s)
        f === e ? t.skipped_effects.delete(l) : t.skipped_effects.add(l);
      for (const [f, l] of this.#e)
        f === e ? t.skipped_effects.delete(l.effect) : t.skipped_effects.add(l.effect);
      t.oncommit(this.#n), t.ondiscard(this.#i);
    } else
      this.#n();
  }
}
function pe(a, e, s = !1) {
  var t = new be(a), i = s ? W : 0;
  function r(n, f) {
    t.ensure(n, f);
  }
  K(() => {
    var n = !1;
    e((f, l = !0) => {
      n = !0, r(l, f);
    }), n || r(!1, null);
  }, i);
}
const y = [...` 	
\r\f \v\uFEFF`];
function Ee(a, e, s) {
  var t = "" + a;
  if (s) {
    for (var i in s)
      if (s[i])
        t = t ? t + " " + i : i;
      else if (t.length)
        for (var r = i.length, n = 0; (n = t.indexOf(i, n)) >= 0; ) {
          var f = n + r;
          (n === 0 || y.includes(t[n - 1])) && (f === t.length || y.includes(t[f])) ? t = (n === 0 ? "" : t.substring(0, n)) + t.substring(f + 1) : n = f;
        }
  }
  return t === "" ? null : t;
}
function Se(a, e, s, t, i, r) {
  var n = a.__className;
  if (n !== s || n === void 0) {
    var f = Ee(s, t, r);
    f == null ? a.removeAttribute("class") : a.className = f, a.__className = s;
  } else if (r && i !== r)
    for (var l in r) {
      var c = !!r[l];
      (i == null || c !== !!i[l]) && a.classList.toggle(l, c);
    }
  return r;
}
function Pe(a = !1) {
  const e = (
    /** @type {ComponentContextLegacy} */
    Q
  ), s = e.l.u;
  if (!s) return;
  let t = () => T(e.s);
  if (a) {
    let i = 0, r = (
      /** @type {Record<string, any>} */
      {}
    );
    const n = Z(() => {
      let f = !1;
      const l = e.s;
      for (const c in l)
        l[c] !== r[c] && (r[c] = l[c], f = !0);
      return f && i++, i;
    });
    t = () => v(n);
  }
  s.b.length && V(() => {
    I(e, t), R(s.b);
  }), O(() => {
    const i = A(() => s.m.map(X));
    return () => {
      for (const r of i)
        typeof r == "function" && r();
    };
  }), s.a.length && O(() => {
    I(e, t), R(s.a);
  });
}
function I(a, e) {
  if (a.l.s)
    for (const s of a.l.s) v(s);
  e();
}
let m = !1;
function Ae(a) {
  var e = m;
  try {
    return m = !1, [a(), m];
  } finally {
    m = e;
  }
}
function S(a, e, s, t) {
  var i = !ne || (s & ie) !== 0, r = (s & fe) !== 0, n = (
    /** @type {V} */
    t
  ), f = !0, l = () => (f && (f = !1, n = /** @type {V} */
  t), n), c;
  {
    var d = ue in a || oe in a;
    c = $(a, e)?.set ?? (d && e in a ? (u) => a[e] = u : void 0);
  }
  var o, N = !1;
  [o, N] = Ae(() => (
    /** @type {V} */
    a[e]
  )), o === void 0 && t !== void 0 && (o = l(), c && (i && ee(), c(o)));
  var h;
  if (i ? h = () => {
    var u = (
      /** @type {V} */
      a[e]
    );
    return u === void 0 ? l() : (f = !0, u);
  } : h = () => {
    var u = (
      /** @type {V} */
      a[e]
    );
    return u !== void 0 && (n = /** @type {V} */
    void 0), u === void 0 ? n : u;
  }, i && (s & te) === 0)
    return h;
  if (c) {
    var k = a.$$legacy;
    return (
      /** @type {() => V} */
      (function(u, g) {
        return arguments.length > 0 ? ((!i || !g || k || N) && c(g ? h() : u), u) : h();
      })
    );
  }
  var b = !1, _ = le(() => (b = !1, h()));
  v(_);
  var C = (
    /** @type {Effect} */
    B
  );
  return (
    /** @type {() => V} */
    (function(u, g) {
      if (arguments.length > 0) {
        const w = g ? v(_) : i && r ? se(u) : u;
        return ae(_, w), b = !0, n !== void 0 && (n = w), u;
      }
      return ce && b || (C.f & re) !== 0 ? _.v : v(_);
    })
  );
}
var Te = /* @__PURE__ */ me("<div><!></div>");
function we(a, e) {
  he(e, !1);
  let s = S(e, "value", 8), t = S(e, "type", 8), i = S(e, "selected", 8, !1);
  Pe();
  var r = Te();
  let n;
  var f = _e(r);
  {
    var l = (d) => {
      var o = x();
      L(() => ve(o, `${T(s()), A(() => s().docs.length) ?? ""} docs`)), E(d, o);
    }, c = (d) => {
      var o = x("—");
      E(d, o);
    };
    pe(f, (d) => {
      T(s()), A(() => s()?.docs.length) ? d(l) : d(c, !1);
    });
  }
  L(() => n = Se(r, 1, "svelte-9fs8bo", null, n, {
    table: t() === "table",
    gallery: t() === "gallery",
    selected: i()
  })), E(a, r), de();
}
export {
  we as default
};
